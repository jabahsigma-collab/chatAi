package com.example.aichat

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.PathBuilder
import androidx.compose.ui.graphics.vector.path
import androidx.compose.ui.unit.dp

// Vector icons drawn in code (24x24 viewport), so no image files are needed.

private fun icon(name: String, block: ImageVector.Builder.() -> Unit): ImageVector =
    ImageVector.Builder(name, 24.dp, 24.dp, 24f, 24f).apply(block).build()

private fun ImageVector.Builder.strokes(block: PathBuilder.() -> Unit) = path(
    stroke = SolidColor(Color.Black),
    strokeLineWidth = 1.8f,
    strokeLineCap = StrokeCap.Round,
    strokeLineJoin = StrokeJoin.Round,
    pathBuilder = block,
)

private fun ImageVector.Builder.fills(block: PathBuilder.() -> Unit) = path(
    fill = SolidColor(Color.Black),
    pathBuilder = block,
)

private fun PathBuilder.circle(cx: Float, cy: Float, r: Float) {
    moveTo(cx + r, cy)
    arcTo(r, r, 0f, true, true, cx - r, cy)
    arcTo(r, r, 0f, true, true, cx + r, cy)
    close()
}

val IcMenu: ImageVector by lazy {
    icon("menu") {
        strokes {
            moveTo(4f, 6f); lineTo(20f, 6f)
            moveTo(4f, 12f); lineTo(20f, 12f)
            moveTo(4f, 18f); lineTo(20f, 18f)
        }
    }
}

val IcEdit: ImageVector by lazy {
    icon("edit") {
        strokes {
            moveTo(12f, 4f); lineTo(5f, 4f); lineTo(5f, 19f); lineTo(20f, 19f); lineTo(20f, 12f)
        }
        strokes {
            moveTo(17f, 3f); lineTo(21f, 7f); lineTo(12f, 16f); lineTo(8f, 16f); lineTo(8f, 12f); close()
        }
    }
}

val IcDoc: ImageVector by lazy {
    icon("document") {
        strokes {
            moveTo(6f, 3f); lineTo(14f, 3f); lineTo(19f, 8f); lineTo(19f, 21f); lineTo(6f, 21f); close()
        }
        strokes { moveTo(14f, 3f); lineTo(14f, 8f); lineTo(19f, 8f) }
    }
}

val IcMore: ImageVector by lazy {
    icon("more") {
        fills { circle(5f, 12f, 1.7f); circle(12f, 12f, 1.7f); circle(19f, 12f, 1.7f) }
    }
}

val IcPlus: ImageVector by lazy {
    icon("plus") {
        strokes { moveTo(12f, 5f); lineTo(12f, 19f); moveTo(5f, 12f); lineTo(19f, 12f) }
    }
}

val IcMic: ImageVector by lazy {
    icon("mic") {
        strokes { moveTo(9f, 4f); lineTo(15f, 4f); lineTo(15f, 13f); lineTo(9f, 13f); close() }
        strokes { moveTo(5f, 11f); arcTo(7f, 7f, 0f, false, false, 19f, 11f) }
        strokes { moveTo(12f, 18f); lineTo(12f, 21f) }
    }
}

val IcSend: ImageVector by lazy {
    icon("send") {
        strokes { moveTo(12f, 19f); lineTo(12f, 5f); moveTo(6f, 11f); lineTo(12f, 5f); lineTo(18f, 11f) }
    }
}

val IcSun: ImageVector by lazy {
    icon("sun") {
        strokes { circle(12f, 12f, 4f) }
        strokes {
            moveTo(12f, 2f); lineTo(12f, 4f); moveTo(12f, 20f); lineTo(12f, 22f)
            moveTo(2f, 12f); lineTo(4f, 12f); moveTo(20f, 12f); lineTo(22f, 12f)
            moveTo(4.9f, 4.9f); lineTo(6.3f, 6.3f); moveTo(17.7f, 17.7f); lineTo(19.1f, 19.1f)
            moveTo(4.9f, 19.1f); lineTo(6.3f, 17.7f); moveTo(17.7f, 6.3f); lineTo(19.1f, 4.9f)
        }
    }
}

val IcMoon: ImageVector by lazy {
    icon("moon") {
        strokes {
            moveTo(20f, 14f)
            arcTo(8f, 8f, 0f, true, true, 10f, 4f)
            arcTo(6.5f, 6.5f, 0f, false, false, 20f, 14f)
            close()
        }
    }
}

val IcSettings: ImageVector by lazy {
    icon("settings") {
        strokes { moveTo(4f, 7f); lineTo(20f, 7f); moveTo(4f, 17f); lineTo(20f, 17f) }
        strokes { circle(9f, 7f, 2.2f) }
        strokes { circle(15f, 17f, 2.2f) }
    }
}

val IcChevronDown: ImageVector by lazy {
    icon("chevron_down") { strokes { moveTo(6f, 9f); lineTo(12f, 15f); lineTo(18f, 9f) } }
}

val IcChevronRight: ImageVector by lazy {
    icon("chevron_right") { strokes { moveTo(9f, 6f); lineTo(15f, 12f); lineTo(9f, 18f) } }
}

val IcBack: ImageVector by lazy {
    icon("back") { strokes { moveTo(15f, 6f); lineTo(9f, 12f); lineTo(15f, 18f) } }
}

val IcCopy: ImageVector by lazy {
    icon("copy") {
        strokes { moveTo(9f, 9f); lineTo(20f, 9f); lineTo(20f, 20f); lineTo(9f, 20f); close() }
        strokes { moveTo(5f, 15f); lineTo(5f, 4f); lineTo(16f, 4f) }
    }
}

val IcDownload: ImageVector by lazy {
    icon("download") {
        strokes { moveTo(12f, 4f); lineTo(12f, 15f); moveTo(7f, 10f); lineTo(12f, 15f); lineTo(17f, 10f) }
        strokes { moveTo(5f, 20f); lineTo(19f, 20f) }
    }
}

val IcClose: ImageVector by lazy {
    icon("close") { strokes { moveTo(6f, 6f); lineTo(18f, 18f); moveTo(18f, 6f); lineTo(6f, 18f) } }
}

val IcEye: ImageVector by lazy {
    icon("eye") {
        strokes {
            moveTo(2f, 12f)
            curveTo(5f, 6f, 9f, 5f, 12f, 5f)
            curveTo(15f, 5f, 19f, 6f, 22f, 12f)
            curveTo(19f, 18f, 15f, 19f, 12f, 19f)
            curveTo(9f, 19f, 5f, 18f, 2f, 12f)
            close()
        }
        strokes { circle(12f, 12f, 3f) }
    }
}

val IcTrash: ImageVector by lazy {
    icon("trash") {
        strokes {
            moveTo(4f, 7f); lineTo(20f, 7f)
            moveTo(9f, 7f); lineTo(9f, 4f); lineTo(15f, 4f); lineTo(15f, 7f)
            moveTo(6f, 7f); lineTo(7f, 20f); lineTo(17f, 20f); lineTo(18f, 7f)
        }
    }
}

val IcSkills: ImageVector by lazy {
    icon("skills") {
        strokes {
            moveTo(4f, 4f); lineTo(10f, 4f); lineTo(10f, 10f); lineTo(4f, 10f); close()
            moveTo(14f, 4f); lineTo(20f, 4f); lineTo(20f, 10f); lineTo(14f, 10f); close()
            moveTo(4f, 14f); lineTo(10f, 14f); lineTo(10f, 20f); lineTo(4f, 20f); close()
            moveTo(14f, 14f); lineTo(20f, 14f); lineTo(20f, 20f); lineTo(14f, 20f); close()
        }
    }
}

val IcList: ImageVector by lazy {
    icon("list") {
        strokes { moveTo(8f, 6f); lineTo(20f, 6f); moveTo(8f, 12f); lineTo(20f, 12f); moveTo(8f, 18f); lineTo(20f, 18f) }
        fills { circle(4f, 6f, 1.2f); circle(4f, 12f, 1.2f); circle(4f, 18f, 1.2f) }
    }
}

val IcEffort: ImageVector by lazy {
    icon("effort") {
        strokes { moveTo(6f, 18f); lineTo(6f, 14f); moveTo(12f, 18f); lineTo(12f, 9f); moveTo(18f, 18f); lineTo(18f, 5f) }
    }
}

val IcPhoto: ImageVector by lazy {
    icon("photo") {
        strokes {
            moveTo(4f, 5f); lineTo(20f, 5f); lineTo(20f, 19f); lineTo(4f, 19f); close()
            moveTo(4f, 15f); lineTo(9f, 10f); lineTo(13f, 14f); lineTo(16f, 11f); lineTo(20f, 15f)
        }
        fills { circle(9f, 9f, 1.6f) }
    }
}

val IcFile: ImageVector by lazy {
    icon("file") {
        strokes {
            moveTo(6f, 3f); lineTo(14f, 3f); lineTo(19f, 8f); lineTo(19f, 21f); lineTo(6f, 21f); close()
            moveTo(9f, 13f); lineTo(16f, 13f); moveTo(9f, 17f); lineTo(16f, 17f)
        }
    }
}

val IcAudio: ImageVector by lazy {
    icon("audio") {
        strokes { moveTo(9f, 17f); lineTo(9f, 5f); lineTo(19f, 3f); lineTo(19f, 15f) }
        fills { circle(6.5f, 17f, 2.5f); circle(16.5f, 15f, 2.5f) }
    }
}

val IcArrowDown: ImageVector by lazy {
    icon("arrow_down") {
        strokes { moveTo(12f, 5f); lineTo(12f, 19f); moveTo(6f, 13f); lineTo(12f, 19f); lineTo(18f, 13f) }
    }
}

val IcCheck: ImageVector by lazy {
    icon("check") { strokes { moveTo(5f, 12f); lineTo(10f, 17f); lineTo(19f, 7f) } }
}

val IcSparkle: ImageVector by lazy {
    icon("sparkle") {
        fills {
            moveTo(12f, 2f)
            curveTo(13f, 8f, 16f, 11f, 22f, 12f)
            curveTo(16f, 13f, 13f, 16f, 12f, 22f)
            curveTo(11f, 16f, 8f, 13f, 2f, 12f)
            curveTo(8f, 11f, 11f, 8f, 12f, 2f)
            close()
        }
    }
}

val IcAsterisk: ImageVector by lazy {
    icon("asterisk") {
        strokes {
            moveTo(12f, 4f); lineTo(12f, 20f)
            moveTo(5.1f, 8f); lineTo(18.9f, 16f)
            moveTo(18.9f, 8f); lineTo(5.1f, 16f)
        }
    }
}

val IcHex: ImageVector by lazy {
    icon("hex") {
        strokes {
            moveTo(12f, 3f); lineTo(20f, 7.5f); lineTo(20f, 16.5f); lineTo(12f, 21f); lineTo(4f, 16.5f); lineTo(4f, 7.5f); close()
            circle(12f, 12f, 2.5f)
        }
    }
}

val IcThink: ImageVector by lazy {
    icon("think") {
        strokes { circle(12f, 12f, 8f) }
        fills { circle(12f, 12f, 2.5f) }
    }
}

val IcUpload: ImageVector by lazy {
    icon("upload") {
        strokes { moveTo(12f, 15f); lineTo(12f, 4f); moveTo(7f, 9f); lineTo(12f, 4f); lineTo(17f, 9f); moveTo(5f, 20f); lineTo(19f, 20f) }
    }
}

val IcShare: ImageVector by lazy {
    icon("share") {
        strokes {
            circle(6f, 12f, 2.5f)
            circle(18f, 6f, 2.5f)
            circle(18f, 18f, 2.5f)
            moveTo(8.2f, 10.8f); lineTo(15.8f, 7.2f)
            moveTo(8.2f, 13.2f); lineTo(15.8f, 16.8f)
        }
    }
}

val IcSearch: ImageVector by lazy {
    icon("search") { strokes { circle(11f, 11f, 6f); moveTo(16f, 16f); lineTo(21f, 21f) } }
}

val IcTerminal: ImageVector by lazy {
    icon("terminal") {
        strokes {
            moveTo(4f, 5f); lineTo(20f, 5f); lineTo(20f, 19f); lineTo(4f, 19f); close()
            moveTo(7f, 9f); lineTo(10f, 12f); lineTo(7f, 15f)
            moveTo(12f, 15f); lineTo(17f, 15f)
        }
    }
}
