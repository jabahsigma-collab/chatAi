package com.example.aichat

import android.util.Base64
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** GitHub account used for AI actions. Token comes from the OAuth device flow. */
data class GhAuth(val token: String, val login: String)

data class DeviceCode(
    val deviceCode: String,
    val userCode: String,
    val verificationUri: String,
    val interval: Int,
    val expiresIn: Int,
)

sealed class PollResult {
    data class Token(val token: String) : PollResult()
    object Pending : PollResult()
    object SlowDown : PollResult()
    data class Error(val message: String) : PollResult()
}

object GitHub {
    private const val JSON = "application/json"
    private const val GH_JSON = "application/vnd.github+json"

    private fun call(
        method: String,
        url: String,
        token: String?,
        body: String?,
        contentType: String,
        accept: String,
    ): Pair<Int, String> {
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = method
            connectTimeout = 20_000
            readTimeout = 30_000
            doInput = true
            setRequestProperty("Accept", accept)
            setRequestProperty("User-Agent", "DeadCode-Android")
            if (!token.isNullOrBlank()) setRequestProperty("Authorization", "Bearer $token")
        }
        return try {
            if (body != null) {
                conn.doOutput = true
                conn.setRequestProperty("Content-Type", contentType)
                conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            code to (stream?.bufferedReader()?.use { it.readText() } ?: "")
        } finally {
            conn.disconnect()
        }
    }

    private fun form(vararg pairs: Pair<String, String>): String =
        pairs.joinToString("&") { URLEncoder.encode(it.first, "UTF-8") + "=" + URLEncoder.encode(it.second, "UTF-8") }

    /** Step 1 of the device flow: get a code the user enters on github.com. */
    fun startDeviceFlow(clientId: String): DeviceCode {
        val (code, text) = call(
            "POST", "https://github.com/login/device/code", null,
            form("client_id" to clientId, "scope" to "repo"),
            "application/x-www-form-urlencoded", JSON,
        )
        val o = JSONObject(text)
        if (code !in 200..299 || o.has("error")) {
            throw IllegalStateException(o.optString("error_description", "HTTP $code"))
        }
        return DeviceCode(
            deviceCode = o.getString("device_code"),
            userCode = o.getString("user_code"),
            verificationUri = o.getString("verification_uri"),
            interval = o.optInt("interval", 5),
            expiresIn = o.optInt("expires_in", 900),
        )
    }

    /** Step 2: checks whether the user has approved the code yet. */
    fun pollToken(clientId: String, deviceCode: String): PollResult {
        val (_, text) = call(
            "POST", "https://github.com/login/oauth/access_token", null,
            form(
                "client_id" to clientId,
                "device_code" to deviceCode,
                "grant_type" to "urn:ietf:params:oauth:grant-type:device_code",
            ),
            "application/x-www-form-urlencoded", JSON,
        )
        val o = JSONObject(text)
        val token = o.optString("access_token")
        if (token.isNotEmpty()) return PollResult.Token(token)
        return when (val err = o.optString("error")) {
            "authorization_pending" -> PollResult.Pending
            "slow_down" -> PollResult.SlowDown
            else -> PollResult.Error(o.optString("error_description", err.ifEmpty { "unknown error" }))
        }
    }

    fun login(token: String): String {
        val (code, text) = call("GET", "https://api.github.com/user", token, null, JSON, GH_JSON)
        if (code !in 200..299) throw IllegalStateException("GitHub HTTP $code")
        return JSONObject(text).getString("login")
    }

    /** Creates a private repository in the connected account. */
    fun createRepo(token: String, name: String): String {
        val body = JSONObject().put("name", name).put("private", true).put("auto_init", false).toString()
        val (code, text) = call("POST", "https://api.github.com/user/repos", token, body, JSON, GH_JSON)
        if (code !in 200..299) throw IllegalStateException("GitHub HTTP $code: ${text.take(200)}")
        return JSONObject(text).optString("html_url")
    }

    /** Creates or updates one file in a repository. */
    fun putFile(token: String, owner: String, repo: String, path: String, content: String, message: String): String {
        val encPath = path.split('/').joinToString("/") { URLEncoder.encode(it, "UTF-8").replace("+", "%20") }
        val url = "https://api.github.com/repos/$owner/$repo/contents/$encPath"
        val (getCode, getText) = call("GET", url, token, null, JSON, GH_JSON)
        val body = JSONObject()
            .put("message", message)
            .put("content", Base64.encodeToString(content.toByteArray(Charsets.UTF_8), Base64.NO_WRAP))
        if (getCode in 200..299) body.put("sha", JSONObject(getText).getString("sha"))
        val (code, text) = call("PUT", url, token, body.toString(), JSON, GH_JSON)
        if (code !in 200..299) throw IllegalStateException("GitHub HTTP $code: ${text.take(200)}")
        return JSONObject(text).optJSONObject("content")?.optString("html_url").orEmpty()
    }
}
