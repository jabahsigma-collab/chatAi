package com.example.aichat

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

data class Provider(val id: String, val name: String, val baseUrl: String)

val PROVIDERS = listOf(
    Provider("openai", "OpenAI", "https://api.openai.com/v1"),
    Provider("anthropic", "Anthropic", "https://api.anthropic.com/v1"),
    Provider("gemini", "Google Gemini", "https://generativelanguage.googleapis.com/v1beta/openai"),
    Provider("deepseek", "DeepSeek", "https://api.deepseek.com/v1"),
    Provider("groq", "Groq", "https://api.groq.com/openai/v1"),
    Provider("mistral", "Mistral", "https://api.mistral.ai/v1"),
    Provider("openrouter", "OpenRouter", "https://openrouter.ai/api/v1"),
    Provider("xai", "xAI", "https://api.x.ai/v1"),
    Provider("together", "Together AI", "https://api.together.xyz/v1"),
    Provider("cohere", "Cohere", "https://api.cohere.ai/compatibility/v1"),
    Provider("custom", "Custom Provider", "https://osaii.wyvernhub.net/api/v1"),
)

data class Profile(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val providerId: String = "custom",
    val baseUrl: String,
    val apiKey: String = "",
    val model: String = "",
    val enabled: Boolean = true,
)

data class AgentAssign(
    val planner: String? = null,
    val coder: String? = null,
    val reviewer: String? = null,
)

/** A reusable instruction block that is added to the system prompt when enabled. */
data class Skill(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val text: String,
    val enabled: Boolean = true,
)

data class Settings(
    val profiles: List<Profile> = emptyList(),
    val activeId: String? = null,
    val failoverKeys: Boolean = true,      // Toggle 1
    val failoverModels: Boolean = true,    // Toggle 2
    val askEveryTime: Boolean = true,      // true = "Ask every time", false = "Auto / No prompt"
    val agents: AgentAssign = AgentAssign(),
    val effort: String = "medium",         // low | medium | high | max
    val startupPrompt: String = "",        // sent to the model at the start of a new chat, hidden in UI
    val skills: List<Skill> = emptyList(),
)

class ConfigStore(context: Context) {
    private val prefs = context.getSharedPreferences("aichat", Context.MODE_PRIVATE)

    fun load(): Settings {
        val raw = prefs.getString("settings", null) ?: return Settings()
        return try {
            val o = JSONObject(raw)
            val arr = o.optJSONArray("profiles") ?: JSONArray()
            val profiles = List(arr.length()) { i ->
                val p = arr.getJSONObject(i)
                Profile(
                    id = p.optString("id"),
                    name = p.optString("name"),
                    providerId = p.optString("providerId", "custom"),
                    baseUrl = p.optString("baseUrl"),
                    apiKey = p.optString("apiKey"),
                    model = p.optString("model"),
                    enabled = p.optBoolean("enabled", true),
                )
            }
            val skillArr = o.optJSONArray("skills") ?: JSONArray()
            val skills = List(skillArr.length()) { i ->
                val s = skillArr.getJSONObject(i)
                Skill(
                    id = s.optString("id"),
                    name = s.optString("name"),
                    text = s.optString("text"),
                    enabled = s.optBoolean("enabled", true),
                )
            }
            val ag = o.optJSONObject("agents") ?: JSONObject()
            Settings(
                profiles = profiles,
                activeId = o.optString("activeId").ifEmpty { null },
                failoverKeys = o.optBoolean("failoverKeys", true),
                failoverModels = o.optBoolean("failoverModels", true),
                askEveryTime = o.optBoolean("askEveryTime", true),
                agents = AgentAssign(
                    planner = ag.optString("planner").ifEmpty { null },
                    coder = ag.optString("coder").ifEmpty { null },
                    reviewer = ag.optString("reviewer").ifEmpty { null },
                ),
                effort = o.optString("effort", "medium"),
                startupPrompt = o.optString("startupPrompt"),
                skills = skills,
            )
        } catch (e: Exception) {
            Settings()
        }
    }

    fun save(s: Settings) {
        val arr = JSONArray()
        s.profiles.forEach { p ->
            arr.put(
                JSONObject()
                    .put("id", p.id)
                    .put("name", p.name)
                    .put("providerId", p.providerId)
                    .put("baseUrl", p.baseUrl)
                    .put("apiKey", p.apiKey)
                    .put("model", p.model)
                    .put("enabled", p.enabled)
            )
        }
        val skillArr = JSONArray()
        s.skills.forEach { k ->
            skillArr.put(
                JSONObject()
                    .put("id", k.id)
                    .put("name", k.name)
                    .put("text", k.text)
                    .put("enabled", k.enabled)
            )
        }
        val ag = JSONObject()
            .put("planner", s.agents.planner.orEmpty())
            .put("coder", s.agents.coder.orEmpty())
            .put("reviewer", s.agents.reviewer.orEmpty())
        val o = JSONObject()
            .put("profiles", arr)
            .put("activeId", s.activeId.orEmpty())
            .put("failoverKeys", s.failoverKeys)
            .put("failoverModels", s.failoverModels)
            .put("askEveryTime", s.askEveryTime)
            .put("agents", ag)
            .put("effort", s.effort)
            .put("startupPrompt", s.startupPrompt)
            .put("skills", skillArr)
        prefs.edit().putString("settings", o.toString()).apply()
    }
}
