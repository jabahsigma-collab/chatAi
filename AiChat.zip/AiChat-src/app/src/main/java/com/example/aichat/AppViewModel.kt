package com.example.aichat

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

data class ChatItem(
    val id: String = UUID.randomUUID().toString(),
    val kind: String,          // user | assistant | step | error | action
    val meta: String = "",
    val text: String = "",
    val reasoning: String = "",
    val action: ActionItem? = null,
)

class AppViewModel(app: Application) : AndroidViewModel(app) {

    private val store = ConfigStore(app)
    private val executor = ActionExecutor(app)
    private val history = mutableListOf<ChatTurn>()

    private val _settings = MutableStateFlow(store.load())
    val settings: StateFlow<Settings> = _settings.asStateFlow()

    private val _chat = MutableStateFlow<List<ChatItem>>(emptyList())
    val chat: StateFlow<List<ChatItem>> = _chat.asStateFlow()

    private val _logs = MutableStateFlow<List<String>>(emptyList())
    val logs: StateFlow<List<String>> = _logs.asStateFlow()

    private val _busy = MutableStateFlow(false)
    val busy: StateFlow<Boolean> = _busy.asStateFlow()

    private val _ping = MutableStateFlow<PingResult?>(null)
    val pingResult: StateFlow<PingResult?> = _ping.asStateFlow()

    private fun log(msg: String) {
        val time = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
        _logs.value = (_logs.value + "[$time] $msg").takeLast(300)
    }

    private fun append(item: ChatItem) {
        _chat.value = _chat.value + item
    }

    // ---------- Settings ----------

    private fun commit(s: Settings) {
        _settings.value = s
        store.save(s)
    }

    fun updateSettings(transform: (Settings) -> Settings) = commit(transform(_settings.value))

    fun saveProfile(p: Profile) {
        val s = _settings.value
        val list = s.profiles.filter { it.id != p.id } + p
        commit(s.copy(profiles = list, activeId = s.activeId ?: p.id))
        log("Saved profile ${p.name}")
    }

    fun deleteProfile(id: String) {
        val s = _settings.value
        val list = s.profiles.filter { it.id != id }
        val newActive = if (s.activeId == id) list.firstOrNull()?.id else s.activeId
        commit(s.copy(profiles = list, activeId = newActive))
        log("Deleted profile")
    }

    fun setActive(id: String) = commit(_settings.value.copy(activeId = id))

    fun ping(baseUrl: String, apiKey: String) {
        viewModelScope.launch {
            val r = ApiClient.ping(baseUrl, apiKey)
            _ping.value = r
            val summary = if (r.ok) {
                "HTTP ${r.status}, ${r.latencyMs} ms, ${r.models.size} models"
            } else {
                "failed: ${r.message.take(120)}"
            }
            log("Ping $baseUrl -> $summary")
        }
    }

    // ---------- Chat ----------

    fun send(text: String, multiAgent: Boolean, attachments: List<Attachment> = emptyList()) {
        val message = text.trim()
        if ((message.isEmpty() && attachments.isEmpty()) || _busy.value) return
        val attachedNames = attachments.joinToString(", ") { it.name }
        append(ChatItem(kind = "user", meta = if (attachedNames.isEmpty()) "" else "Attached: $attachedNames", text = message))
        _busy.value = true

        viewModelScope.launch {
            try {
                val result = AgentEngine.runTurn(
                    _settings.value, multiAgent, message, attachments, history.toList()
                ) { log(it) }

                if (multiAgent) {
                    result.steps.forEach { s ->
                        append(ChatItem(kind = "step",
                            meta = "${s.agent} · ${s.profileName} / ${s.model}",
                            text = s.text, reasoning = s.reasoning))
                    }
                } else {
                    append(ChatItem(kind = "assistant",
                        meta = "Assistant · ${result.profileName} / ${result.model}",
                        text = result.text, reasoning = result.reasoning))
                }

                history += ChatTurn("user", if (attachedNames.isEmpty()) message else "$message\n[attached: $attachedNames]")
                history += ChatTurn("assistant", result.text)

                result.actions.forEach { action ->
                    append(ChatItem(id = action.id, kind = "action", action = action))
                    if (!_settings.value.askEveryTime) approveAction(action)
                }
            } catch (e: Exception) {
                append(ChatItem(kind = "error", meta = "Error", text = e.message ?: e.toString()))
                log("Error: ${e.message}")
            } finally {
                _busy.value = false
            }
        }
    }

    fun clearChat() {
        _chat.value = emptyList()
        history.clear()
    }

    // ---------- Actions ----------

    fun approveAction(item: ActionItem) {
        setActionState(item.id, "running", "")
        viewModelScope.launch {
            val result = withContext(Dispatchers.IO) { executor.execute(item) }
            setActionState(item.id, result.status, result.output)
            log("Action ${result.kind} -> ${result.status}: ${result.target.take(80)}")
        }
    }

    fun rejectAction(item: ActionItem) {
        setActionState(item.id, "rejected", "Rejected by user")
        log("Rejected ${item.kind}: ${item.target.take(80)}")
    }

    private fun setActionState(id: String, status: String, output: String) {
        _chat.value = _chat.value.map { c ->
            val a = c.action
            if (c.id == id && a != null) c.copy(action = a.copy(status = status, output = output)) else c
        }
    }
}
