package com.example.aichat

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

data class ChatItem(
    val id: String = UUID.randomUUID().toString(),
    val kind: String,          // user | assistant | step | error | action
    val meta: String = "",
    val text: String = "",
    val reasoning: String = "",
    val action: ActionItem? = null,
)

class AppViewModel(app: Application) : AndroidViewModel(app) {

    private val store = ConfigStore(app)
    private val chatStore = ChatStore(app)
    private val history = mutableListOf<ChatTurn>()
    private var chatId: String = UUID.randomUUID().toString()
    private var customTitle: String? = null

    private val _settings = MutableStateFlow(store.load())
    val settings: StateFlow<Settings> = _settings.asStateFlow()

    private val _chat = MutableStateFlow<List<ChatItem>>(emptyList())
    val chat: StateFlow<List<ChatItem>> = _chat.asStateFlow()

    private val _currentId = MutableStateFlow(chatId)
    val currentId: StateFlow<String> = _currentId.asStateFlow()

    private val _sessions = MutableStateFlow(chatStore.list())
    val sessions: StateFlow<List<ChatSession>> = _sessions.asStateFlow()

    private val _logs = MutableStateFlow<List<String>>(emptyList())
    val logs: StateFlow<List<String>> = _logs.asStateFlow()

    private val _busy = MutableStateFlow(false)
    val busy: StateFlow<Boolean> = _busy.asStateFlow()

    private val _ping = MutableStateFlow<PingResult?>(null)
    val pingResult: StateFlow<PingResult?> = _ping.asStateFlow()

    init {
        // Reopen the most recently used chat on launch.
        _sessions.value.firstOrNull()?.let { restore(it) }
    }

    private fun log(msg: String) {
        val time = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
        _logs.value = (_logs.value + "[$time] $msg").takeLast(300)
    }

    // ---------- Chat persistence ----------

    private fun titleOf(items: List<ChatItem>): String =
        items.firstOrNull { it.kind == "user" && it.text.isNotBlank() }?.text?.take(40) ?: "New chat"

    /** Saves the current chat. Chats without any user message are not saved. */
    private fun persist() {
        val items = _chat.value
        if (items.none { it.kind == "user" }) return
        val s = ChatSession(
            id = chatId,
            title = titleOf(items),
            updatedAt = System.currentTimeMillis(),
            items = items,
            history = history.toList(),
            customTitle = customTitle,
        )
        chatStore.save(s)
        _sessions.value = (listOf(s) + _sessions.value.filter { it.id != chatId })
            .sortedByDescending { it.updatedAt }
    }

    private fun restore(s: ChatSession) {
        chatId = s.id
        customTitle = s.customTitle
        _currentId.value = s.id
        _chat.value = s.items
        history.clear()
        history.addAll(s.history)
    }

    private fun append(item: ChatItem) {
        _chat.value = _chat.value + item
        persist()
    }

    // ---------- Settings ----------

    private fun commit(s: Settings) {
        _settings.value = s
        store.save(s)
    }

    fun updateSettings(transform: (Settings) -> Settings) = commit(transform(_settings.value))

    fun saveProfile(p: Profile) {
        val s = _settings.value
        val list = s.profiles.filter { it.id != p.id } + p
        commit(s.copy(profiles = list, activeId = s.activeId ?: p.id))
        log("Saved profile ${p.name}")
    }

    fun deleteProfile(id: String) {
        val s = _settings.value
        val list = s.profiles.filter { it.id != id }
        val newActive = if (s.activeId == id) list.firstOrNull()?.id else s.activeId
        commit(s.copy(profiles = list, activeId = newActive))
        log("Deleted profile")
    }

    fun setActive(id: String) = commit(_settings.value.copy(activeId = id))

    /** Adds one profile per fetched model; models already saved for this endpoint are skipped. */
    fun addModels(providerId: String, baseUrl: String, apiKey: String, models: List<String>): Int {
        val s = _settings.value
        val existing = s.profiles.filter { it.baseUrl == baseUrl && it.apiKey == apiKey }.map { it.model }.toSet()
        val fresh = models.filter { it !in existing }.map { m ->
            Profile(name = m, providerId = providerId, baseUrl = baseUrl, apiKey = apiKey, model = m)
        }
        if (fresh.isEmpty()) return 0
        commit(s.copy(profiles = s.profiles + fresh, activeId = s.activeId ?: fresh.first().id))
        log("Added ${fresh.size} models from $baseUrl")
        return fresh.size
    }

    fun ping(baseUrl: String, apiKey: String) {
        viewModelScope.launch {
            val r = ApiClient.ping(baseUrl, apiKey)
            _ping.value = r
            val summary = if (r.ok) {
                "HTTP ${r.status}, ${r.latencyMs} ms, ${r.models.size} models"
            } else {
                "failed: ${r.message.take(120)}"
            }
            log("Ping $baseUrl -> $summary")
        }
    }

    // ---------- Chat ----------

    fun send(text: String, multiAgent: Boolean, attachments: List<Attachment> = emptyList()) {
        val message = text.trim()
        if ((message.isEmpty() && attachments.isEmpty()) || _busy.value) return
        val attachedNames = attachments.joinToString(", ") { it.name }
        // The startup prompt is only sent on the first message of a chat and is never shown in the UI.
        val startup = history.isEmpty()
        val userTurn = if (attachedNames.isEmpty()) message else "$message\n[attached: $attachedNames]"
        append(ChatItem(kind = "user", meta = if (attachedNames.isEmpty()) "" else "Attached: $attachedNames", text = message))
        _busy.value = true

        viewModelScope.launch {
            try {
                val result = AgentEngine.runTurn(
                    _settings.value, multiAgent, message, attachments, history.toList(), startup
                ) { log(it) }

                history += ChatTurn("user", userTurn)
                history += ChatTurn("assistant", result.text)

                if (multiAgent) {
                    result.steps.forEach { s ->
                        append(ChatItem(kind = "step",
                            meta = "${s.agent} · ${s.profileName} / ${s.model}",
                            text = s.text, reasoning = s.reasoning))
                    }
                } else {
                    append(ChatItem(kind = "assistant",
                        meta = "${result.profileName} · ${result.model}",
                        text = result.text, reasoning = result.reasoning))
                }

                result.actions.forEach { action ->
                    append(ChatItem(id = action.id, kind = "action", action = action))
                    if (!_settings.value.askEveryTime) approveAction(action)
                }
            } catch (e: Exception) {
                append(ChatItem(kind = "error", meta = "Error", text = e.message ?: e.toString()))
                log("Error: ${e.message}")
            } finally {
                _busy.value = false
                persist()
            }
        }
    }

    /** Starts an empty chat. The previous chat stays saved in the list. */
    fun newChat() {
        if (_busy.value) return
        chatId = UUID.randomUUID().toString()
        customTitle = null
        _currentId.value = chatId
        _chat.value = emptyList()
        history.clear()
        log("New chat started")
    }

    fun clearChat() = newChat()

    /** JSON text of a chat, or null if it does not exist. */
    fun exportChat(id: String): String? {
        val s = if (id == chatId) {
            ChatSession(id = chatId, title = titleOf(_chat.value), items = _chat.value,
                history = history.toList(), customTitle = customTitle)
        } else {
            _sessions.value.firstOrNull { it.id == id }
        }
        return s?.let { chatStore.encode(it) }
    }

    /** Imports a chat exported from this app as a new chat and opens it. */
    fun importChat(text: String): Boolean {
        if (_busy.value) return false
        val parsed = runCatching { chatStore.decode(text) }.getOrNull() ?: return false
        if (parsed.items.isEmpty()) return false
        val fresh = parsed.copy(id = UUID.randomUUID().toString(), updatedAt = System.currentTimeMillis())
        chatStore.save(fresh)
        _sessions.value = (listOf(fresh) + _sessions.value).sortedByDescending { it.updatedAt }
        restore(fresh)
        log("Imported chat")
        return true
    }

    /** Runs a shell command in the workspace folder and returns its output to the caller. */
    fun runTerminal(cmd: String, onDone: (String) -> Unit) {
        viewModelScope.launch {
            val r = withContext(Dispatchers.IO) {
                ActionExecutor(getApplication(), _settings.value.workspacePath)
                    .execute(ActionItem(kind = "command", target = cmd))
            }
            log("Terminal: ${cmd.take(60)} -> ${r.status}")
            onDone(r.output)
        }
    }

    fun renameChat(id: String, title: String) {
        val clean = title.trim().ifEmpty { null }
        if (id == chatId) {
            customTitle = clean
            persist()
            return
        }
        _sessions.value.firstOrNull { it.id == id }?.let { s ->
            val updated = s.copy(customTitle = clean)
            chatStore.save(updated)
            _sessions.value = _sessions.value.map { if (it.id == id) updated else it }
        }
    }

    fun openChat(id: String) {
        if (_busy.value) return
        _sessions.value.firstOrNull { it.id == id }?.let {
            restore(it)
            log("Opened chat: ${it.title}")
        }
    }

    fun deleteChat(id: String) {
        if (_busy.value && id == chatId) return
        chatStore.delete(id)
        _sessions.value = _sessions.value.filter { it.id != id }
        if (id == chatId) newChat()
        log("Chat deleted")
    }

    // ---------- Actions ----------

    fun approveAction(item: ActionItem) {
        setActionState(item.id, "running", "")
        viewModelScope.launch {
            val result = withContext(Dispatchers.IO) {
                ActionExecutor(getApplication(), _settings.value.workspacePath).execute(item)
            }
            setActionState(item.id, result.status, result.output)
            log("Action ${result.kind} -> ${result.status}: ${result.target.take(80)}")
        }
    }

    fun rejectAction(item: ActionItem) {
        setActionState(item.id, "rejected", "Rejected by user")
        log("Rejected ${item.kind}: ${item.target.take(80)}")
    }

    private fun setActionState(id: String, status: String, output: String) {
        _chat.value = _chat.value.map { c ->
            val a = c.action
            if (c.id == id && a != null) c.copy(action = a.copy(status = status, output = output)) else c
        }
        persist()
    }
}
