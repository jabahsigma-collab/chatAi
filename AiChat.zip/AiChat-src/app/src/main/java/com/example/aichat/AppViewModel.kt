package com.example.aichat

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

data class ChatItem(
    val id: String = UUID.randomUUID().toString(),
    val kind: String,          // user | assistant | step | error | action
    val meta: String = "",
    val text: String = "",
    val reasoning: String = "",
    val action: ActionItem? = null,
    val attachments: List<Attachment> = emptyList(),
    val inTok: Int = 0,
    val outTok: Int = 0,
    val cost: Double = 0.0,
)

private fun sortSessions(list: List<ChatSession>): List<ChatSession> =
    list.sortedWith(compareByDescending<ChatSession> { it.pinned }.thenByDescending { it.updatedAt })

class AppViewModel(app: Application) : AndroidViewModel(app) {

    private val store = ConfigStore(app)
    private val chatStore = ChatStore(app)
    private val history = mutableListOf<ChatTurn>()
    private var chatId: String = UUID.randomUUID().toString()
    private var customTitle: String? = null
    private var pinned = false
    private var job: Job? = null

    private val _settings = MutableStateFlow(store.load())
    val settings: StateFlow<Settings> = _settings.asStateFlow()

    private val _chat = MutableStateFlow<List<ChatItem>>(emptyList())
    val chat: StateFlow<List<ChatItem>> = _chat.asStateFlow()

    private val _currentId = MutableStateFlow(chatId)
    val currentId: StateFlow<String> = _currentId.asStateFlow()

    private val _sessions = MutableStateFlow(sortSessions(chatStore.list()))
    val sessions: StateFlow<List<ChatSession>> = _sessions.asStateFlow()

    private val _logs = MutableStateFlow<List<String>>(emptyList())
    val logs: StateFlow<List<String>> = _logs.asStateFlow()

    private val _busy = MutableStateFlow(false)
    val busy: StateFlow<Boolean> = _busy.asStateFlow()

    private val _ping = MutableStateFlow<PingResult?>(null)
    val pingResult: StateFlow<PingResult?> = _ping.asStateFlow()

    init {
        // Reopen the most recently used chat on launch.
        _sessions.value.firstOrNull()?.let { restore(it) }
    }

    private fun log(msg: String) {
        val time = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
        _logs.value = (_logs.value + "[$time] $msg").takeLast(300)
    }

    // ---------- Chat persistence ----------

    private fun titleOf(items: List<ChatItem>): String =
        items.firstOrNull { it.kind == "user" && it.text.isNotBlank() }?.text?.take(40) ?: "New chat"

    /** Saves the current chat. A chat without any user message is removed from storage. */
    private fun persist() {
        val items = _chat.value
        if (items.none { it.kind == "user" }) {
            chatStore.delete(chatId)
            _sessions.value = _sessions.value.filter { it.id != chatId }
            return
        }
        val s = ChatSession(
            id = chatId,
            title = titleOf(items),
            updatedAt = System.currentTimeMillis(),
            items = items,
            history = history.toList(),
            customTitle = customTitle,
            pinned = pinned,
        )
        chatStore.save(s)
        _sessions.value = sortSessions(listOf(s) + _sessions.value.filter { it.id != chatId })
    }

    private fun restore(s: ChatSession) {
        chatId = s.id
        customTitle = s.customTitle
        pinned = s.pinned
        _currentId.value = s.id
        _chat.value = s.items
        history.clear()
        history.addAll(s.history)
    }

    private fun append(item: ChatItem) {
        _chat.value = _chat.value + item
        persist()
    }

    /** Changes one item without saving (used while a reply is streaming). */
    private fun updateItem(id: String, f: (ChatItem) -> ChatItem) {
        _chat.value = _chat.value.map { if (it.id == id) f(it) else it }
    }

    private fun removeItem(id: String) {
        _chat.value = _chat.value.filter { it.id != id }
    }

    // ---------- Settings ----------

    private fun commit(s: Settings) {
        _settings.value = s
        store.save(s)
    }

    fun updateSettings(transform: (Settings) -> Settings) = commit(transform(_settings.value))

    fun saveProfile(p: Profile) {
        val s = _settings.value
        val list = s.profiles.filter { it.id != p.id } + p
        commit(s.copy(profiles = list, activeId = s.activeId ?: p.id))
        log("Saved profile ${p.name}")
    }

    fun deleteProfile(id: String) {
        val s = _settings.value
        val list = s.profiles.filter { it.id != id }
        val newActive = if (s.activeId == id) list.firstOrNull()?.id else s.activeId
        commit(s.copy(profiles = list, activeId = newActive))
        log("Deleted profile")
    }

    fun setActive(id: String) = commit(_settings.value.copy(activeId = id))

    /** Adds one profile per fetched model; models already saved for this endpoint are skipped. */
    fun addModels(providerId: String, baseUrl: String, apiKey: String, models: List<String>): Int {
        val s = _settings.value
        val existing = s.profiles.filter { it.baseUrl == baseUrl && it.apiKey == apiKey }.map { it.model }.toSet()
        val fresh = models.filter { it !in existing }.map { m ->
            Profile(name = m, providerId = providerId, baseUrl = baseUrl, apiKey = apiKey, model = m)
        }
        if (fresh.isEmpty()) return 0
        commit(s.copy(profiles = s.profiles + fresh, activeId = s.activeId ?: fresh.first().id))
        log("Added ${fresh.size} models from $baseUrl")
        return fresh.size
    }

    fun ping(baseUrl: String, apiKey: String) {
        viewModelScope.launch {
            val r = ApiClient.ping(baseUrl, apiKey)
            _ping.value = r
            val summary = if (r.ok) {
                "HTTP ${r.status}, ${r.latencyMs} ms, ${r.models.size} models"
            } else {
                "failed: ${r.message.take(120)}"
            }
            log("Ping $baseUrl -> $summary")
        }
    }

    // ---------- Chat ----------

    fun send(text: String, multiAgent: Boolean, attachments: List<Attachment> = emptyList()) {
        val message = text.trim()
        if ((message.isEmpty() && attachments.isEmpty()) || _busy.value) return
        startTurn(message, attachments, multiAgent)
    }

    /** Sends one user message, streams the answer, and records the result. */
    private fun startTurn(message: String, attachments: List<Attachment>, multiAgent: Boolean) {
        val attachedNames = attachments.joinToString(", ") { it.name }
        // The startup prompt is only sent on the first message of a chat and is never shown in the UI.
        val startup = history.isEmpty()
        val userTurn = if (attachedNames.isEmpty()) message else "$message\n[attached: $attachedNames]"
        append(ChatItem(
            kind = "user",
            meta = if (attachedNames.isEmpty()) "" else "Attached: $attachedNames",
            text = message,
            attachments = attachments,
        ))
        _busy.value = true
        val liveId = "live-" + UUID.randomUUID().toString()
        if (!multiAgent) append(ChatItem(id = liveId, kind = "assistant"))

        job = viewModelScope.launch {
            try {
                val result = AgentEngine.runTurn(
                    settings = _settings.value,
                    multiAgent = multiAgent,
                    message = message,
                    attachments = attachments,
                    history = history.toList(),
                    startup = startup,
                    info = buildInfo(_settings.value),
                    onDelta = { content, reasoning ->
                        if (!multiAgent) updateItem(liveId) { it.copy(text = content, reasoning = reasoning) }
                    },
                ) { log(it) }

                history += ChatTurn("user", userTurn)
                history += ChatTurn("assistant", result.text)

                if (multiAgent) {
                    result.steps.forEach { s ->
                        append(ChatItem(kind = "step",
                            meta = "${s.agent} · ${s.profileName} / ${s.model}",
                            text = s.text, reasoning = s.reasoning))
                    }
                } else {
                    updateItem(liveId) {
                        it.copy(
                            meta = "${result.profileName} · ${result.model}",
                            text = result.text,
                            reasoning = result.reasoning,
                            inTok = result.inTokens,
                            outTok = result.outTokens,
                            cost = result.cost,
                        )
                    }
                }

                result.actions.forEach { action ->
                    append(ChatItem(id = action.id, kind = "action", action = action))
                    if (!_settings.value.askEveryTime) approveAction(action)
                }
            } catch (e: CancellationException) {
                // Stopped by the user: keep whatever was already streamed.
                if (!multiAgent) {
                    val partial = _chat.value.firstOrNull { it.id == liveId }?.text.orEmpty()
                    history += ChatTurn("user", userTurn)
                    history += ChatTurn("assistant", partial)
                    if (partial.isBlank()) {
                        removeItem(liveId)
                    } else {
                        updateItem(liveId) { it.copy(meta = if (it.meta.isBlank()) "Stopped" else it.meta + " · stopped") }
                    }
                }
                log("Generation stopped")
                throw e
            } catch (e: Exception) {
                if (!multiAgent) removeItem(liveId)
                append(ChatItem(kind = "error", meta = "Error", text = e.message ?: e.toString()))
                log("Error: ${e.message}")
            } finally {
                _busy.value = false
                job = null
                persist()
                val s = _settings.value
                if (s.notifyDone && !AppState.foreground && !multiAgent) {
                    Notify.show(getApplication(), "DeadCode", "Reply is ready")
                }
            }
        }
    }

    /** Stops the reply that is being generated. */
    fun stop() {
        job?.cancel()
    }

    /** Re-runs the last user message with a fresh answer. */
    fun regenerate(multiAgent: Boolean) {
        if (_busy.value) return
        val idx = _chat.value.indexOfLast { it.kind == "user" }
        if (idx < 0) return
        val u = _chat.value[idx]
        truncateFrom(idx)
        startTurn(u.text, u.attachments, multiAgent)
    }

    /** Replaces a user message and re-runs the conversation from it. */
    fun editAndResend(itemId: String, text: String, multiAgent: Boolean) {
        if (_busy.value) return
        val clean = text.trim()
        val idx = _chat.value.indexOfFirst { it.id == itemId }
        if (idx < 0 || clean.isEmpty()) return
        val u = _chat.value[idx]
        truncateFrom(idx)
        startTurn(clean, u.attachments, multiAgent)
    }

    /** Removes the chat from item idx onwards and rebuilds the model history from what remains. */
    private fun truncateFrom(idx: Int) {
        _chat.value = _chat.value.take(idx)
        history.clear()
        history += rebuildHistory(_chat.value)
        persist()
    }

    private fun rebuildHistory(items: List<ChatItem>): List<ChatTurn> {
        val out = mutableListOf<ChatTurn>()
        var pendingStep: String? = null
        fun flushStep() {
            pendingStep?.let { out += ChatTurn("assistant", it) }
            pendingStep = null
        }
        items.forEach { c ->
            when (c.kind) {
                "user" -> {
                    flushStep()
                    val names = c.attachments.joinToString(", ") { it.name }
                    out += ChatTurn("user", if (names.isEmpty()) c.text else "${c.text}\n[attached: $names]")
                }
                "assistant" -> {
                    flushStep()
                    if (c.text.isNotBlank()) out += ChatTurn("assistant", c.text)
                }
                "step" -> { pendingStep = c.text }
            }
        }
        flushStep()
        return out
    }

    /** Starts an empty chat. The previous chat stays saved in the list. */
    fun newChat() {
        if (_busy.value) return
        chatId = UUID.randomUUID().toString()
        customTitle = null
        pinned = false
        _currentId.value = chatId
        _chat.value = emptyList()
        history.clear()
        log("New chat started")
    }

    fun clearChat() = newChat()

    fun openChat(id: String) {
        if (_busy.value) return
        _sessions.value.firstOrNull { it.id == id }?.let {
            restore(it)
            log("Opened chat: ${it.customTitle ?: it.title}")
        }
    }

    fun deleteChat(id: String) {
        if (_busy.value && id == chatId) return
        chatStore.delete(id)
        _sessions.value = _sessions.value.filter { it.id != id }
        if (id == chatId) newChat()
        log("Chat deleted")
    }

    fun renameChat(id: String, title: String) {
        val clean = title.trim().ifEmpty { null }
        if (id == chatId) {
            customTitle = clean
            persist()
            return
        }
        _sessions.value.firstOrNull { it.id == id }?.let { s ->
            val updated = s.copy(customTitle = clean)
            chatStore.save(updated)
            _sessions.value = sortSessions(_sessions.value.map { if (it.id == id) updated else it })
        }
    }

    fun togglePin(id: String) {
        if (id == chatId) {
            pinned = !pinned
            persist()
            return
        }
        _sessions.value.firstOrNull { it.id == id }?.let { s ->
            val updated = s.copy(pinned = !s.pinned)
            chatStore.save(updated)
            _sessions.value = sortSessions(_sessions.value.map { if (it.id == id) updated else it })
        }
    }

    /** JSON text of a chat, or null if it does not exist. */
    fun exportChat(id: String): String? {
        val s = if (id == chatId) {
            ChatSession(id = chatId, title = titleOf(_chat.value), items = _chat.value,
                history = history.toList(), customTitle = customTitle, pinned = pinned)
        } else {
            _sessions.value.firstOrNull { it.id == id }
        }
        return s?.let { chatStore.encode(it) }
    }

    /** Imports a chat exported from this app as a new chat and opens it. */
    fun importChat(text: String): Boolean {
        if (_busy.value) return false
        val parsed = runCatching { chatStore.decode(text) }.getOrNull() ?: return false
        if (parsed.items.isEmpty()) return false
        val fresh = parsed.copy(id = UUID.randomUUID().toString(), updatedAt = System.currentTimeMillis())
        chatStore.save(fresh)
        _sessions.value = sortSessions(listOf(fresh) + _sessions.value)
        restore(fresh)
        log("Imported chat")
        return true
    }

    /** Runs a shell command in the workspace folder and returns its output to the caller. */
    fun runTerminal(cmd: String, onDone: (String) -> Unit) {
        viewModelScope.launch {
            val r = withContext(Dispatchers.IO) {
                ActionExecutor(getApplication(), _settings.value.workspacePath, ghAuth())
                    .execute(ActionItem(kind = "command", target = cmd))
            }
            log("Terminal: ${cmd.take(60)} -> ${r.status}")
            onDone(r.output)
        }
    }

    // ---------- Actions ----------

    fun approveAction(item: ActionItem) {
        setActionState(item.id, "running", "")
        viewModelScope.launch {
            val result = withContext(Dispatchers.IO) {
                ActionExecutor(getApplication(), _settings.value.workspacePath, ghAuth()).execute(item)
            }
            setActionState(item.id, result.status, result.output)
            log("Action ${result.kind} -> ${result.status}: ${result.target.take(80)}")
        }
    }

    fun rejectAction(item: ActionItem) {
        setActionState(item.id, "rejected", "Rejected by user")
        log("Rejected ${item.kind}: ${item.target.take(80)}")
    }

    private fun ghAuth(): GhAuth? {
        val s = _settings.value
        return if (s.githubToken.isBlank()) null else GhAuth(s.githubToken, s.githubLogin)
    }

    /** Current date, time and weather, added to the system prompt so the AI can use them. */
    private suspend fun buildInfo(s: Settings): String {
        val now = SimpleDateFormat("EEEE, d MMMM yyyy, HH:mm (zzz)", Locale.ENGLISH).format(Date())
        val lines = mutableListOf("Current time: $now")
        if (s.weatherCity.isNotBlank()) {
            val weather = withContext(Dispatchers.IO) {
                runCatching { Weather.fetch(s.weatherCity) }.getOrElse { "Weather unavailable" }
            }
            lines += "Weather in ${s.weatherCity}: $weather"
        }
        return lines.joinToString("\n")
    }

    /**
     * Connects GitHub with the OAuth device flow. onCode shows the code to type on github.com,
     * onDone receives an error message, or an empty string on success.
     */
    fun connectGithub(onCode: (DeviceCode) -> Unit, onDone: (String) -> Unit) {
        val clientId = _settings.value.githubClientId.trim()
        if (clientId.isEmpty()) {
            onDone("Paste the OAuth App Client ID first")
            return
        }
        viewModelScope.launch {
            try {
                val code = withContext(Dispatchers.IO) { GitHub.startDeviceFlow(clientId) }
                onCode(code)
                var interval = code.interval.coerceAtLeast(1) * 1000L
                val deadline = System.currentTimeMillis() + code.expiresIn * 1000L
                var token: String? = null
                while (token == null) {
                    if (System.currentTimeMillis() > deadline) throw IllegalStateException("Code expired, try again")
                    delay(interval)
                    when (val r = withContext(Dispatchers.IO) { GitHub.pollToken(clientId, code.deviceCode) }) {
                        is PollResult.Token -> token = r.token
                        PollResult.Pending -> Unit
                        PollResult.SlowDown -> interval += 5_000L
                        is PollResult.Error -> throw IllegalStateException(r.message)
                    }
                }
                val login = withContext(Dispatchers.IO) { GitHub.login(token) }
                commit(_settings.value.copy(githubToken = token, githubLogin = login))
                log("GitHub connected as $login")
                onDone("")
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                onDone(e.message ?: e.toString())
            }
        }
    }

    fun disconnectGithub() {
        commit(_settings.value.copy(githubToken = "", githubLogin = ""))
        log("GitHub disconnected")
    }

    /** Translates text with the active model. Calls onDone with the result or an error prefixed by "!". */
    fun translate(text: String, language: String, onDone: (String) -> Unit) {
        val s = _settings.value
        val profile = s.profiles.firstOrNull { it.id == s.activeId && it.enabled && it.apiKey.isNotBlank() }
            ?: s.profiles.firstOrNull { it.enabled && it.apiKey.isNotBlank() }
        if (profile == null) {
            onDone("!No enabled profile with an API key")
            return
        }
        viewModelScope.launch {
            try {
                val reply = ApiClient.chat(
                    profile,
                    listOf(
                        ChatMessage("system", "You are a translator. Translate the user's text into $language. Output only the translation, no notes."),
                        ChatMessage("user", text),
                    ),
                    effort = "low",
                )
                onDone(reply.content.trim())
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                onDone("!" + (e.message ?: e.toString()))
            }
        }
    }

    private fun setActionState(id: String, status: String, output: String) {
        _chat.value = _chat.value.map { c ->
            val a = c.action
            if (c.id == id && a != null) c.copy(action = a.copy(status = status, output = output)) else c
        }
        persist()
    }
}
