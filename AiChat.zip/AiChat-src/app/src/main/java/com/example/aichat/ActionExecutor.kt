package com.example.aichat

import android.content.Context
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.TimeUnit

/** Runs AI actions inside the workspace folder chosen in Settings. */
class ActionExecutor(
    private val context: Context,
    workspacePath: String,
    private val gh: GhAuth? = null,
) {

    val workspace: File = File(workspacePath.trim().ifEmpty { File(context.filesDir, "workspace").path })

    /** Returns an error message if the workspace cannot be used, otherwise null. */
    private fun workspaceError(): String? {
        val isPrivate = workspace.canonicalPath.startsWith(context.filesDir.canonicalPath)
        if (!isPrivate && !Perms.hasFileAccess(context)) {
            return "No file access. Allow it in Settings > File access and workspace."
        }
        return if (workspace.isDirectory || workspace.mkdirs()) null
        else "Cannot create workspace folder: ${workspace.path}"
    }

    private fun safeFile(rel: String): File {
        val root = workspace.canonicalFile
        val target = File(root, rel).canonicalFile
        require(target == root || target.path.startsWith(root.path + File.separator)) {
            "Path escapes workspace: $rel"
        }
        return target
    }

    fun execute(item: ActionItem): ActionItem {
        workspaceError()?.let { return item.copy(status = "error", output = it) }
        return try {
            when (item.kind) {
                "command" -> runCommand(item)
                "mkdir" -> {
                    safeFile(item.target).mkdirs()
                    item.copy(status = "done", output = "Created folder ${item.target}")
                }
                "write" -> {
                    val file = safeFile(item.target)
                    file.parentFile?.mkdirs()
                    file.writeText(item.content)
                    item.copy(status = "done", output = "Wrote ${item.content.length} chars to ${item.target}")
                }
                "ghrepo" -> {
                    val auth = gh ?: return item.copy(status = "error", output = "Connect GitHub in Settings first")
                    val url = GitHub.createRepo(auth.token, item.target)
                    item.copy(status = "done", output = "Repository created: $url")
                }
                "ghfile" -> {
                    val auth = gh ?: return item.copy(status = "error", output = "Connect GitHub in Settings first")
                    val repo = item.target.substringBefore(':')
                    val path = item.target.substringAfter(':')
                    val url = GitHub.putFile(auth.token, auth.login, repo, path, item.content, "Update $path")
                    item.copy(status = "done", output = "Saved $path to $repo $url")
                }
                "python" -> {
                    val out = PyRun.run(context, item.content, workspace.path)
                    val failed = out.contains("Traceback")
                    item.copy(
                        status = if (failed) "error" else "done",
                        output = out.takeLast(4_000).ifBlank { "(no output)" },
                    )
                }
                "fetch" -> item.copy(status = "done", output = fetchUrl(item.target))
                else -> item.copy(status = "error", output = "Unknown action: ${item.kind}")
            }
        } catch (e: Exception) {
            item.copy(status = "error", output = e.message ?: e.toString())
        }
    }

    /** Downloads a page and returns its status and the first part of its text. */
    private fun fetchUrl(url: String): String {
        require(url.startsWith("https://") || url.startsWith("http://")) { "Only http and https links are allowed" }
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.connectTimeout = 15_000
        conn.readTimeout = 20_000
        conn.setRequestProperty("User-Agent", "DeadCode-Android")
        return try {
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val body = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            "HTTP $code\n" + body.take(6_000)
        } finally {
            conn.disconnect()
        }
    }

    private fun runCommand(item: ActionItem): ActionItem {
        val proc = ProcessBuilder("/system/bin/sh", "-c", item.target)
            .directory(workspace)
            .redirectErrorStream(true)
            .start()

        val buffer = StringBuilder()
        val reader = Thread { buffer.append(proc.inputStream.bufferedReader().readText()) }
        reader.start()

        val finished = proc.waitFor(60, TimeUnit.SECONDS)
        if (!finished) proc.destroyForcibly()
        reader.join(2_000)

        val text = buffer.toString().takeLast(4_000).ifBlank { "(no output)" }
        return if (!finished) {
            item.copy(status = "error", output = "Timed out after 60 s\n$text")
        } else {
            val code = proc.exitValue()
            item.copy(
                status = if (code == 0) "done" else "error",
                output = "exit $code\n$text",
            )
        }
    }
}
