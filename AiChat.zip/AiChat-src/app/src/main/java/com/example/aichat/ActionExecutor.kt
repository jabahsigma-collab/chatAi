package com.example.aichat

import android.content.Context
import java.io.File
import java.util.concurrent.TimeUnit

/** Runs actions only inside the app's private workspace folder. */
class ActionExecutor(context: Context) {

    val workspace: File = File(context.filesDir, "workspace").apply { mkdirs() }

    private fun safeFile(rel: String): File {
        val root = workspace.canonicalFile
        val target = File(root, rel).canonicalFile
        require(target == root || target.path.startsWith(root.path + File.separator)) {
            "Path escapes workspace: $rel"
        }
        return target
    }

    fun execute(item: ActionItem): ActionItem = try {
        when (item.kind) {
            "command" -> runCommand(item)
            "mkdir" -> {
                safeFile(item.target).mkdirs()
                item.copy(status = "done", output = "Created folder ${item.target}")
            }
            "write" -> {
                val file = safeFile(item.target)
                file.parentFile?.mkdirs()
                file.writeText(item.content)
                item.copy(status = "done", output = "Wrote ${item.content.length} chars to ${item.target}")
            }
            else -> item.copy(status = "error", output = "Unknown action: ${item.kind}")
        }
    } catch (e: Exception) {
        item.copy(status = "error", output = e.message ?: e.toString())
    }

    private fun runCommand(item: ActionItem): ActionItem {
        val proc = ProcessBuilder("/system/bin/sh", "-c", item.target)
            .directory(workspace)
            .redirectErrorStream(true)
            .start()

        val buffer = StringBuilder()
        val reader = Thread { buffer.append(proc.inputStream.bufferedReader().readText()) }
        reader.start()

        val finished = proc.waitFor(60, TimeUnit.SECONDS)
        if (!finished) proc.destroyForcibly()
        reader.join(2_000)

        val text = buffer.toString().takeLast(4_000).ifBlank { "(no output)" }
        return if (!finished) {
            item.copy(status = "error", output = "Timed out after 60 s\n$text")
        } else {
            val ok = proc.exitValue() == 0
            item.copy(
                status = if (ok) "done" else "error",
                output = "exit ${proc.exitValue()}\n$text",
            )
        }
    }
}
