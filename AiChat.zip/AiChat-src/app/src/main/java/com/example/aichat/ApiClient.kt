package com.example.aichat

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

data class PingResult(
    val ok: Boolean,
    val status: Int,
    val latencyMs: Long,
    val models: List<String>,
    val message: String,
)

/** kind: "image" (base64 jpeg), "audio" (base64), or "text" (plain text included in the prompt). */
data class Attachment(val name: String, val kind: String, val mime: String, val data: String)

data class ChatMessage(val role: String, val text: String, val attachments: List<Attachment> = emptyList())

data class ModelReply(
    val content: String,
    val reasoning: String,
    val promptTokens: Int = 0,
    val completionTokens: Int = 0,
)

object ApiClient {

    private val THINK_REGEX = Regex("<think>([\\s\\S]*?)</think>")

    /**
     * Splits raw text into (answer, thinking). Works while streaming: an unclosed <think> block
     * counts as thinking so far, and text before a lone </think> counts as thinking too.
     */
    fun splitThink(raw: String): Pair<String, String> {
        val thinking = mutableListOf<String>()
        var answer = THINK_REGEX.replace(raw) { m -> thinking += m.groupValues[1].trim(); "" }
        val close = answer.indexOf("</think>")
        if (close >= 0) {
            thinking += answer.substring(0, close).trim()
            answer = answer.substring(close + "</think>".length)
        }
        val open = answer.indexOf("<think>")
        if (open >= 0) {
            thinking += answer.substring(open + "<think>".length).trim()
            answer = answer.substring(0, open)
        }
        return answer.trim() to thinking.filter { it.isNotBlank() }.joinToString("\n\n")
    }

    private fun open(url: String, method: String, apiKey: String, body: String?, timeoutMs: Int): HttpURLConnection {
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = method
            connectTimeout = timeoutMs
            readTimeout = timeoutMs
            doInput = true
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("Accept", "application/json")
            if (apiKey.isNotBlank()) setRequestProperty("Authorization", "Bearer $apiKey")
        }
        if (body != null) {
            conn.doOutput = true
            conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        }
        return conn
    }

    private fun request(url: String, method: String, apiKey: String, body: String?, timeoutMs: Int): Pair<Int, String> {
        val conn = open(url, method, apiKey, body, timeoutMs)
        return try {
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
            code to text
        } finally {
            conn.disconnect()
        }
    }

    private fun parseModels(text: String): List<String> {
        return try {
            val arr: JSONArray = if (text.trimStart().startsWith("[")) {
                JSONArray(text)
            } else {
                val root = JSONObject(text)
                root.optJSONArray("data") ?: root.optJSONArray("models") ?: JSONArray()
            }
            (0 until arr.length()).mapNotNull { i ->
                when (val item = arr.get(i)) {
                    is JSONObject -> item.optString("id").ifEmpty { item.optString("name") }.ifEmpty { null }
                    is String -> item
                    else -> null
                }
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    suspend fun ping(baseUrl: String, apiKey: String): PingResult = withContext(Dispatchers.IO) {
        val start = System.currentTimeMillis()
        try {
            val (code, text) = request(baseUrl.trimEnd('/') + "/models", "GET", apiKey, null, 20_000)
            val latency = System.currentTimeMillis() - start
            if (code !in 200..299) {
                PingResult(false, code, latency, emptyList(), text.take(300))
            } else {
                PingResult(true, code, latency, parseModels(text), "OK")
            }
        } catch (e: Exception) {
            PingResult(false, 0, System.currentTimeMillis() - start, emptyList(), e.message ?: "Network error")
        }
    }

    /** Builds the "content" field: plain string, or a parts array when images/audio are attached. */
    private fun contentOf(m: ChatMessage): Any {
        if (m.attachments.isEmpty()) return m.text
        val textBuilder = StringBuilder(m.text)
        val parts = JSONArray()
        m.attachments.forEach { a ->
            when (a.kind) {
                "text" -> textBuilder.append("\n\n[File: ${a.name}]\n${a.data}")
                "image" -> parts.put(
                    JSONObject().put("type", "image_url")
                        .put("image_url", JSONObject().put("url", "data:${a.mime};base64,${a.data}"))
                )
                "audio" -> {
                    val format = when (val f = a.mime.substringAfter('/')) {
                        "mpeg" -> "mp3"
                        else -> f
                    }
                    parts.put(
                        JSONObject().put("type", "input_audio")
                            .put("input_audio", JSONObject().put("data", a.data).put("format", format))
                    )
                }
            }
        }
        parts.put(0, JSONObject().put("type", "text").put("text", textBuilder.toString()))
        return parts
    }

    private fun buildBody(profile: Profile, messages: List<ChatMessage>, effort: String, stream: Boolean): String {
        val msgArr = JSONArray()
        messages.forEach { m ->
            msgArr.put(JSONObject().put("role", m.role).put("content", contentOf(m)))
        }
        val level = if (effort == "max") "high" else effort
        val o = JSONObject()
            .put("model", profile.model)
            .put("messages", msgArr)
            .put("reasoning_effort", level)
        if (stream) {
            o.put("stream", true)
            o.put("stream_options", JSONObject().put("include_usage", true))
        }
        return o.toString()
    }

    /** Full (non-streaming) reply. */
    suspend fun chat(profile: Profile, messages: List<ChatMessage>, effort: String = "medium"): ModelReply = withContext(Dispatchers.IO) {
        val body = buildBody(profile, messages, effort, stream = false)
        val (code, text) = request(
            profile.baseUrl.trimEnd('/') + "/chat/completions",
            "POST", profile.apiKey, body, 120_000
        )
        if (code !in 200..299) {
            throw IllegalStateException("HTTP $code: ${text.take(300)}")
        }
        val root = try {
            JSONObject(text)
        } catch (e: Exception) {
            throw IllegalStateException("Unexpected response shape from provider")
        }
        val message = try {
            root.getJSONArray("choices").getJSONObject(0).getJSONObject("message")
        } catch (e: Exception) {
            throw IllegalStateException("Unexpected response shape from provider")
        }
        val usage = root.optJSONObject("usage")
        val raw = message.optString("content")
        val inlineThink = THINK_REGEX.findAll(raw).joinToString("\n\n") { it.groupValues[1].trim() }
        val field = message.optString("reasoning_content").ifEmpty { message.optString("reasoning") }
        val reasoning = listOf(field, inlineThink).filter { it.isNotBlank() }.joinToString("\n\n").trim()
        ModelReply(
            raw.replace(THINK_REGEX, "").trim(),
            reasoning,
            usage?.optInt("prompt_tokens", 0) ?: 0,
            usage?.optInt("completion_tokens", 0) ?: 0,
        )
    }

    /**
     * Streamed reply (server-sent events). onUpdate receives the full text and reasoning so far.
     * Cancelling the calling coroutine stops reading.
     */
    suspend fun chatStream(
        profile: Profile,
        messages: List<ChatMessage>,
        effort: String,
        onUpdate: (content: String, reasoning: String) -> Unit,
    ): ModelReply = withContext(Dispatchers.IO) {
        val body = buildBody(profile, messages, effort, stream = true)
        val conn = open(profile.baseUrl.trimEnd('/') + "/chat/completions", "POST", profile.apiKey, body, 120_000)
        try {
            val code = conn.responseCode
            if (code !in 200..299) {
                val err = conn.errorStream?.bufferedReader()?.use { it.readText() } ?: ""
                throw IllegalStateException("HTTP $code: ${err.take(300)}")
            }
            val content = StringBuilder()
            val reasoningSb = StringBuilder()
            var promptTok = 0
            var completionTok = 0
            conn.inputStream.bufferedReader().use { reader ->
                while (true) {
                    currentCoroutineContext().ensureActive()
                    val line = reader.readLine() ?: break
                    if (!line.startsWith("data:")) continue
                    val payload = line.removePrefix("data:").trim()
                    if (payload == "[DONE]") break
                    val obj = runCatching { JSONObject(payload) }.getOrNull() ?: continue
                    obj.optJSONObject("usage")?.let { u ->
                        promptTok = u.optInt("prompt_tokens", promptTok)
                        completionTok = u.optInt("completion_tokens", completionTok)
                    }
                    val choices = obj.optJSONArray("choices") ?: continue
                    if (choices.length() == 0) continue
                    val delta = choices.getJSONObject(0).optJSONObject("delta") ?: continue
                    val piece = delta.optString("content")
                    if (piece.isNotEmpty()) content.append(piece)
                    val r = delta.optString("reasoning_content").ifEmpty { delta.optString("reasoning") }
                    if (r.isNotEmpty()) reasoningSb.append(r)
                    if (piece.isNotEmpty() || r.isNotEmpty()) {
                        val (answer, inline) = splitThink(content.toString())
                        val thinking = listOf(reasoningSb.toString(), inline).filter { it.isNotBlank() }.joinToString("\n\n")
                        onUpdate(answer, thinking)
                    }
                }
            }
            val (answer, inline) = splitThink(content.toString())
            val reasoning = listOf(reasoningSb.toString(), inline).filter { it.isNotBlank() }.joinToString("\n\n").trim()
            ModelReply(answer, reasoning, promptTok, completionTok)
        } finally {
            conn.disconnect()
        }
    }
}
