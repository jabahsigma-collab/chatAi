package com.example.aichat

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

data class PingResult(
    val ok: Boolean,
    val status: Int,
    val latencyMs: Long,
    val models: List<String>,
    val message: String,
)

/** kind: "image" (base64 jpeg), "audio" (base64), or "text" (plain text included in the prompt). */
data class Attachment(val name: String, val kind: String, val mime: String, val data: String)

data class ChatMessage(val role: String, val text: String, val attachments: List<Attachment> = emptyList())

data class ModelReply(val content: String, val reasoning: String)

object ApiClient {

    private val THINK_REGEX = Regex("<think>([\\s\\S]*?)</think>")

    private fun request(
        url: String,
        method: String,
        apiKey: String,
        body: String?,
        timeoutMs: Int,
    ): Pair<Int, String> {
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = method
            connectTimeout = timeoutMs
            readTimeout = timeoutMs
            doInput = true
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("Accept", "application/json")
            if (apiKey.isNotBlank()) setRequestProperty("Authorization", "Bearer $apiKey")
            if (body != null) {
                doOutput = true
                outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            }
        }
        return try {
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
            code to text
        } finally {
            conn.disconnect()
        }
    }

    private fun parseModels(text: String): List<String> {
        return try {
            val arr: JSONArray = if (text.trimStart().startsWith("[")) {
                JSONArray(text)
            } else {
                val root = JSONObject(text)
                root.optJSONArray("data") ?: root.optJSONArray("models") ?: JSONArray()
            }
            (0 until arr.length()).mapNotNull { i ->
                when (val item = arr.get(i)) {
                    is JSONObject -> item.optString("id").ifEmpty { item.optString("name") }.ifEmpty { null }
                    is String -> item
                    else -> null
                }
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    suspend fun ping(baseUrl: String, apiKey: String): PingResult = withContext(Dispatchers.IO) {
        val start = System.currentTimeMillis()
        try {
            val (code, text) = request(baseUrl.trimEnd('/') + "/models", "GET", apiKey, null, 20_000)
            val latency = System.currentTimeMillis() - start
            if (code !in 200..299) {
                PingResult(false, code, latency, emptyList(), text.take(300))
            } else {
                PingResult(true, code, latency, parseModels(text), "OK")
            }
        } catch (e: Exception) {
            PingResult(false, 0, System.currentTimeMillis() - start, emptyList(), e.message ?: "Network error")
        }
    }

    /** Builds the "content" field: plain string, or a parts array when images/audio are attached. */
    private fun contentOf(m: ChatMessage): Any {
        if (m.attachments.isEmpty()) return m.text
        val textBuilder = StringBuilder(m.text)
        val parts = JSONArray()
        m.attachments.forEach { a ->
            when (a.kind) {
                "text" -> textBuilder.append("\n\n[File: ${a.name}]\n${a.data}")
                "image" -> parts.put(
                    JSONObject().put("type", "image_url")
                        .put("image_url", JSONObject().put("url", "data:${a.mime};base64,${a.data}"))
                )
                "audio" -> {
                    val format = when (val f = a.mime.substringAfter('/')) {
                        "mpeg" -> "mp3"
                        else -> f
                    }
                    parts.put(
                        JSONObject().put("type", "input_audio")
                            .put("input_audio", JSONObject().put("data", a.data).put("format", format))
                    )
                }
            }
        }
        parts.put(0, JSONObject().put("type", "text").put("text", textBuilder.toString()))
        return parts
    }

    suspend fun chat(profile: Profile, messages: List<ChatMessage>, effort: String = "medium"): ModelReply = withContext(Dispatchers.IO) {
        val msgArr = JSONArray()
        messages.forEach { m ->
            msgArr.put(JSONObject().put("role", m.role).put("content", contentOf(m)))
        }
        val level = if (effort == "max") "high" else effort
        val body = JSONObject().put("model", profile.model).put("messages", msgArr).put("reasoning_effort", level).toString()

        val (code, text) = request(
            profile.baseUrl.trimEnd('/') + "/chat/completions",
            "POST", profile.apiKey, body, 120_000
        )
        if (code !in 200..299) {
            throw IllegalStateException("HTTP $code: ${text.take(300)}")
        }
        val message = try {
            JSONObject(text).getJSONArray("choices").getJSONObject(0).getJSONObject("message")
        } catch (e: Exception) {
            throw IllegalStateException("Unexpected response shape from provider")
        }
        val raw = message.optString("content")
        val inlineThink = THINK_REGEX.findAll(raw).joinToString("\n\n") { it.groupValues[1].trim() }
        val field = message.optString("reasoning_content").ifEmpty { message.optString("reasoning") }
        val reasoning = listOf(field, inlineThink).filter { it.isNotBlank() }.joinToString("\n\n").trim()
        ModelReply(raw.replace(THINK_REGEX, "").trim(), reasoning)
    }
}
