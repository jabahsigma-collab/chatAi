package com.example.aichat

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

data class PingResult(
    val ok: Boolean,
    val status: Int,
    val latencyMs: Long,
    val models: List<String>,
    val message: String,
)

object ApiClient {

    private fun request(
        url: String,
        method: String,
        apiKey: String,
        body: String?,
        timeoutMs: Int,
    ): Pair<Int, String> {
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = method
            connectTimeout = timeoutMs
            readTimeout = timeoutMs
            doInput = true
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("Accept", "application/json")
            if (apiKey.isNotBlank()) setRequestProperty("Authorization", "Bearer $apiKey")
            if (body != null) {
                doOutput = true
                outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            }
        }
        return try {
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
            code to text
        } finally {
            conn.disconnect()
        }
    }

    private fun parseModels(text: String): List<String> {
        return try {
            val arr: JSONArray = if (text.trimStart().startsWith("[")) {
                JSONArray(text)
            } else {
                val root = JSONObject(text)
                root.optJSONArray("data") ?: root.optJSONArray("models") ?: JSONArray()
            }
            (0 until arr.length()).mapNotNull { i ->
                when (val item = arr.get(i)) {
                    is JSONObject -> item.optString("id").ifEmpty { item.optString("name") }.ifEmpty { null }
                    is String -> item
                    else -> null
                }
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    suspend fun ping(baseUrl: String, apiKey: String): PingResult = withContext(Dispatchers.IO) {
        val start = System.currentTimeMillis()
        try {
            val (code, text) = request(
                baseUrl.trimEnd('/') + "/models", "GET", apiKey, null, 20_000
            )
            val latency = System.currentTimeMillis() - start
            if (code !in 200..299) {
                PingResult(false, code, latency, emptyList(), text.take(300))
            } else {
                PingResult(true, code, latency, parseModels(text), "OK")
            }
        } catch (e: Exception) {
            PingResult(false, 0, System.currentTimeMillis() - start, emptyList(),
                e.message ?: "Network error")
        }
    }

    suspend fun chat(profile: Profile, messages: List<Pair<String, String>>): String =
        withContext(Dispatchers.IO) {
            val msgArr = JSONArray()
            messages.forEach { (role, content) ->
                msgArr.put(JSONObject().put("role", role).put("content", content))
            }
            val body = JSONObject()
                .put("model", profile.model)
                .put("messages", msgArr)
                .toString()

            val (code, text) = request(
                profile.baseUrl.trimEnd('/') + "/chat/completions",
                "POST", profile.apiKey, body, 120_000
            )
            if (code !in 200..299) {
                throw IllegalStateException("HTTP $code: ${text.take(300)}")
            }
            try {
                JSONObject(text).getJSONArray("choices")
                    .getJSONObject(0).getJSONObject("message").optString("content")
            } catch (e: Exception) {
                throw IllegalStateException("Unexpected response shape from provider")
            }
        }
}
