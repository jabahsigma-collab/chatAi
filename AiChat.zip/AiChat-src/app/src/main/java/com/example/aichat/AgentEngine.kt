package com.example.aichat

import java.util.UUID

data class ActionItem(
    val id: String = UUID.randomUUID().toString(),
    val kind: String,               // command | mkdir | write
    val target: String,             // command text or relative path
    val content: String = "",       // file content for write
    val status: String = "pending", // pending | running | done | error | rejected
    val output: String = "",
)

fun ActionItem.describe(): String = when (kind) {
    "command" -> "$ $target"
    "mkdir" -> "mkdir $target"
    "write" -> "write $target\n\n$content"
    else -> target
}

data class ChatTurn(val role: String, val content: String)

data class AgentStep(
    val agent: String,
    val profileName: String,
    val model: String,
    val text: String,
    val reasoning: String,
)

data class TurnResult(
    val text: String,
    val reasoning: String,
    val profileName: String,
    val model: String,
    val steps: List<AgentStep>,
    val actions: List<ActionItem>,
)

object AgentEngine {

    private val ACTION_REGEX = Regex("""```action:(command|mkdir|write)(?::([^\n]*))?\n([\s\S]*?)```""")

    val SYSTEM_PROMPT = """
You are a coding assistant working in a local workspace on an Android device. You can change the workspace by emitting these fenced blocks:
```action:command
<shell command, runs with /system/bin/sh inside the workspace>
```
```action:mkdir:relative/path
```
```action:write:relative/path/file.ext
<file contents>
```
Paths are relative to the workspace. Explain briefly what you do.
Do not claim an action ran until its result is reported.
""".trimIndent()

    /** Startup prompt (new chat only) and enabled skills, appended to the system prompt. */
    fun extraSystem(settings: Settings, startup: Boolean): String {
        val parts = mutableListOf<String>()
        if (startup && settings.startupPrompt.isNotBlank()) {
            parts += "Instructions for this chat:\n" + settings.startupPrompt.trim()
        }
        settings.skills.filter { it.enabled && it.text.isNotBlank() }.forEach {
            parts += "Skill: ${it.name}\n${it.text.trim()}"
        }
        return if (parts.isEmpty()) "" else "\n\n" + parts.joinToString("\n\n")
    }

    fun extractActions(text: String): List<ActionItem> {
        return ACTION_REGEX.findAll(text).mapNotNull { m ->
            val kind = m.groupValues[1]
            val arg = m.groupValues[2].trim()
            val body = m.groupValues[3].trimEnd('\n')
            when (kind) {
                "command" -> if (body.isNotBlank()) ActionItem(kind = "command", target = body.trim()) else null
                "mkdir" -> if (arg.isNotEmpty()) ActionItem(kind = "mkdir", target = arg) else null
                "write" -> if (arg.isNotEmpty()) ActionItem(kind = "write", target = arg, content = body) else null
                else -> null
            }
        }.toList()
    }

    /**
     * Tries the preferred profile first.
     *  - Toggle 1 (failoverKeys): other enabled profiles with the same base URL (other keys).
     *  - Toggle 2 (failoverModels): any other enabled profile (other model or provider).
     */
    suspend fun callWithFailover(
        settings: Settings,
        preferredId: String?,
        messages: List<ChatMessage>,
        log: (String) -> Unit,
    ): Pair<Profile, ModelReply> {
        val enabled = settings.profiles.filter { it.enabled }
        if (enabled.isEmpty()) throw IllegalStateException("No enabled profiles. Add one in Settings.")
        val primary = enabled.firstOrNull { it.id == preferredId } ?: enabled.first()

        val order = mutableListOf(primary)
        if (settings.failoverKeys) {
            order += enabled.filter { it !== primary && it.baseUrl == primary.baseUrl }
        }
        if (settings.failoverModels) {
            order += enabled.filter { it !in order }
        }

        var lastError = "No attempt made"
        for (p in order) {
            try {
                log("Calling ${p.name} / ${p.model} (effort ${settings.effort})")
                return p to ApiClient.chat(p, messages, settings.effort)
            } catch (e: Exception) {
                lastError = e.message ?: e.toString()
                log("Failed ${p.name} / ${p.model}: ${lastError.take(160)}")
            }
        }
        throw IllegalStateException("All attempts failed. Last error: $lastError")
    }

    suspend fun runTurn(
        settings: Settings,
        multiAgent: Boolean,
        message: String,
        attachments: List<Attachment>,
        history: List<ChatTurn>,
        startup: Boolean,
        log: (String) -> Unit,
    ): TurnResult {
        val historyMsgs = history.map { ChatMessage(it.role, it.content) }
        val extra = extraSystem(settings, startup)

        if (!multiAgent) {
            val msgs = listOf(ChatMessage("system", SYSTEM_PROMPT + extra)) +
                historyMsgs + ChatMessage("user", message, attachments)
            val (p, reply) = callWithFailover(settings, settings.activeId, msgs, log)
            return TurnResult(
                text = reply.content,
                reasoning = reply.reasoning,
                profileName = p.name,
                model = p.model,
                steps = emptyList(),
                actions = extractActions(reply.content),
            )
        }

        val roles = listOf(
            Triple("planner", settings.agents.planner,
                "You are the Planner/Architect. Break the task into concrete numbered steps. Do not write code."),
            Triple("coder", settings.agents.coder,
                "You are the Coder. Implement the plan. Use action blocks to write files or run commands."),
            Triple("reviewer", settings.agents.reviewer,
                "You are the Reviewer/Tester. Check the work for bugs and missing parts. Be concise."),
        )

        val steps = mutableListOf<AgentStep>()
        val actions = mutableListOf<ActionItem>()
        var context = message

        for ((role, assigned, instruction) in roles) {
            val msgs = listOf(ChatMessage("system", instruction + "\n\n" + SYSTEM_PROMPT + extra)) +
                historyMsgs + ChatMessage("user", context, attachments)
            val (p, reply) = callWithFailover(settings, assigned ?: settings.activeId, msgs, log)
            actions += extractActions(reply.content)
            steps += AgentStep(role, p.name, p.model, reply.content, reply.reasoning)
            context = "Previous $role output:\n${reply.content}\n\nOriginal task: $message"
        }

        val last = steps.last()
        return TurnResult(last.text, last.reasoning, last.profileName, last.model, steps, actions)
    }
}
