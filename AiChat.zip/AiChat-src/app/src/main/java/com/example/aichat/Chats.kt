package com.example.aichat

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

/** One saved chat. Stored as a JSON file per chat in filesDir/chats. */
data class ChatSession(
    val id: String = UUID.randomUUID().toString(),
    val title: String = "New chat",
    val updatedAt: Long = System.currentTimeMillis(),
    val items: List<ChatItem> = emptyList(),
    val history: List<ChatTurn> = emptyList(),
    val customTitle: String? = null,  // set by the user; overrides the automatic title
    val pinned: Boolean = false,
)

class ChatStore(context: Context) {
    private val dir = File(context.filesDir, "chats").apply { mkdirs() }

    fun list(): List<ChatSession> =
        dir.listFiles()
            ?.filter { it.extension == "json" }
            ?.mapNotNull { f -> runCatching { fromJson(JSONObject(f.readText())) }.getOrNull() }
            ?.sortedByDescending { it.updatedAt }
            ?: emptyList()

    fun save(s: ChatSession) {
        runCatching { File(dir, "${s.id}.json").writeText(toJson(s).toString()) }
    }

    fun delete(id: String) {
        File(dir, "$id.json").delete()
    }

    /** Text form of a chat, used for export. */
    fun encode(s: ChatSession): String = toJson(s).toString()

    /** Parses a chat exported with encode(). Throws on bad input. */
    fun decode(text: String): ChatSession = fromJson(JSONObject(text))

    private fun actionToJson(a: ActionItem): JSONObject =
        JSONObject()
            .put("id", a.id)
            .put("kind", a.kind)
            .put("target", a.target)
            .put("content", a.content)
            .put("status", a.status)
            .put("output", a.output)

    private fun actionFromJson(o: JSONObject): ActionItem {
        val status = o.optString("status", "pending")
        // An action that was still waiting or running when the app closed is not run again.
        val restored = status == "pending" || status == "running"
        return ActionItem(
            id = o.optString("id"),
            kind = o.optString("kind"),
            target = o.optString("target"),
            content = o.optString("content"),
            status = if (restored) "rejected" else status,
            output = if (restored) "Not run: the app was closed before it was confirmed" else o.optString("output"),
        )
    }

    private fun attachmentToJson(a: Attachment): JSONObject =
        JSONObject().put("name", a.name).put("kind", a.kind).put("mime", a.mime).put("data", a.data)

    private fun attachmentFromJson(o: JSONObject): Attachment =
        Attachment(o.optString("name"), o.optString("kind"), o.optString("mime"), o.optString("data"))

    private fun toJson(s: ChatSession): JSONObject {
        val items = JSONArray()
        s.items.forEach { c ->
            val o = JSONObject()
                .put("id", c.id)
                .put("kind", c.kind)
                .put("meta", c.meta)
                .put("text", c.text)
                .put("reasoning", c.reasoning)
                .put("inTok", c.inTok)
                .put("outTok", c.outTok)
                .put("cost", c.cost)
            c.action?.let { o.put("action", actionToJson(it)) }
            val att = JSONArray()
            c.attachments.forEach { att.put(attachmentToJson(it)) }
            o.put("attachments", att)
            items.put(o)
        }
        val hist = JSONArray()
        s.history.forEach { hist.put(JSONObject().put("role", it.role).put("content", it.content)) }
        return JSONObject()
            .put("id", s.id)
            .put("title", s.title)
            .put("updatedAt", s.updatedAt)
            .put("items", items)
            .put("history", hist)
            .put("customTitle", s.customTitle ?: "")
            .put("pinned", s.pinned)
    }

    private fun fromJson(o: JSONObject): ChatSession {
        val ia = o.optJSONArray("items") ?: JSONArray()
        val items = List(ia.length()) { i ->
            val c = ia.getJSONObject(i)
            val aa = c.optJSONArray("attachments") ?: JSONArray()
            ChatItem(
                id = c.optString("id"),
                kind = c.optString("kind"),
                meta = c.optString("meta"),
                text = c.optString("text"),
                reasoning = c.optString("reasoning"),
                action = c.optJSONObject("action")?.let { actionFromJson(it) },
                attachments = List(aa.length()) { j -> attachmentFromJson(aa.getJSONObject(j)) },
                inTok = c.optInt("inTok", 0),
                outTok = c.optInt("outTok", 0),
                cost = c.optDouble("cost", 0.0),
            )
        }
        val ha = o.optJSONArray("history") ?: JSONArray()
        val history = List(ha.length()) { i ->
            val h = ha.getJSONObject(i)
            ChatTurn(h.optString("role"), h.optString("content"))
        }
        return ChatSession(
            id = o.optString("id"),
            title = o.optString("title", "New chat"),
            updatedAt = o.optLong("updatedAt", System.currentTimeMillis()),
            items = items,
            history = history,
            customTitle = o.optString("customTitle").ifEmpty { null },
            pinned = o.optBoolean("pinned", false),
        )
    }
}
