package com.example.aichat

import android.content.Context
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform

/**
 * Runs Python with the embedded Chaquopy interpreter. Packages are fixed at build time
 * (see the chaquopy block in app/build.gradle.kts); they cannot be installed at runtime.
 */
object PyRun {
    private val lock = Any()

    /** Runs code with the workspace as the current folder and returns everything it printed. */
    fun run(ctx: Context, code: String, workdir: String): String = synchronized(lock) {
        if (!Python.isStarted()) Python.start(AndroidPlatform(ctx))
        val py = Python.getInstance()
        val sys = py.getModule("sys")
        val io = py.getModule("io")
        val builtins = py.getBuiltinModule("builtins")
        val buffer = io.callAttr("StringIO")
        val oldOut = sys.get("stdout")
        val oldErr = sys.get("stderr")
        sys.put("stdout", buffer)
        sys.put("stderr", buffer)
        try {
            val globals = builtins.callAttr("dict")
            val dir = pyString(workdir)
            val prelude = "import os\nos.makedirs($dir, exist_ok=True)\nos.chdir($dir)\n"
            builtins.callAttr("exec", prelude + code, globals)
        } catch (e: Exception) {
            buffer.callAttr("write", (e.message ?: e.toString()) + "\n")
        } finally {
            sys.put("stdout", oldOut)
            sys.put("stderr", oldErr)
        }
        buffer.callAttr("getvalue").toString()
    }

    private fun pyString(s: String): String =
        "'" + s.replace("\\", "\\\\").replace("'", "\\'").replace("\n", "\\n") + "'"
}
