package com.example.aichat

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.speech.RecognizerIntent
import android.util.Base64
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.UUID

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AppRoot() }
    }
}

// ---------- Palette ----------

data class Palette(
    val bg: Color,
    val surface: Color,
    val user: Color,
    val text: Color,
    val muted: Color,
    val line: Color,
    val accent: Color,
    val accentText: Color,
    val error: Color,
)

val LightPalette = Palette(
    bg = Color(0xFFF7F7F5),
    surface = Color(0xFFFFFFFF),
    user = Color(0xFFEFEEEA),
    text = Color(0xFF1F1E1D),
    muted = Color(0xFF6E6E6A),
    line = Color(0xFFE3E2DE),
    accent = Color(0xFF1F1E1D),
    accentText = Color(0xFFFFFFFF),
    error = Color(0xFF9B2C2C),
)

val DarkPalette = Palette(
    bg = Color(0xFF2E2E2E),
    surface = Color(0xFF383838),
    user = Color(0xFF454545),
    text = Color(0xFFECECEC),
    muted = Color(0xFFA3A3A3),
    line = Color(0xFF4A4A4A),
    accent = Color(0xFFECECEC),
    accentText = Color(0xFF2E2E2E),
    error = Color(0xFFF2A9A9),
)

val LocalPalette = staticCompositionLocalOf { LightPalette }

private fun schemeFor(p: Palette, dark: Boolean) =
    (if (dark) darkColorScheme() else lightColorScheme()).copy(
        primary = p.accent, onPrimary = p.accentText,
        secondary = p.accent, onSecondary = p.accentText,
        background = p.bg, onBackground = p.text,
        surface = p.surface, onSurface = p.text,
        surfaceVariant = p.user, onSurfaceVariant = p.muted,
        primaryContainer = p.user, onPrimaryContainer = p.text,
        secondaryContainer = p.user, onSecondaryContainer = p.text,
        outline = p.line, error = p.error,
    )

// ---------- Root ----------

@Composable
fun AppRoot(vm: AppViewModel = viewModel()) {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("ui", Context.MODE_PRIVATE) }
    var dark by remember { mutableStateOf(prefs.getBoolean("dark", false)) }
    var multi by remember { mutableStateOf(prefs.getBoolean("multi", false)) }
    var screen by remember { mutableStateOf("chat") }

    val palette = if (dark) DarkPalette else LightPalette

    MaterialTheme(colorScheme = schemeFor(palette, dark)) {
        CompositionLocalProvider(LocalPalette provides palette) {
            Box(Modifier.fillMaxSize().background(palette.bg)) {
                if (screen == "settings") {
                    BackHandler { screen = "chat" }
                    SettingsScreen(
                        vm = vm,
                        multi = multi,
                        onMulti = { v ->
                            multi = v
                            prefs.edit().putBoolean("multi", v).apply()
                        },
                        onBack = { screen = "chat" },
                    )
                } else {
                    ChatScreen(
                        vm = vm,
                        multi = multi,
                        dark = dark,
                        onToggleTheme = {
                            dark = !dark
                            prefs.edit().putBoolean("dark", dark).apply()
                        },
                        onOpenSettings = { screen = "settings" },
                    )
                }
            }
        }
    }
}

// ---------- Shared components ----------

@Composable
fun fieldColors() = OutlinedTextFieldDefaults.colors(
    focusedTextColor = LocalPalette.current.text,
    unfocusedTextColor = LocalPalette.current.text,
    focusedContainerColor = LocalPalette.current.surface,
    unfocusedContainerColor = LocalPalette.current.surface,
    focusedBorderColor = LocalPalette.current.muted,
    unfocusedBorderColor = LocalPalette.current.line,
    focusedLabelColor = LocalPalette.current.muted,
    unfocusedLabelColor = LocalPalette.current.muted,
    cursorColor = LocalPalette.current.text,
    focusedPlaceholderColor = LocalPalette.current.muted,
    unfocusedPlaceholderColor = LocalPalette.current.muted,
)

@Composable
fun Choice(
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val p = LocalPalette.current
    val shape = RoundedCornerShape(10.dp)
    if (selected) {
        Button(
            onClick = onClick,
            modifier = modifier,
            shape = shape,
            colors = ButtonDefaults.buttonColors(containerColor = p.accent, contentColor = p.accentText),
        ) { Text(label, fontSize = 14.sp) }
    } else {
        OutlinedButton(
            onClick = onClick,
            modifier = modifier,
            shape = shape,
            border = BorderStroke(1.dp, p.line),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = p.text),
        ) { Text(label, fontSize = 14.sp) }
    }
}

@Composable
fun SmallButton(label: String, onClick: () -> Unit) {
    val p = LocalPalette.current
    OutlinedButton(
        onClick = onClick,
        shape = RoundedCornerShape(10.dp),
        border = BorderStroke(1.dp, p.line),
        colors = ButtonDefaults.outlinedButtonColors(contentColor = p.text),
        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
    ) { Text(label, fontSize = 13.sp) }
}

@Composable
fun Dropdown(
    label: String,
    options: List<Pair<String, String>>,
    selectedId: String,
    onSelect: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    val p = LocalPalette.current
    var expanded by remember { mutableStateOf(false) }
    val selectedText = options.firstOrNull { it.first == selectedId }?.second ?: label
    Box(modifier) {
        OutlinedButton(
            onClick = { expanded = true },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(10.dp),
            border = BorderStroke(1.dp, p.line),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = p.text),
        ) {
            Text(selectedText, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false))
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            options.forEach { (id, text) ->
                DropdownMenuItem(
                    text = { Text(text) },
                    onClick = {
                        onSelect(id)
                        expanded = false
                    },
                )
            }
        }
    }
}

@Composable
fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    val p = LocalPalette.current
    Text(
        title,
        fontSize = 13.sp,
        fontWeight = FontWeight.Medium,
        color = p.muted,
        modifier = Modifier.padding(top = 22.dp, bottom = 8.dp, start = 4.dp),
    )
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = p.surface,
        border = BorderStroke(1.dp, p.line),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(Modifier.padding(14.dp), content = content)
    }
}

@Composable
fun LabeledField(
    label: String,
    value: String,
    placeholder: String = "",
    onChange: (String) -> Unit,
) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label) },
        placeholder = { Text(placeholder) },
        singleLine = true,
        colors = fieldColors(),
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
    )
}

@Composable
fun ToggleRow(title: String, subtitle: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    val p = LocalPalette.current
    Row(
        Modifier.fillMaxWidth().padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = p.text, fontSize = 15.sp)
            Text(subtitle, fontSize = 12.sp, color = p.muted)
        }
        Spacer(Modifier.width(8.dp))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

// ---------- Files, clipboard, save ----------

fun showToast(ctx: Context, msg: String) {
    Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show()
}

fun copyText(ctx: Context, text: String) {
    val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    cm.setPrimaryClip(ClipData.newPlainText("text", text))
}

/** Saves text to the public Downloads folder and returns the file name. */
fun saveToDownloads(ctx: Context, fileName: String, text: String): String {
    return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, fileName)
            put(MediaStore.Downloads.MIME_TYPE, "text/plain")
            put(MediaStore.Downloads.IS_PENDING, 1)
        }
        val uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            ?: error("Cannot create file")
        ctx.contentResolver.openOutputStream(uri)?.use { it.write(text.toByteArray(Charsets.UTF_8)) }
        val done = ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }
        ctx.contentResolver.update(uri, done, null, null)
        fileName
    } else {
        val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        dir.mkdirs()
        File(dir, fileName).writeText(text, Charsets.UTF_8)
        fileName
    }
}

/** Returns a saver that asks for storage permission on Android 8 and older. */
@Composable
fun rememberSaver(): (String, String) -> Unit {
    val ctx = LocalContext.current
    var pending by remember { mutableStateOf<Pair<String, String>?>(null) }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        val job = pending
        pending = null
        if (job != null) {
            if (granted) {
                val msg = runCatching { saveToDownloads(ctx, job.first, job.second) }
                    .fold({ "Saved to Downloads: $it" }, { "Save failed: ${it.message}" })
                showToast(ctx, msg)
            } else {
                showToast(ctx, "Storage permission denied")
            }
        }
    }
    return { name, text ->
        val needsPermission = Build.VERSION.SDK_INT < Build.VERSION_CODES.Q &&
            ctx.checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != android.content.pm.PackageManager.PERMISSION_GRANTED
        if (needsPermission) {
            pending = name to text
            permLauncher.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        } else {
            val msg = runCatching { saveToDownloads(ctx, name, text) }
                .fold({ "Saved to Downloads: $it" }, { "Save failed: ${it.message}" })
            showToast(ctx, msg)
        }
    }
}

/** Reads a picked file. Photos are downscaled to keep requests small. */
fun readAttachment(ctx: Context, uri: Uri): Attachment? {
    val mime = ctx.contentResolver.getType(uri) ?: "application/octet-stream"
    val name = uri.lastPathSegment?.substringAfterLast('/')?.substringAfterLast(':') ?: "file"
    val bytes = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: return null
    return when {
        mime.startsWith("image/") -> {
            val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: return null
            val scale = minOf(1f, 1024f / maxOf(bmp.width, bmp.height))
            val scaled = if (scale < 1f) {
                Bitmap.createScaledBitmap(bmp, (bmp.width * scale).toInt(), (bmp.height * scale).toInt(), true)
            } else bmp
            val out = ByteArrayOutputStream()
            scaled.compress(Bitmap.CompressFormat.JPEG, 85, out)
            Attachment(name, "image", "image/jpeg", Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP))
        }
        mime.startsWith("audio/") ->
            Attachment(name, "audio", mime, Base64.encodeToString(bytes, Base64.NO_WRAP))
        bytes.size > 300_000 ->
            Attachment(name, "text", mime, "(file too large to include: ${bytes.size} bytes)")
        mime.startsWith("text/") || mime.contains("json") || mime.contains("xml") ||
            name.endsWith(".kt") || name.endsWith(".py") || name.endsWith(".js") || name.endsWith(".md") ||
            name.endsWith(".java") || name.endsWith(".html") || name.endsWith(".css") || name.endsWith(".csv") ->
            Attachment(name, "text", mime, String(bytes, Charsets.UTF_8))
        else ->
            Attachment(name, "text", mime, "(binary file, content not included)")
    }
}

// ---------- Message rendering: text, code blocks, thinking ----------

data class Seg(val code: Boolean, val lang: String, val text: String)

/** Splits a reply into prose and fenced code blocks. Action blocks are hidden (shown as action cards). */
fun segmentsOf(src: String): List<Seg> {
    val cleaned = src.replace(Regex("```action:[^\\n]*\\n[\\s\\S]*?```"), "")
    val re = Regex("```([A-Za-z0-9_+#.-]*)\\n([\\s\\S]*?)```")
    val out = mutableListOf<Seg>()
    var last = 0
    re.findAll(cleaned).forEach { m ->
        if (m.range.first > last) out += Seg(false, "", cleaned.substring(last, m.range.first))
        out += Seg(true, m.groupValues[1], m.groupValues[2].trimEnd('\n'))
        last = m.range.last + 1
    }
    if (last < cleaned.length) out += Seg(false, "", cleaned.substring(last))
    return out
}

fun fileNameFor(lang: String): String {
    val ext = when (lang.lowercase()) {
        "kotlin", "kt" -> "kt"
        "python", "py" -> "py"
        "javascript", "js" -> "js"
        "typescript", "ts" -> "ts"
        "java" -> "java"
        "html" -> "html"
        "css" -> "css"
        "json" -> "json"
        "bash", "sh", "shell" -> "sh"
        "xml" -> "xml"
        "markdown", "md" -> "md"
        "" -> "txt"
        else -> lang.filter { it.isLetterOrDigit() }.take(8).ifBlank { "txt" }
    }
    return "snippet_${System.currentTimeMillis()}.$ext"
}

@Composable
fun ThinkingBlock(reasoning: String) {
    val p = LocalPalette.current
    var open by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxWidth()) {
        Text(
            (if (open) "▾ " else "▸ ") + "Thinking",
            fontSize = 14.sp,
            color = p.muted,
            modifier = Modifier.clickable { open = !open }.padding(vertical = 4.dp),
        )
        if (open) {
            Text(
                reasoning,
                fontSize = 14.sp,
                lineHeight = 20.sp,
                color = p.muted,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 4.dp)
                    .background(p.surface, RoundedCornerShape(10.dp))
                    .padding(12.dp),
            )
        }
    }
}

@Composable
fun CodeBlock(seg: Seg, onSave: (String, String) -> Unit) {
    val p = LocalPalette.current
    val ctx = LocalContext.current
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = p.surface,
        border = BorderStroke(1.dp, p.line),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column {
            Row(
                Modifier.fillMaxWidth().padding(start = 12.dp, end = 4.dp, top = 2.dp, bottom = 2.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(seg.lang.ifBlank { "code" }, fontSize = 12.sp, color = p.muted, modifier = Modifier.weight(1f))
                TextButton(onClick = {
                    copyText(ctx, seg.text)
                    showToast(ctx, "Copied")
                }) { Text("Copy", fontSize = 13.sp, color = p.text) }
                TextButton(onClick = { onSave(fileNameFor(seg.lang), seg.text) }) {
                    Text("Save", fontSize = 13.sp, color = p.text)
                }
            }
            Text(
                seg.text,
                fontFamily = FontFamily.Monospace,
                fontSize = 13.sp,
                lineHeight = 19.sp,
                color = p.text,
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(12.dp),
            )
        }
    }
}

@Composable
fun AnswerText(text: String, onSave: (String, String) -> Unit) {
    val p = LocalPalette.current
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        segmentsOf(text).forEach { s ->
            if (s.code) {
                CodeBlock(s, onSave)
            } else if (s.text.isNotBlank()) {
                Text(s.text.trim(), color = p.text, fontSize = 16.sp, lineHeight = 24.sp)
            }
        }
    }
}

@Composable
fun ChatBubble(item: ChatItem, onSave: (String, String) -> Unit) {
    val p = LocalPalette.current
    val ctx = LocalContext.current
    if (item.kind == "user") {
        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.End) {
            if (item.meta.isNotBlank()) {
                Text(item.meta, fontSize = 12.sp, color = p.muted)
                Spacer(Modifier.height(4.dp))
            }
            if (item.text.isNotBlank()) {
                Box(
                    Modifier
                        .widthIn(max = 320.dp)
                        .background(p.user, RoundedCornerShape(18.dp))
                        .padding(horizontal = 14.dp, vertical = 10.dp)
                ) {
                    Text(item.text, color = p.text, fontSize = 16.sp, lineHeight = 22.sp)
                }
            }
        }
        return
    }

    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        if (item.meta.isNotBlank()) {
            Text(item.meta, fontSize = 12.sp, color = p.muted)
        }
        if (item.reasoning.isNotBlank()) {
            ThinkingBlock(item.reasoning)
        }
        if (item.kind == "error") {
            Text(item.text, color = p.error, fontSize = 16.sp, lineHeight = 24.sp)
        } else if (item.text.isNotBlank()) {
            AnswerText(item.text, onSave)
        }
        item.action?.let { ActionView(it, onSave) }
        if ((item.kind == "assistant" || item.kind == "step") && item.text.isNotBlank()) {
            Row {
                TextButton(onClick = {
                    copyText(ctx, item.text)
                    showToast(ctx, "Copied")
                }) { Text("Copy answer", fontSize = 13.sp, color = p.muted) }
            }
        }
    }
}

@Composable
fun ActionView(a: ActionItem, onSave: (String, String) -> Unit) {
    val p = LocalPalette.current
    val ctx = LocalContext.current
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = p.surface,
        border = BorderStroke(1.dp, p.line),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(Modifier.padding(12.dp)) {
            Text(a.kind.uppercase(), fontSize = 11.sp, color = p.muted)
            Spacer(Modifier.height(6.dp))
            Text(a.describe(), fontFamily = FontFamily.Monospace, fontSize = 13.sp, color = p.text)
            val statusText = when (a.status) {
                "pending" -> "Waiting for confirmation"
                "running" -> "Running…"
                "done" -> "Done"
                "rejected" -> "Rejected"
                else -> "Error"
            }
            val extra = if (a.output.isNotBlank()) "\n" + a.output.take(800) else ""
            Text(
                statusText + extra,
                fontSize = 12.sp,
                color = if (a.status == "error") p.error else p.muted,
                modifier = Modifier.padding(top = 8.dp),
            )
            if (a.kind == "write") {
                Row(Modifier.padding(top = 6.dp)) {
                    SmallButton("Save file") {
                        onSave(a.target.substringAfterLast('/'), a.content)
                    }
                    Spacer(Modifier.width(8.dp))
                    SmallButton("Copy") {
                        copyText(ctx, a.content)
                        showToast(ctx, "Copied")
                    }
                }
            }
        }
    }
}

// ---------- Chat screen ----------

@Composable
fun ChatScreen(
    vm: AppViewModel,
    multi: Boolean,
    dark: Boolean,
    onToggleTheme: () -> Unit,
    onOpenSettings: () -> Unit,
) {
    val p = LocalPalette.current
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val settings by vm.settings.collectAsState()
    val chat by vm.chat.collectAsState()
    val busy by vm.busy.collectAsState()
    var input by remember { mutableStateOf("") }
    var attachments by remember { mutableStateOf<List<Attachment>>(emptyList()) }
    val listState = rememberLazyListState()
    val save = rememberSaver()

    LaunchedEffect(chat.size) {
        if (chat.isNotEmpty()) listState.animateScrollToItem(chat.lastIndex)
    }

    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            scope.launch {
                val a = withContext(Dispatchers.IO) { runCatching { readAttachment(ctx, uri) }.getOrNull() }
                if (a != null) attachments = attachments + a
                else showToast(ctx, "Could not read the file")
            }
        }
    }

    val voiceLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        val spoken = res.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!spoken.isNullOrBlank()) {
            input = if (input.isBlank()) spoken else input + " " + spoken
        }
    }

    // "Ask every time": show the exact command, path and content before running
    val pending = chat.firstOrNull { it.action?.status == "pending" }?.action
    if (pending != null) {
        AlertDialog(
            onDismissRequest = { },
            containerColor = p.surface,
            title = { Text("Confirm action", color = p.text) },
            text = {
                Column(Modifier.heightIn(max = 320.dp).verticalScroll(rememberScrollState())) {
                    Text(pending.describe(), fontFamily = FontFamily.Monospace, fontSize = 13.sp, color = p.text)
                }
            },
            confirmButton = { Choice("Yes", selected = true, onClick = { vm.approveAction(pending) }) },
            dismissButton = { Choice("No", selected = false, onClick = { vm.rejectAction(pending) }) },
        )
    }

    Scaffold(
        containerColor = p.bg,
        topBar = {
            Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        "Multi-Model Chat",
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 16.sp,
                        color = p.text,
                        modifier = Modifier.weight(1f),
                    )
                    SmallButton(if (dark) "Light theme" else "Dark theme", onToggleTheme)
                    Spacer(Modifier.width(8.dp))
                    SmallButton("Settings", onOpenSettings)
                }
                Spacer(Modifier.height(10.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Dropdown(
                        label = "No profiles yet",
                        options = if (settings.profiles.isEmpty()) {
                            listOf("" to "No profiles yet")
                        } else {
                            settings.profiles.map { it.id to "${it.name} · ${it.model.ifBlank { "no model" }}" }
                        },
                        selectedId = settings.activeId.orEmpty(),
                        onSelect = { vm.setActive(it) },
                        modifier = Modifier.weight(1f),
                    )
                    if (multi) {
                        Spacer(Modifier.width(8.dp))
                        Text("Multi-agent", fontSize = 12.sp, color = p.muted)
                    }
                }
            }
        },
        bottomBar = {
            Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp)) {
                if (attachments.isNotEmpty()) {
                    Row(
                        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(bottom = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        attachments.forEachIndexed { i, a ->
                            Row(
                                Modifier
                                    .background(p.surface, RoundedCornerShape(10.dp))
                                    .padding(start = 10.dp, end = 4.dp, top = 4.dp, bottom = 4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Text(a.name, fontSize = 12.sp, color = p.text, maxLines = 1)
                                TextButton(onClick = { attachments = attachments.filterIndexed { j, _ -> j != i } }) {
                                    Text("×", color = p.muted)
                                }
                            }
                        }
                    }
                }
                Row(
                    Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    SmallButton("Photo") { filePicker.launch("image/*") }
                    SmallButton("File / audio") { filePicker.launch("*/*") }
                    SmallButton("Voice") {
                        try {
                            voiceLauncher.launch(
                                Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                                    .putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak your message")
                            )
                        } catch (e: Exception) {
                            showToast(ctx, "Speech recognition is not available on this device")
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.Bottom) {
                    OutlinedTextField(
                        value = input,
                        onValueChange = { input = it },
                        modifier = Modifier.weight(1f),
                        placeholder = { Text("Message") },
                        maxLines = 5,
                        shape = RoundedCornerShape(22.dp),
                        colors = fieldColors(),
                    )
                    Spacer(Modifier.width(8.dp))
                    Button(
                        onClick = {
                            vm.send(input, multi, attachments)
                            input = ""
                            attachments = emptyList()
                        },
                        enabled = !busy && (input.isNotBlank() || attachments.isNotEmpty()),
                        modifier = Modifier.size(46.dp),
                        shape = CircleShape,
                        contentPadding = PaddingValues(0.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = p.accent,
                            contentColor = p.accentText,
                            disabledContainerColor = p.line,
                            disabledContentColor = p.muted,
                        ),
                    ) { Text("↑", fontSize = 18.sp) }
                }
            }
        },
    ) { padding ->
        if (chat.isEmpty() && !busy) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                Text("How can I help you today?", color = p.muted, fontSize = 18.sp)
            }
        } else {
            LazyColumn(
                state = listState,
                modifier = Modifier.fillMaxSize().padding(padding),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
            ) {
                items(chat, key = { it.id }) { item -> ChatBubble(item, save) }
                if (busy) {
                    item { Text("Thinking…", color = p.muted, fontSize = 14.sp) }
                }
            }
        }
    }
}

// ---------- Settings screen ----------

@Composable
fun SettingsScreen(
    vm: AppViewModel,
    multi: Boolean,
    onMulti: (Boolean) -> Unit,
    onBack: () -> Unit,
) {
    val p = LocalPalette.current
    val settings by vm.settings.collectAsState()
    val logs by vm.logs.collectAsState()
    val ping by vm.pingResult.collectAsState()

    var editingId by remember { mutableStateOf<String?>(null) }
    var providerId by remember { mutableStateOf("custom") }
    var profileName by remember { mutableStateOf("") }
    var baseUrl by remember { mutableStateOf("https://osaii.wyvernhub.net/api/v1") }
    var apiKey by remember { mutableStateOf("") }
    var model by remember { mutableStateOf("") }
    var showKey by remember { mutableStateOf(false) }
    var formStatus by remember { mutableStateOf("") }

    val clearForm: () -> Unit = {
        editingId = null
        profileName = ""
        apiKey = ""
        model = ""
    }
    val loadProfile: (Profile) -> Unit = { prof ->
        editingId = prof.id
        providerId = prof.providerId
        profileName = prof.name
        baseUrl = prof.baseUrl
        apiKey = prof.apiKey
        model = prof.model
        formStatus = "Editing ${prof.name}"
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("Back", color = p.text) }
            Spacer(Modifier.width(8.dp))
            Text("Settings", fontSize = 18.sp, fontWeight = FontWeight.SemiBold, color = p.text)
        }

        Section("Mode") {
            Text("Agent mode", fontSize = 13.sp, color = p.muted)
            Row(
                Modifier.fillMaxWidth().padding(top = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Choice("Single model", selected = !multi, onClick = { onMulti(false) }, modifier = Modifier.weight(1f))
                Choice("Multi-agent", selected = multi, onClick = { onMulti(true) }, modifier = Modifier.weight(1f))
            }
            Text("Execution", fontSize = 13.sp, color = p.muted, modifier = Modifier.padding(top = 14.dp))
            Row(
                Modifier.fillMaxWidth().padding(top = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Choice(
                    "Ask every time",
                    selected = settings.askEveryTime,
                    onClick = { vm.updateSettings { it.copy(askEveryTime = true) } },
                    modifier = Modifier.weight(1f),
                )
                Choice(
                    "Auto / No prompt",
                    selected = !settings.askEveryTime,
                    onClick = { vm.updateSettings { it.copy(askEveryTime = false) } },
                    modifier = Modifier.weight(1f),
                )
            }
        }

        Section("Provider profile") {
            Dropdown(
                label = "Provider",
                options = PROVIDERS.map { it.id to it.name },
                selectedId = providerId,
                onSelect = { id ->
                    providerId = id
                    val meta = PROVIDERS.first { it.id == id }
                    baseUrl = if (id == "custom") baseUrl.ifBlank { meta.baseUrl } else meta.baseUrl
                    if (profileName.isBlank()) profileName = meta.name
                },
                modifier = Modifier.fillMaxWidth(),
            )
            LabeledField("Profile name", profileName, "e.g. My OpenAI key") { profileName = it }
            LabeledField("Base URL", baseUrl, "https://osaii.wyvernhub.net/api/v1") { baseUrl = it }
            OutlinedTextField(
                value = apiKey,
                onValueChange = { apiKey = it },
                label = { Text("API key") },
                singleLine = true,
                colors = fieldColors(),
                shape = RoundedCornerShape(10.dp),
                visualTransformation = if (showKey) VisualTransformation.None else PasswordVisualTransformation(),
                trailingIcon = {
                    TextButton(onClick = { showKey = !showKey }) {
                        Text(if (showKey) "Hide" else "Show", color = p.muted)
                    }
                },
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
            )

            Spacer(Modifier.height(12.dp))
            Choice(
                "Ping / Fetch Models",
                selected = false,
                onClick = { vm.ping(baseUrl.trim(), apiKey.trim()) },
                modifier = Modifier.fillMaxWidth(),
            )

            ping?.let { r ->
                val pingLine = if (r.ok) {
                    "Status ${r.status} · ${r.latencyMs} ms · ${r.models.size} models"
                } else {
                    val code = if (r.status > 0) " (${r.status})" else ""
                    "Failed$code · ${r.message.take(200)}"
                }
                Text(pingLine, fontSize = 12.sp, color = if (r.ok) p.muted else p.error, modifier = Modifier.padding(top = 8.dp))
            }

            val models = ping?.models.orEmpty()
            if (models.isNotEmpty()) {
                Column(
                    Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp)
                        .heightIn(max = 200.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    models.forEach { m ->
                        Text(
                            m,
                            fontSize = 14.sp,
                            color = p.text,
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(if (m == model) p.user else p.surface)
                                .clickable { model = m }
                                .padding(10.dp),
                        )
                    }
                }
            }

            LabeledField("Model", model, "Pick from the list or type a model name") { model = it }

            Row(
                Modifier.fillMaxWidth().padding(top = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Choice(
                    "Save profile",
                    selected = true,
                    onClick = {
                        if (baseUrl.isBlank()) {
                            formStatus = "Base URL is required."
                        } else {
                            vm.saveProfile(
                                Profile(
                                    id = editingId ?: UUID.randomUUID().toString(),
                                    name = profileName.ifBlank { "Untitled profile" },
                                    providerId = providerId,
                                    baseUrl = baseUrl.trim(),
                                    apiKey = apiKey.trim(),
                                    model = model.trim(),
                                )
                            )
                            formStatus = "Profile saved."
                            clearForm()
                        }
                    },
                    modifier = Modifier.weight(1f),
                )
                Choice(
                    "Delete",
                    selected = false,
                    onClick = {
                        editingId?.let { vm.deleteProfile(it) }
                        formStatus = "Profile deleted."
                        clearForm()
                    },
                    modifier = Modifier.weight(1f),
                )
            }
            if (formStatus.isNotBlank()) {
                Text(formStatus, fontSize = 12.sp, color = p.muted, modifier = Modifier.padding(top = 6.dp))
            }
        }

        Section("Saved profiles") {
            if (settings.profiles.isEmpty()) {
                Text("No profiles saved.", fontSize = 13.sp, color = p.muted)
            }
            settings.profiles.forEach { prof ->
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(prof.name, color = p.text, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(
                            "${prof.model.ifBlank { "no model" }} · ${prof.baseUrl}",
                            fontSize = 12.sp,
                            color = p.muted,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                    TextButton(onClick = { loadProfile(prof) }) { Text("Edit", color = p.text) }
                    TextButton(onClick = { vm.setActive(prof.id) }) {
                        Text(if (settings.activeId == prof.id) "Active" else "Use", color = p.text)
                    }
                }
            }
        }

        Section("Failover") {
            ToggleRow(
                title = "Switch API key on failure",
                subtitle = "Moves to another key for the same provider when quota, rate limit or an error occurs.",
                checked = settings.failoverKeys,
                onChange = { v -> vm.updateSettings { it.copy(failoverKeys = v) } },
            )
            ToggleRow(
                title = "Switch model on failure",
                subtitle = "Falls back to another enabled profile if the current model fails or runs out of tokens.",
                checked = settings.failoverModels,
                onChange = { v -> vm.updateSettings { it.copy(failoverModels = v) } },
            )
        }

        Section("Multi-agent assignment") {
            val agentOptions = listOf("" to "Use active profile") +
                settings.profiles.map { it.id to it.name }

            Text("Planner / Architect", fontSize = 13.sp, color = p.muted, modifier = Modifier.padding(top = 4.dp))
            Dropdown(
                label = "Use active profile",
                options = agentOptions,
                selectedId = settings.agents.planner.orEmpty(),
                onSelect = { id -> vm.updateSettings { it.copy(agents = it.agents.copy(planner = id.ifEmpty { null })) } },
                modifier = Modifier.fillMaxWidth(),
            )

            Text("Coder", fontSize = 13.sp, color = p.muted, modifier = Modifier.padding(top = 10.dp))
            Dropdown(
                label = "Use active profile",
                options = agentOptions,
                selectedId = settings.agents.coder.orEmpty(),
                onSelect = { id -> vm.updateSettings { it.copy(agents = it.agents.copy(coder = id.ifEmpty { null })) } },
                modifier = Modifier.fillMaxWidth(),
            )

            Text("Reviewer / Tester", fontSize = 13.sp, color = p.muted, modifier = Modifier.padding(top = 10.dp))
            Dropdown(
                label = "Use active profile",
                options = agentOptions,
                selectedId = settings.agents.reviewer.orEmpty(),
                onSelect = { id -> vm.updateSettings { it.copy(agents = it.agents.copy(reviewer = id.ifEmpty { null })) } },
                modifier = Modifier.fillMaxWidth(),
            )
        }

        Section("Activity log") {
            Column(
                Modifier
                    .fillMaxWidth()
                    .heightIn(max = 220.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Text(
                    if (logs.isEmpty()) "No activity yet." else logs.joinToString("\n"),
                    fontFamily = FontFamily.Monospace,
                    fontSize = 12.sp,
                    color = p.muted,
                )
            }
        }

        Spacer(Modifier.height(24.dp))
    }
}
