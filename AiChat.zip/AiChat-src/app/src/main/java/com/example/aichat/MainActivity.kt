package com.example.aichat

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import java.util.UUID

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = GreyScheme) {
                Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    AppRoot()
                }
            }
        }
    }
}

private val GreyScheme = lightColorScheme(
    primary = Color(0xFF2B2B2B),
    onPrimary = Color.White,
    secondary = Color(0xFF5A5A5A),
    onSecondary = Color.White,
    background = Color(0xFFF2F2F2),
    onBackground = Color(0xFF1A1A1A),
    surface = Color.White,
    onSurface = Color(0xFF1A1A1A),
    surfaceVariant = Color(0xFFECECEC),
    onSurfaceVariant = Color(0xFF6B6B6B),
    outline = Color(0xFFD4D4D4),
    error = Color(0xFF7A2B2B),
)

private val LineColor = Color(0xFFD4D4D4)
private val MutedColor = Color(0xFF6B6B6B)

@Composable
fun AppRoot(vm: AppViewModel = viewModel()) {
    var screen by remember { mutableStateOf("chat") }
    if (screen == "settings") {
        BackHandler { screen = "chat" }
        SettingsScreen(vm = vm, onBack = { screen = "chat" })
    } else {
        ChatScreen(vm = vm, onOpenSettings = { screen = "settings" })
    }
}

// ---------- Shared components ----------

@Composable
fun Dropdown(
    label: String,
    options: List<Pair<String, String>>,
    selectedId: String,
    onSelect: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    var expanded by remember { mutableStateOf(false) }
    val selectedText = options.firstOrNull { it.first == selectedId }?.second ?: label
    Box(modifier) {
        OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) {
            Text(selectedText, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            options.forEach { (id, text) ->
                DropdownMenuItem(
                    text = { Text(text) },
                    onClick = {
                        onSelect(id)
                        expanded = false
                    },
                )
            }
        }
    }
}

@Composable
fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    Text(
        title.uppercase(),
        fontSize = 12.sp,
        fontWeight = FontWeight.SemiBold,
        color = MutedColor,
        modifier = Modifier.padding(top = 20.dp, bottom = 6.dp),
    )
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = Color.White,
        border = BorderStroke(1.dp, LineColor),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(Modifier.padding(12.dp), content = content)
    }
}

@Composable
fun LabeledField(
    label: String,
    value: String,
    placeholder: String = "",
    onChange: (String) -> Unit,
) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label) },
        placeholder = { Text(placeholder) },
        singleLine = true,
        modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
    )
}

@Composable
fun ToggleRow(title: String, subtitle: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title)
            Text(subtitle, fontSize = 12.sp, color = MutedColor)
        }
        Spacer(Modifier.width(8.dp))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

// ---------- Chat screen ----------

@Composable
fun ChatScreen(vm: AppViewModel, onOpenSettings: () -> Unit) {
    val settings by vm.settings.collectAsState()
    val chat by vm.chat.collectAsState()
    val busy by vm.busy.collectAsState()
    var input by remember { mutableStateOf("") }
    var multi by remember { mutableStateOf(false) }
    val listState = rememberLazyListState()

    LaunchedEffect(chat.size) {
        if (chat.isNotEmpty()) listState.animateScrollToItem(chat.lastIndex)
    }

    // "Ask every time": show the exact command, path and content before running
    val pending = chat.firstOrNull { it.action?.status == "pending" }?.action
    if (pending != null) {
        AlertDialog(
            onDismissRequest = { },
            title = { Text("Confirm action") },
            text = {
                Column(
                    Modifier
                        .heightIn(max = 320.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    Text(
                        pending.describe(),
                        fontFamily = FontFamily.Monospace,
                        fontSize = 13.sp,
                    )
                }
            },
            confirmButton = {
                Button(onClick = { vm.approveAction(pending) }) { Text("Yes") }
            },
            dismissButton = {
                OutlinedButton(onClick = { vm.rejectAction(pending) }) { Text("No") }
            },
        )
    }

    Scaffold(
        topBar = {
            Column(
                Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surface)
                    .padding(12.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        "Multi-Model Chat",
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 17.sp,
                        modifier = Modifier.weight(1f),
                    )
                    OutlinedButton(onClick = onOpenSettings) { Text("Settings") }
                }
                Spacer(Modifier.height(8.dp))
                Dropdown(
                    label = "No profiles yet",
                    options = if (settings.profiles.isEmpty()) {
                        listOf("" to "No profiles yet")
                    } else {
                        settings.profiles.map { it.id to "${it.name} · ${it.model.ifBlank { "no model" }}" }
                    },
                    selectedId = settings.activeId.orEmpty(),
                    onSelect = { vm.setActive(it) },
                    modifier = Modifier.fillMaxWidth(),
                )
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = !multi,
                        onClick = { multi = false },
                        label = { Text("Single model") },
                    )
                    FilterChip(
                        selected = multi,
                        onClick = { multi = true },
                        label = { Text("Multi-agent") },
                    )
                }
                Spacer(Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = settings.askEveryTime,
                        onClick = { vm.updateSettings { it.copy(askEveryTime = true) } },
                        label = { Text("Ask every time") },
                    )
                    FilterChip(
                        selected = !settings.askEveryTime,
                        onClick = { vm.updateSettings { it.copy(askEveryTime = false) } },
                        label = { Text("Auto / No prompt") },
                    )
                }
            }
        },
        bottomBar = {
            Row(
                Modifier.fillMaxWidth().padding(12.dp),
                verticalAlignment = Alignment.Bottom,
            ) {
                OutlinedTextField(
                    value = input,
                    onValueChange = { input = it },
                    modifier = Modifier.weight(1f),
                    placeholder = { Text("Describe a task or ask a question…") },
                    maxLines = 5,
                )
                Spacer(Modifier.width(8.dp))
                Button(
                    onClick = {
                        vm.send(input, multi)
                        input = ""
                    },
                    enabled = !busy && input.isNotBlank(),
                ) { Text("Send") }
            }
        },
    ) { padding ->
        LazyColumn(
            state = listState,
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            items(chat, key = { it.id }) { item -> ChatBubble(item) }
            if (busy) {
                item { Text("Working…", color = MutedColor, fontSize = 13.sp) }
            }
        }
    }
}

@Composable
fun ChatBubble(item: ChatItem) {
    val isUser = item.kind == "user"
    val bg = when (item.kind) {
        "user" -> Color(0xFFE6E6E6)
        "error" -> Color(0xFFF3E9E9)
        else -> Color.White
    }
    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = if (isUser) Alignment.End else Alignment.Start,
    ) {
        Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = bg),
            border = BorderStroke(1.dp, LineColor),
            modifier = Modifier.widthIn(max = 520.dp),
        ) {
            Column(Modifier.padding(12.dp)) {
                if (item.meta.isNotBlank()) {
                    Text(item.meta, fontSize = 12.sp, color = MutedColor)
                    Spacer(Modifier.height(4.dp))
                }
                if (item.text.isNotBlank()) {
                    Text(item.text, lineHeight = 20.sp)
                }
                item.action?.let { ActionView(it) }
            }
        }
    }
}

@Composable
fun ActionView(a: ActionItem) {
    Spacer(Modifier.height(8.dp))
    Text(a.kind.uppercase(), fontSize = 11.sp, color = MutedColor)
    Surface(
        shape = RoundedCornerShape(8.dp),
        color = Color(0xFFF7F7F7),
        border = BorderStroke(1.dp, LineColor),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Text(
            a.describe(),
            fontFamily = FontFamily.Monospace,
            fontSize = 12.sp,
            modifier = Modifier.padding(8.dp),
        )
    }
    val statusText = when (a.status) {
        "pending" -> "Waiting for confirmation"
        "running" -> "Running…"
        "done" -> "Done"
        "rejected" -> "Rejected"
        else -> "Error"
    }
    val extra = if (a.output.isNotBlank()) "\n" + a.output.take(800) else ""
    Text(statusText + extra, fontSize = 12.sp, color = MutedColor, modifier = Modifier.padding(top = 6.dp))
}

// ---------- Settings screen ----------

@Composable
fun SettingsScreen(vm: AppViewModel, onBack: () -> Unit) {
    val settings by vm.settings.collectAsState()
    val logs by vm.logs.collectAsState()
    val ping by vm.pingResult.collectAsState()

    var editingId by remember { mutableStateOf<String?>(null) }
    var providerId by remember { mutableStateOf("custom") }
    var profileName by remember { mutableStateOf("") }
    var baseUrl by remember { mutableStateOf("https://osaii.wyvernhub.net/api/v1") }
    var apiKey by remember { mutableStateOf("") }
    var model by remember { mutableStateOf("") }
    var showKey by remember { mutableStateOf(false) }
    var formStatus by remember { mutableStateOf("") }

    val clearForm: () -> Unit = {
        editingId = null
        profileName = ""
        apiKey = ""
        model = ""
    }
    val loadProfile: (Profile) -> Unit = { p ->
        editingId = p.id
        providerId = p.providerId
        profileName = p.name
        baseUrl = p.baseUrl
        apiKey = p.apiKey
        model = p.model
        formStatus = "Editing ${p.name}"
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedButton(onClick = onBack) { Text("Back") }
            Spacer(Modifier.width(12.dp))
            Text("Settings", fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
        }

        Section("Provider profile") {
            Dropdown(
                label = "Provider",
                options = PROVIDERS.map { it.id to it.name },
                selectedId = providerId,
                onSelect = { id ->
                    providerId = id
                    val meta = PROVIDERS.first { it.id == id }
                    baseUrl = if (id == "custom") baseUrl.ifBlank { meta.baseUrl } else meta.baseUrl
                    if (profileName.isBlank()) profileName = meta.name
                },
                modifier = Modifier.fillMaxWidth(),
            )
            LabeledField("Profile name", profileName, "e.g. My OpenAI key") { profileName = it }
            LabeledField("Base URL", baseUrl, "https://osaii.wyvernhub.net/api/v1") { baseUrl = it }
            OutlinedTextField(
                value = apiKey,
                onValueChange = { apiKey = it },
                label = { Text("API key") },
                singleLine = true,
                visualTransformation = if (showKey) VisualTransformation.None else PasswordVisualTransformation(),
                trailingIcon = {
                    TextButton(onClick = { showKey = !showKey }) {
                        Text(if (showKey) "Hide" else "Show")
                    }
                },
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
            )

            Spacer(Modifier.height(12.dp))
            Button(
                onClick = { vm.ping(baseUrl.trim(), apiKey.trim()) },
                enabled = baseUrl.isNotBlank(),
            ) { Text("Ping / Fetch Models") }

            ping?.let { p ->
                val pingLine = if (p.ok) {
                    "Status ${p.status} · ${p.latencyMs} ms · ${p.models.size} models"
                } else {
                    val code = if (p.status > 0) " (${p.status})" else ""
                    "Failed$code · ${p.message.take(200)}"
                }
                Text(pingLine, fontSize = 12.sp, color = MutedColor, modifier = Modifier.padding(top = 6.dp))
            }

            val models = ping?.models.orEmpty()
            if (models.isNotEmpty()) {
                Column(
                    Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp)
                        .heightIn(max = 200.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    models.forEach { m ->
                        Text(
                            m,
                            fontSize = 14.sp,
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(if (m == model) Color(0xFFE4E4E4) else Color.Transparent)
                                .clickable { model = m }
                                .padding(10.dp),
                        )
                    }
                }
            }

            LabeledField("Model", model, "Pick from the list or type a model name") { model = it }

            Row(
                Modifier.fillMaxWidth().padding(top = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Button(
                    onClick = {
                        if (baseUrl.isBlank()) {
                            formStatus = "Base URL is required."
                        } else {
                            vm.saveProfile(
                                Profile(
                                    id = editingId ?: UUID.randomUUID().toString(),
                                    name = profileName.ifBlank { "Untitled profile" },
                                    providerId = providerId,
                                    baseUrl = baseUrl.trim(),
                                    apiKey = apiKey.trim(),
                                    model = model.trim(),
                                )
                            )
                            formStatus = "Profile saved."
                            clearForm()
                        }
                    },
                    modifier = Modifier.weight(1f),
                ) { Text("Save profile") }

                OutlinedButton(
                    onClick = {
                        editingId?.let { vm.deleteProfile(it) }
                        formStatus = "Profile deleted."
                        clearForm()
                    },
                    enabled = editingId != null,
                ) { Text("Delete") }
            }
            if (formStatus.isNotBlank()) {
                Text(formStatus, fontSize = 12.sp, color = MutedColor, modifier = Modifier.padding(top = 6.dp))
            }
        }

        Section("Saved profiles") {
            if (settings.profiles.isEmpty()) {
                Text("No profiles saved.", fontSize = 13.sp, color = MutedColor)
            }
            settings.profiles.forEach { p ->
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(p.name, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(
                            "${p.model.ifBlank { "no model" }} · ${p.baseUrl}",
                            fontSize = 12.sp,
                            color = MutedColor,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                    TextButton(onClick = { loadProfile(p) }) { Text("Edit") }
                    TextButton(onClick = { vm.setActive(p.id) }) {
                        Text(if (settings.activeId == p.id) "Active" else "Use")
                    }
                }
            }
        }

        Section("Failover") {
            ToggleRow(
                title = "Switch API key on failure",
                subtitle = "Moves to another key for the same provider when quota, rate limit or an error occurs.",
                checked = settings.failoverKeys,
                onChange = { v -> vm.updateSettings { it.copy(failoverKeys = v) } },
            )
            ToggleRow(
                title = "Switch model on failure",
                subtitle = "Falls back to another enabled profile if the current model fails or runs out of tokens.",
                checked = settings.failoverModels,
                onChange = { v -> vm.updateSettings { it.copy(failoverModels = v) } },
            )
        }

        Section("Multi-agent assignment") {
            val agentOptions = listOf("" to "Use active profile") +
                settings.profiles.map { it.id to it.name }

            Text("Planner / Architect", fontSize = 13.sp, color = MutedColor, modifier = Modifier.padding(top = 4.dp))
            Dropdown(
                label = "Use active profile",
                options = agentOptions,
                selectedId = settings.agents.planner.orEmpty(),
                onSelect = { id -> vm.updateSettings { it.copy(agents = it.agents.copy(planner = id.ifEmpty { null })) } },
                modifier = Modifier.fillMaxWidth(),
            )

            Text("Coder", fontSize = 13.sp, color = MutedColor, modifier = Modifier.padding(top = 8.dp))
            Dropdown(
                label = "Use active profile",
                options = agentOptions,
                selectedId = settings.agents.coder.orEmpty(),
                onSelect = { id -> vm.updateSettings { it.copy(agents = it.agents.copy(coder = id.ifEmpty { null })) } },
                modifier = Modifier.fillMaxWidth(),
            )

            Text("Reviewer / Tester", fontSize = 13.sp, color = MutedColor, modifier = Modifier.padding(top = 8.dp))
            Dropdown(
                label = "Use active profile",
                options = agentOptions,
                selectedId = settings.agents.reviewer.orEmpty(),
                onSelect = { id -> vm.updateSettings { it.copy(agents = it.agents.copy(reviewer = id.ifEmpty { null })) } },
                modifier = Modifier.fillMaxWidth(),
            )
        }

        Section("Activity log") {
            Column(
                Modifier
                    .fillMaxWidth()
                    .heightIn(max = 220.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Text(
                    if (logs.isEmpty()) "No activity yet." else logs.joinToString("\n"),
                    fontFamily = FontFamily.Monospace,
                    fontSize = 12.sp,
                )
            }
        }

        Spacer(Modifier.height(24.dp))
    }
}
