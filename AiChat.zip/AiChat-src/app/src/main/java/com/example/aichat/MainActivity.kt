package com.example.aichat

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.speech.RecognizerIntent
import android.util.Base64
import android.webkit.WebView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.MutableTransitionState
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.runtime.DisposableEffect
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.material3.Slider
import androidx.compose.ui.draw.blur
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.runtime.derivedStateOf
import androidx.compose.foundation.border
import androidx.compose.animation.slideOutVertically
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.UUID

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AppRoot() }
    }
}

// ---------- Palette and theme ----------

data class Palette(
    val bg: Color,
    val surface: Color,
    val user: Color,
    val text: Color,
    val muted: Color,
    val line: Color,
    val accent: Color,
    val accentText: Color,
    val error: Color,
    val glass: Boolean = false,
    val glassHighlight: Float = 0f,
)

val LightPalette = Palette(
    bg = Color(0xFFF7F7F5),
    surface = Color(0xFFFFFFFF),
    user = Color(0xFFEFEEEA),
    text = Color(0xFF1F1E1D),
    muted = Color(0xFF6E6E6A),
    line = Color(0xFFE3E2DE),
    accent = Color(0xFF1F1E1D),
    accentText = Color(0xFFFFFFFF),
    error = Color(0xFF9B2C2C),
)

val DarkPalette = Palette(
    bg = Color(0xFF2B2B2A),
    surface = Color(0xFF353533),
    user = Color(0xFF424240),
    text = Color(0xFFECECEA),
    muted = Color(0xFFA3A39E),
    line = Color(0xFF474745),
    accent = Color(0xFFECECEA),
    accentText = Color(0xFF2B2B2A),
    error = Color(0xFFF2A9A9),
)

val AccentOrange = Color(0xFFD97757)

val LocalPalette = staticCompositionLocalOf { DarkPalette }

val EFFORTS = listOf("low" to "Low", "medium" to "Medium", "high" to "High", "max" to "Max")

fun effortLabel(key: String): String = EFFORTS.firstOrNull { it.first == key }?.second ?: "Medium"

private fun schemeFor(p: Palette, dark: Boolean) =
    (if (dark) darkColorScheme() else lightColorScheme()).copy(
        primary = p.accent, onPrimary = p.accentText,
        secondary = p.accent, onSecondary = p.accentText,
        background = p.bg, onBackground = p.text,
        surface = p.surface, onSurface = p.text,
        surfaceVariant = p.user, onSurfaceVariant = p.muted,
        primaryContainer = p.user, onPrimaryContainer = p.text,
        secondaryContainer = p.user, onSecondaryContainer = p.text,
        outline = p.line, error = p.error,
    )

// ---------- Root ----------

@Composable
fun AppRoot(vm: AppViewModel = viewModel()) {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("ui", Context.MODE_PRIVATE) }
    var themeCfg by remember { mutableStateOf(ThemeStore.load(ctx)) }
    val setTheme: (ThemeConfig) -> Unit = { themeCfg = it; ThemeStore.save(ctx, it) }
    val dark = themeCfg.theme != "light"
    var multi by remember { mutableStateOf(prefs.getBoolean("multi", false)) }
    var screen by remember { mutableStateOf("chat") }
    var hasAccess by remember { mutableStateOf(Perms.hasFileAccess(ctx)) }
    var showAccessDialog by remember { mutableStateOf(!hasAccess) }

    // Re-check file access every time the app comes back from the system settings page.
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) hasAccess = Perms.hasFileAccess(ctx)
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }
    val legacyLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        hasAccess = Perms.hasFileAccess(ctx)
    }

    val palette = buildPalette(themeCfg)
    val bgBitmap = remember(themeCfg.bgImage) {
        if (themeCfg.bgImage.isBlank()) null
        else runCatching { BitmapFactory.decodeFile(themeCfg.bgImage)?.asImageBitmap() }.getOrNull()
    }

    MaterialTheme(colorScheme = schemeFor(palette, dark)) {
        CompositionLocalProvider(LocalPalette provides palette) {
            Box(Modifier.fillMaxSize().background(palette.bg)) {
                val bg = bgBitmap
                if (bg != null) {
                    Image(
                        bitmap = bg,
                        contentDescription = null,
                        modifier = Modifier
                            .fillMaxSize()
                            .then(if (themeCfg.glass) Modifier.blur(themeCfg.glassBlur.dp) else Modifier),
                        contentScale = ContentScale.Crop,
                    )
                    Box(Modifier.fillMaxSize().background(palette.bg.copy(alpha = if (palette.glass) 0.3f else 0.6f)))
                }

                if (screen == "settings") {
                    BackHandler { screen = "chat" }
                    SettingsScreen(
                        vm = vm,
                        multi = multi,
                        onMulti = { v ->
                            multi = v
                            prefs.edit().putBoolean("multi", v).apply()
                        },
                        onBack = { screen = "chat" },
                        theme = themeCfg,
                        onTheme = setTheme,
                    )
                } else {
                    ChatScreen(
                        vm = vm,
                        multi = multi,
                        dark = dark,
                        onToggleTheme = { setTheme(themeCfg.copy(theme = if (dark) "light" else "dark")) },
                        onOpenSettings = { screen = "settings" },
                    )
                }

                if (showAccessDialog && !hasAccess) {
                    AlertDialog(
                        onDismissRequest = { showAccessDialog = false },
                        containerColor = palette.surface,
                        title = { Text("Allow file access", color = palette.text) },
                        text = {
                            Text(
                                "DeadCode needs access to files so the AI can create files and folders in your workspace folder.",
                                color = palette.muted,
                            )
                        },
                        confirmButton = {
                            Choice("Allow", selected = true, onClick = {
                                showAccessDialog = false
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                                    ctx.startActivity(Perms.settingsIntent(ctx))
                                } else {
                                    legacyLauncher.launch(
                                        arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE)
                                    )
                                }
                            })
                        },
                        dismissButton = { Choice("Later", selected = false, onClick = { showAccessDialog = false }) },
                    )
                }
            }
        }
    }
}

// ---------- Shared components ----------

@Composable
fun fieldColors() = OutlinedTextFieldDefaults.colors(
    focusedTextColor = LocalPalette.current.text,
    unfocusedTextColor = LocalPalette.current.text,
    focusedContainerColor = LocalPalette.current.surface,
    unfocusedContainerColor = LocalPalette.current.surface,
    focusedBorderColor = LocalPalette.current.muted,
    unfocusedBorderColor = LocalPalette.current.line,
    focusedLabelColor = LocalPalette.current.muted,
    unfocusedLabelColor = LocalPalette.current.muted,
    cursorColor = LocalPalette.current.text,
    focusedPlaceholderColor = LocalPalette.current.muted,
    unfocusedPlaceholderColor = LocalPalette.current.muted,
)

/** Round icon button with a vector icon. */
@Composable
fun IconBtn(icon: ImageVector, desc: String, box: Dp = 40.dp, size: Dp = 22.dp, onClick: () -> Unit) {
    val p = LocalPalette.current
    Box(
        Modifier
            .size(box)
            .clip(CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, contentDescription = desc, tint = p.text, modifier = Modifier.size(size))
    }
}

@Composable
fun Choice(
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val p = LocalPalette.current
    val shape = RoundedCornerShape(10.dp)
    if (selected) {
        Button(
            onClick = onClick,
            modifier = modifier,
            shape = shape,
            colors = ButtonDefaults.buttonColors(containerColor = p.accent, contentColor = p.accentText),
        ) { Text(label, fontSize = 14.sp) }
    } else {
        OutlinedButton(
            onClick = onClick,
            modifier = modifier,
            shape = shape,
            border = BorderStroke(1.dp, p.line),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = p.text),
        ) { Text(label, fontSize = 14.sp) }
    }
}

@Composable
fun Dropdown(
    label: String,
    options: List<Pair<String, String>>,
    selectedId: String,
    onSelect: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    val p = LocalPalette.current
    var expanded by remember { mutableStateOf(false) }
    val selectedText = options.firstOrNull { it.first == selectedId }?.second ?: label
    Box(modifier) {
        OutlinedButton(
            onClick = { expanded = true },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(10.dp),
            border = BorderStroke(1.dp, p.line),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = p.text),
        ) {
            Text(selectedText, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false))
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            options.forEach { (id, text) ->
                DropdownMenuItem(
                    text = { Text(text) },
                    onClick = {
                        onSelect(id)
                        expanded = false
                    },
                )
            }
        }
    }
}

@Composable
fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    val p = LocalPalette.current
    Text(
        title,
        fontSize = 13.sp,
        fontWeight = FontWeight.Medium,
        color = p.muted,
        modifier = Modifier.padding(top = 22.dp, bottom = 8.dp, start = 4.dp),
    )
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = p.surface,
        border = BorderStroke(1.dp, p.line),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(Modifier.padding(14.dp), content = content)
    }
}

@Composable
fun LabeledField(
    label: String,
    value: String,
    placeholder: String = "",
    onChange: (String) -> Unit,
) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label) },
        placeholder = { Text(placeholder) },
        singleLine = true,
        colors = fieldColors(),
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
    )
}

@Composable
fun ToggleRow(title: String, subtitle: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    val p = LocalPalette.current
    Row(
        Modifier.fillMaxWidth().padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = p.text, fontSize = 15.sp)
            Text(subtitle, fontSize = 12.sp, color = p.muted)
        }
        Spacer(Modifier.width(8.dp))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

// ---------- Files, clipboard, save ----------

fun showToast(ctx: Context, msg: String) {
    Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show()
}

fun copyText(ctx: Context, text: String) {
    val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    cm.setPrimaryClip(ClipData.newPlainText("text", text))
}

/** Saves text to the public Downloads folder and returns the file name. */
fun saveToDownloads(ctx: Context, fileName: String, text: String): String {
    return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, fileName)
            put(MediaStore.Downloads.MIME_TYPE, "text/plain")
            put(MediaStore.Downloads.IS_PENDING, 1)
        }
        val uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            ?: error("Cannot create file")
        ctx.contentResolver.openOutputStream(uri)?.use { it.write(text.toByteArray(Charsets.UTF_8)) }
        val done = ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }
        ctx.contentResolver.update(uri, done, null, null)
        fileName
    } else {
        val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        dir.mkdirs()
        File(dir, fileName).writeText(text, Charsets.UTF_8)
        fileName
    }
}

/** Returns a saver that asks for storage permission on Android 8 and older. */
@Composable
fun rememberSaver(): (String, String) -> Unit {
    val ctx = LocalContext.current
    var pending by remember { mutableStateOf<Pair<String, String>?>(null) }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        val job = pending
        pending = null
        if (job != null) {
            if (granted) {
                val msg = runCatching { saveToDownloads(ctx, job.first, job.second) }
                    .fold({ "Saved to Downloads: $it" }, { "Save failed: ${it.message}" })
                showToast(ctx, msg)
            } else {
                showToast(ctx, "Storage permission denied")
            }
        }
    }
    return { name, text ->
        val needsPermission = Build.VERSION.SDK_INT < Build.VERSION_CODES.Q &&
            ctx.checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
        if (needsPermission) {
            pending = name to text
            permLauncher.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        } else {
            val msg = runCatching { saveToDownloads(ctx, name, text) }
                .fold({ "Saved to Downloads: $it" }, { "Save failed: ${it.message}" })
            showToast(ctx, msg)
        }
    }
}

/** Reads a picked file. Photos are downscaled to keep requests small. */
fun readAttachment(ctx: Context, uri: Uri): Attachment? {
    val mime = ctx.contentResolver.getType(uri) ?: "application/octet-stream"
    val name = uri.lastPathSegment?.substringAfterLast('/')?.substringAfterLast(':') ?: "file"
    val bytes = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: return null
    return when {
        mime.startsWith("image/") -> {
            val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: return null
            val scale = minOf(1f, 1024f / maxOf(bmp.width, bmp.height))
            val scaled = if (scale < 1f) {
                Bitmap.createScaledBitmap(bmp, (bmp.width * scale).toInt(), (bmp.height * scale).toInt(), true)
            } else bmp
            val out = ByteArrayOutputStream()
            scaled.compress(Bitmap.CompressFormat.JPEG, 85, out)
            Attachment(name, "image", "image/jpeg", Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP))
        }
        mime.startsWith("audio/") ->
            Attachment(name, "audio", mime, Base64.encodeToString(bytes, Base64.NO_WRAP))
        bytes.size > 300_000 ->
            Attachment(name, "text", mime, "(file too large to include: ${bytes.size} bytes)")
        mime.startsWith("text/") || mime.contains("json") || mime.contains("xml") ||
            name.endsWith(".kt") || name.endsWith(".py") || name.endsWith(".js") || name.endsWith(".md") ||
            name.endsWith(".java") || name.endsWith(".html") || name.endsWith(".css") || name.endsWith(".csv") ->
            Attachment(name, "text", mime, String(bytes, Charsets.UTF_8))
        else ->
            Attachment(name, "text", mime, "(binary file, content not included)")
    }
}

// ---------- Message rendering ----------

/** Callbacks used by message items. */
class ChatActions(val save: (String, String) -> Unit, val preview: (String) -> Unit)

data class Seg(val code: Boolean, val lang: String, val text: String)

/** Splits a reply into prose and fenced code blocks. Action blocks are hidden (shown as action cards). */
fun segmentsOf(src: String): List<Seg> {
    val cleaned = src.replace(Regex("```action:[^\\n]*\\n[\\s\\S]*?```"), "")
    val re = Regex("```([A-Za-z0-9_+#.-]*)\\n([\\s\\S]*?)```")
    val out = mutableListOf<Seg>()
    var last = 0
    re.findAll(cleaned).forEach { m ->
        if (m.range.first > last) out += Seg(false, "", cleaned.substring(last, m.range.first))
        out += Seg(true, m.groupValues[1], m.groupValues[2].trimEnd('\n'))
        last = m.range.last + 1
    }
    if (last < cleaned.length) out += Seg(false, "", cleaned.substring(last))
    return out
}

fun isHtmlName(name: String): Boolean {
    val n = name.lowercase()
    return n == "html" || n == "htm" || n.endsWith(".html") || n.endsWith(".htm")
}

fun fileNameFor(lang: String): String {
    val ext = when (lang.lowercase()) {
        "kotlin", "kt" -> "kt"
        "python", "py" -> "py"
        "javascript", "js" -> "js"
        "typescript", "ts" -> "ts"
        "java" -> "java"
        "html" -> "html"
        "css" -> "css"
        "json" -> "json"
        "bash", "sh", "shell" -> "sh"
        "xml" -> "xml"
        "markdown", "md" -> "md"
        "" -> "txt"
        else -> lang.filter { it.isLetterOrDigit() }.take(8).ifBlank { "txt" }
    }
    return "snippet_${System.currentTimeMillis()}.$ext"
}

@Composable
fun ThinkingBlock(reasoning: String) {
    val p = LocalPalette.current
    var open by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxWidth()) {
        Row(
            Modifier
                .clip(RoundedCornerShape(8.dp))
                .clickable { open = !open }
                .padding(vertical = 4.dp, horizontal = 2.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(
                if (open) IcChevronDown else IcChevronRight,
                contentDescription = null,
                tint = p.muted,
                modifier = Modifier.size(16.dp),
            )
            Spacer(Modifier.width(4.dp))
            Text("Thinking", fontSize = 14.sp, color = p.muted)
        }
        AnimatedVisibility(visible = open, enter = fadeIn() + expandVertically(), exit = fadeOut() + shrinkVertically()) {
            Text(
                reasoning,
                fontSize = 14.sp,
                lineHeight = 20.sp,
                color = p.muted,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 4.dp)
                    .background(p.surface, RoundedCornerShape(10.dp))
                    .padding(12.dp),
            )
        }
    }
}

@Composable
fun CodeBlock(seg: Seg, act: ChatActions) {
    val p = LocalPalette.current
    val ctx = LocalContext.current
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = p.surface,
        border = BorderStroke(1.dp, p.line),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column {
            Row(
                Modifier.fillMaxWidth().padding(start = 12.dp, end = 4.dp, top = 2.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(seg.lang.ifBlank { "code" }, fontSize = 12.sp, color = p.muted, modifier = Modifier.weight(1f))
                if (isHtmlName(seg.lang)) {
                    IconBtn(IcEye, "Preview HTML", box = 32.dp, size = 18.dp) { act.preview(seg.text) }
                }
                IconBtn(IcCopy, "Copy", box = 32.dp, size = 18.dp) {
                    copyText(ctx, seg.text)
                    showToast(ctx, "Copied")
                }
                IconBtn(IcDownload, "Save", box = 32.dp, size = 18.dp) { act.save(fileNameFor(seg.lang), seg.text) }
            }
            Text(
                seg.text,
                fontFamily = FontFamily.Monospace,
                fontSize = 13.sp,
                lineHeight = 19.sp,
                color = p.text,
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(12.dp),
            )
        }
    }
}

@Composable
fun AnswerText(text: String, act: ChatActions) {
    val p = LocalPalette.current
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        segmentsOf(text).forEach { s ->
            if (s.code) {
                CodeBlock(s, act)
            } else if (s.text.isNotBlank()) {
                Text(s.text.trim(), color = p.text, fontSize = 15.sp, lineHeight = 22.sp)
            }
        }
    }
}

@Composable
fun ChatBubble(item: ChatItem, act: ChatActions) {
    val p = LocalPalette.current
    val ctx = LocalContext.current
    if (item.kind == "user") {
        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.End) {
            if (item.meta.isNotBlank()) {
                Text(item.meta, fontSize = 12.sp, color = p.muted)
                Spacer(Modifier.height(4.dp))
            }
            if (item.text.isNotBlank()) {
                var menuOpen by remember { mutableStateOf(false) }
                Box {
                    Box(
                        Modifier
                            .widthIn(max = 300.dp)
                            .clip(RoundedCornerShape(18.dp))
                            .glassTouch(p.glass, p.glassHighlight)
                            .combinedClickable(onClick = {}, onLongClick = { menuOpen = true })
                            .background(p.user, RoundedCornerShape(18.dp))
                            .padding(horizontal = 14.dp, vertical = 10.dp)
                    ) {
                        Text(item.text, color = p.text, fontSize = 15.sp, lineHeight = 21.sp)
                    }
                    DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                        DropdownMenuItem(
                            text = { Text("Copy") },
                            leadingIcon = { Icon(IcCopy, null, tint = p.text, modifier = Modifier.size(18.dp)) },
                            onClick = {
                                menuOpen = false
                                copyText(ctx, item.text)
                                showToast(ctx, "Copied")
                            },
                        )
                        DropdownMenuItem(
                            text = { Text("Share") },
                            leadingIcon = { Icon(IcShare, null, tint = p.text, modifier = Modifier.size(18.dp)) },
                            onClick = {
                                menuOpen = false
                                shareText(ctx, item.text)
                            },
                        )
                    }
                }
            }
        }
        return
    }

    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        if (item.meta.isNotBlank()) {
            Text(item.meta, fontSize = 12.sp, color = p.muted)
        }
        if (item.reasoning.isNotBlank()) {
            ThinkingBlock(item.reasoning)
        }
        if (item.kind == "error") {
            Text(item.text, color = p.error, fontSize = 16.sp, lineHeight = 24.sp)
        } else if (item.text.isNotBlank()) {
            AnswerText(item.text, act)
        }
        item.action?.let { ActionView(it, act) }
        if ((item.kind == "assistant" || item.kind == "step") && item.text.isNotBlank()) {
            Row {
                IconBtn(IcCopy, "Copy answer", box = 32.dp, size = 18.dp) {
                    copyText(ctx, item.text)
                    showToast(ctx, "Copied")
                }
            }
        }
    }
}

@Composable
fun ActionView(a: ActionItem, act: ChatActions) {
    val p = LocalPalette.current
    val ctx = LocalContext.current
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = p.surface,
        border = BorderStroke(1.dp, p.line),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(Modifier.padding(12.dp)) {
            Text(a.kind.uppercase(), fontSize = 11.sp, color = p.muted)
            Spacer(Modifier.height(6.dp))
            Text(a.describe(), fontFamily = FontFamily.Monospace, fontSize = 13.sp, color = p.text)
            val statusText = when (a.status) {
                "pending" -> "Waiting for confirmation"
                "running" -> "Running…"
                "done" -> "Done"
                "rejected" -> "Rejected"
                else -> "Error"
            }
            val extra = if (a.output.isNotBlank()) "\n" + a.output.take(800) else ""
            Text(
                statusText + extra,
                fontSize = 12.sp,
                color = if (a.status == "error") p.error else p.muted,
                modifier = Modifier.padding(top = 8.dp),
            )
            if (a.kind == "write") {
                Row(Modifier.padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconBtn(IcDownload, "Save file", box = 32.dp, size = 18.dp) {
                        act.save(a.target.substringAfterLast('/'), a.content)
                    }
                    IconBtn(IcCopy, "Copy file", box = 32.dp, size = 18.dp) {
                        copyText(ctx, a.content)
                        showToast(ctx, "Copied")
                    }
                    if (isHtmlName(a.target)) {
                        IconBtn(IcEye, "Preview HTML", box = 32.dp, size = 18.dp) { act.preview(a.content) }
                    }
                }
            }
        }
    }
}

// ---------- HTML preview ----------

@Composable
fun HtmlPreviewDialog(html: String, onClose: () -> Unit) {
    val p = LocalPalette.current
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(modifier = Modifier.fillMaxSize(), color = p.bg) {
            Column(Modifier.fillMaxSize()) {
                Row(
                    Modifier.fillMaxWidth().padding(4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        "HTML preview",
                        color = p.text,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier.weight(1f).padding(start = 12.dp),
                    )
                    IconBtn(IcClose, "Close", onClick = onClose)
                }
                AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = { ctx ->
                        WebView(ctx).apply {
                            this.settings.javaScriptEnabled = true
                            this.settings.domStorageEnabled = true
                            loadDataWithBaseURL(null, html, "text/html", "UTF-8", null)
                        }
                    },
                )
            }
        }
    }
}

// ---------- Side menu ----------

@Composable
fun MenuItem(icon: ImageVector, label: String, onClick: () -> Unit) {
    val p = LocalPalette.current
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, contentDescription = null, tint = p.text, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(12.dp))
        Text(label, color = p.text, fontSize = 15.sp)
    }
}

@Composable
fun SideMenu(
    sessions: List<ChatSession>,
    currentId: String,
    dark: Boolean,
    onClose: () -> Unit,
    onNew: () -> Unit,
    onOpenChat: (String) -> Unit,
    onDeleteChat: (String) -> Unit,
    onRename: (String, String) -> Unit,
    onExportChat: (String) -> Unit,
    onImport: () -> Unit,
    onSettings: () -> Unit,
    onLog: () -> Unit,
    onToggleTheme: () -> Unit,
) {
    val p = LocalPalette.current
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { shown = true }
    Box(Modifier.fillMaxSize().background(Color(0x66000000)).clickable { onClose() }) {
        AnimatedVisibility(
            visible = shown,
            modifier = Modifier.align(Alignment.CenterStart),
            enter = slideInHorizontally(tween(260)) { -it } + fadeIn(tween(260)),
            exit = slideOutHorizontally(tween(200)) { -it } + fadeOut(),
        ) {
            Column(
                Modifier
                    .fillMaxHeight()
                    .width(290.dp)
                    .background(p.surface)
                    .clickable { }
                    .padding(16.dp)
            ) {
                Text("Menu", color = p.text, fontSize = 18.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(bottom = 8.dp))
                MenuItem(IcEdit, "New chat", onNew)
                MenuItem(IcSettings, "Settings", onSettings)
                MenuItem(IcList, "Activity log", onLog)
                MenuItem(IcUpload, "Import chat", onImport)
                MenuItem(if (dark) IcSun else IcMoon, if (dark) "Light theme" else "Dark theme", onToggleTheme)
                Text(
                    "Saved chats",
                    color = p.muted,
                    fontSize = 13.sp,
                    modifier = Modifier.padding(top = 14.dp, bottom = 6.dp, start = 12.dp),
                )
                if (sessions.isEmpty()) {
                    Text("No saved chats yet.", color = p.muted, fontSize = 13.sp, modifier = Modifier.padding(start = 12.dp))
                }
                LazyColumn(Modifier.weight(1f)) {
                    items(sessions, key = { it.id }) { s ->
                        ChatRow(
                            s = s,
                            selected = s.id == currentId,
                            onOpen = { onOpenChat(s.id) },
                            onDelete = { onDeleteChat(s.id) },
                            onRename = { onRename(s.id, s.customTitle ?: s.title) },
                            onExport = { onExportChat(s.id) },
                        )
                    }
                }
            }
        }
    }
}

@Composable
@OptIn(ExperimentalFoundationApi::class)
fun ChatRow(s: ChatSession, selected: Boolean, onOpen: () -> Unit, onDelete: () -> Unit, onRename: () -> Unit, onExport: () -> Unit) {
    val p = LocalPalette.current
    val date = java.text.SimpleDateFormat("dd MMM HH:mm", java.util.Locale.US).format(java.util.Date(s.updatedAt))
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(if (selected) p.user else Color.Transparent)
            .combinedClickable(onClick = onOpen, onLongClick = onExport)
            .padding(start = 12.dp, end = 4.dp, top = 8.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(s.customTitle ?: s.title, color = p.text, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(date, color = p.muted, fontSize = 11.sp)
        }
        IconBtn(IcEdit, "Rename chat", box = 32.dp, size = 16.dp, onClick = onRename)
        IconBtn(IcTrash, "Delete chat", box = 32.dp, size = 16.dp, onClick = onDelete)
    }
}

// ---------- Chat screen ----------

@Composable
fun ChatScreen(
    vm: AppViewModel,
    multi: Boolean,
    dark: Boolean,
    onToggleTheme: () -> Unit,
    onOpenSettings: () -> Unit,
) {
    val p = LocalPalette.current
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val settings by vm.settings.collectAsState()
    val chat by vm.chat.collectAsState()
    val busy by vm.busy.collectAsState()
    val logs by vm.logs.collectAsState()
    var input by remember { mutableStateOf("") }
    var attachments by remember { mutableStateOf<List<Attachment>>(emptyList()) }
    var menuOpen by remember { mutableStateOf(false) }
    var moreOpen by remember { mutableStateOf(false) }
    var attachOpen by remember { mutableStateOf(false) }
    var effortOpen by remember { mutableStateOf(false) }
    var logOpen by remember { mutableStateOf(false) }
    var modelPickerOpen by remember { mutableStateOf(false) }
    var renaming by remember { mutableStateOf<Pair<String, String>?>(null) }
    var previewHtml by remember { mutableStateOf<String?>(null) }
    val listState = rememberLazyListState()
    val showScrollDown by remember { derivedStateOf { listState.canScrollForward } }
    val save = rememberSaver()
    val actions = ChatActions(save = save, preview = { previewHtml = it })
    val sessions by vm.sessions.collectAsState()
    val currentChatId by vm.currentId.collectAsState()
    val activeProfile = settings.profiles.firstOrNull { it.id == settings.activeId }
    val modelName = activeProfile?.model?.ifBlank { null } ?: "Choose a model"
    val companyName = activeProfile?.let { prof -> PROVIDERS.firstOrNull { it.id == prof.providerId }?.name ?: prof.name }
        ?: "No provider selected"

    LaunchedEffect(chat.size) {
        if (chat.isNotEmpty()) listState.animateScrollToItem(chat.lastIndex)
    }

    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            scope.launch {
                val a = withContext(Dispatchers.IO) { runCatching { readAttachment(ctx, uri) }.getOrNull() }
                if (a != null) attachments = attachments + a
                else showToast(ctx, "Could not read the file")
            }
        }
    }

    val importPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            val text = runCatching {
                ctx.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
            }.getOrNull()
            if (text != null && vm.importChat(text)) showToast(ctx, "Chat imported")
            else showToast(ctx, "Could not import this chat")
        }
    }

    val voiceLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        val spoken = res.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!spoken.isNullOrBlank()) {
            input = if (input.isBlank()) spoken else input + " " + spoken
        }
    }

    // "Ask every time": show the exact command, path and content before running
    val pending = chat.firstOrNull { it.action?.status == "pending" }?.action
    if (pending != null) {
        AlertDialog(
            onDismissRequest = { },
            containerColor = p.surface,
            title = { Text("Confirm action", color = p.text) },
            text = {
                Column(Modifier.heightIn(max = 320.dp).verticalScroll(rememberScrollState())) {
                    Text(pending.describe(), fontFamily = FontFamily.Monospace, fontSize = 13.sp, color = p.text)
                }
            },
            confirmButton = { Choice("Yes", selected = true, onClick = { vm.approveAction(pending) }) },
            dismissButton = { Choice("No", selected = false, onClick = { vm.rejectAction(pending) }) },
        )
    }

    if (logOpen) {
        AlertDialog(
            onDismissRequest = { logOpen = false },
            containerColor = p.surface,
            title = { Text("Activity log", color = p.text) },
            text = {
                Column(Modifier.heightIn(max = 360.dp).verticalScroll(rememberScrollState())) {
                    Text(
                        if (logs.isEmpty()) "No activity yet." else logs.joinToString("\n"),
                        fontFamily = FontFamily.Monospace,
                        fontSize = 12.sp,
                        color = p.muted,
                    )
                }
            },
            confirmButton = { Choice("Close", selected = true, onClick = { logOpen = false }) },
        )
    }

    previewHtml?.let { html -> HtmlPreviewDialog(html = html, onClose = { previewHtml = null }) }
    if (modelPickerOpen) {
        ModelPicker(
            settings = settings,
            onPick = { id ->
                vm.setActive(id)
                modelPickerOpen = false
            },
            onDismiss = { modelPickerOpen = false },
        )
    }
    renaming?.let { (id, current) ->
        RenameDialog(
            current = current,
            onSave = { t ->
                vm.renameChat(id, t)
                renaming = null
            },
            onDismiss = { renaming = null },
        )
    }

    val canSend = !busy && (input.isNotBlank() || attachments.isNotEmpty())
    val sendColor by animateColorAsState(if (canSend) AccentOrange else p.line, tween(200), label = "send")
    val doSend = {
        vm.send(input, multi, attachments)
        input = ""
        attachments = emptyList()
    }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            // Top bar
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                IconBtn(IcMenu, "Menu") { menuOpen = true }
                Column(
                    Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(10.dp))
                        .clickable { modelPickerOpen = true }
                        .padding(vertical = 2.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Crossfade(targetState = modelName, label = "model") { name ->
                        Text(
                            name,
                            color = p.text,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.SemiBold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                    Text(
                        companyName,
                        color = p.muted,
                        fontSize = 12.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                IconBtn(IcDoc, "Activity log") { logOpen = true }
                IconBtn(IcEdit, "New chat") {
                    vm.clearChat()
                    input = ""
                    attachments = emptyList()
                }
                Box {
                    IconBtn(IcMore, "More") { moreOpen = true }
                    DropdownMenu(expanded = moreOpen, onDismissRequest = { moreOpen = false }) {
                        DropdownMenuItem(text = { Text("Settings") }, onClick = {
                            moreOpen = false
                            onOpenSettings()
                        })
                        DropdownMenuItem(text = { Text(if (dark) "Light theme" else "Dark theme") }, onClick = {
                            moreOpen = false
                            onToggleTheme()
                        })
                        DropdownMenuItem(text = { Text("Rename chat") }, onClick = {
                            moreOpen = false
                            renaming = currentChatId to (sessions.firstOrNull { it.id == currentChatId }?.let { it.customTitle ?: it.title } ?: "New chat")
                        })
                        DropdownMenuItem(text = { Text("Clear chat") }, onClick = {
                            moreOpen = false
                            vm.clearChat()
                        })
                    }
                }
            }

            // Messages
            if (chat.isEmpty() && !busy) {
                Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("DeadCode", color = p.text, fontSize = 26.sp, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(6.dp))
                        Text("How can I help you today?", color = p.muted, fontSize = 16.sp)
                    }
                }
            } else {
                Box(Modifier.weight(1f).fillMaxWidth()) {
                LazyColumn(
                    state = listState,
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(18.dp),
                ) {
                    items(chat, key = { it.id }) { item ->
                        Column(Modifier.animateItem()) {
                            EnterFade { ChatBubble(item, actions) }
                        }
                    }
                    if (busy) {
                        item { if (multi) AgentsWorking(settings) else TypingDots() }
                    }
                }
                ScrollToBottom(visible = showScrollDown, onClick = {
                    scope.launch { listState.scrollToItem(maxOf(0, listState.layoutInfo.totalItemsCount - 1)) }
                })
                }
            }

            // Composer
            Surface(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp).glassTouch(p.glass, p.glassHighlight),
                shape = RoundedCornerShape(26.dp),
                color = p.surface,
                border = BorderStroke(1.dp, p.line),
            ) {
                Column(Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
                    if (attachments.isNotEmpty()) {
                        Row(
                            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(bottom = 6.dp),
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                        ) {
                            attachments.forEachIndexed { i, a ->
                                Row(
                                    Modifier
                                        .background(p.user, RoundedCornerShape(10.dp))
                                        .padding(start = 10.dp, end = 2.dp, top = 2.dp, bottom = 2.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                ) {
                                    Text(a.name, fontSize = 12.sp, color = p.text, maxLines = 1)
                                    IconBtn(IcClose, "Remove", box = 28.dp, size = 14.dp) {
                                        attachments = attachments.filterIndexed { j, _ -> j != i }
                                    }
                                }
                            }
                        }
                    }
                    TextField(
                        value = input,
                        onValueChange = { input = it },
                        modifier = Modifier.fillMaxWidth(),
                        placeholder = { Text("Message", color = p.muted) },
                        maxLines = 6,
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = Color.Transparent,
                            unfocusedContainerColor = Color.Transparent,
                            disabledContainerColor = Color.Transparent,
                            focusedIndicatorColor = Color.Transparent,
                            unfocusedIndicatorColor = Color.Transparent,
                            focusedTextColor = p.text,
                            unfocusedTextColor = p.text,
                            cursorColor = p.text,
                        ),
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box {
                            IconBtn(IcPlus, "Attach") { attachOpen = true }
                            DropdownMenu(expanded = attachOpen, onDismissRequest = { attachOpen = false }) {
                                DropdownMenuItem(
                                    text = { Text("Photo") },
                                    leadingIcon = { Icon(IcPhoto, null, tint = p.text, modifier = Modifier.size(18.dp)) },
                                    onClick = {
                                        attachOpen = false
                                        filePicker.launch("image/*")
                                    },
                                )
                                DropdownMenuItem(
                                    text = { Text("File") },
                                    leadingIcon = { Icon(IcFile, null, tint = p.text, modifier = Modifier.size(18.dp)) },
                                    onClick = {
                                        attachOpen = false
                                        filePicker.launch("*/*")
                                    },
                                )
                                DropdownMenuItem(
                                    text = { Text("Audio") },
                                    leadingIcon = { Icon(IcAudio, null, tint = p.text, modifier = Modifier.size(18.dp)) },
                                    onClick = {
                                        attachOpen = false
                                        filePicker.launch("audio/*")
                                    },
                                )
                            }
                        }
                        Box {
                            Row(
                                Modifier
                                    .clip(RoundedCornerShape(16.dp))
                                    .clickable { effortOpen = true }
                                    .padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Icon(IcEffort, contentDescription = null, tint = p.muted, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(6.dp))
                                Text(effortLabel(settings.effort), fontSize = 13.sp, color = p.muted)
                                Icon(IcChevronDown, contentDescription = null, tint = p.muted, modifier = Modifier.size(14.dp))
                            }
                            DropdownMenu(expanded = effortOpen, onDismissRequest = { effortOpen = false }) {
                                EFFORTS.forEach { (key, label) ->
                                    DropdownMenuItem(text = { Text(label) }, onClick = {
                                        effortOpen = false
                                        vm.updateSettings { it.copy(effort = key) }
                                    })
                                }
                            }
                        }
                        Spacer(Modifier.weight(1f))
                        IconBtn(IcMic, "Voice") {
                            try {
                                voiceLauncher.launch(
                                    Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                                        .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                                        .putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak your message")
                                )
                            } catch (e: Exception) {
                                showToast(ctx, "Speech recognition is not available on this device")
                            }
                        }
                        Spacer(Modifier.width(4.dp))
                        Box(
                            Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .glassTouch(p.glass, p.glassHighlight)
                                .background(sendColor)
                                .clickable(enabled = canSend) { doSend() },
                            contentAlignment = Alignment.Center,
                        ) {
                            Icon(
                                IcSend,
                                contentDescription = "Send",
                                tint = if (canSend) Color.White else p.muted,
                                modifier = Modifier.size(18.dp),
                            )
                        }
                    }
                }
            }
        }

        AnimatedVisibility(visible = menuOpen, enter = fadeIn(), exit = fadeOut()) {
            SideMenu(
                sessions = sessions,
                currentId = currentChatId,
                onOpenChat = { id ->
                    menuOpen = false
                    vm.openChat(id)
                },
                onDeleteChat = { id -> vm.deleteChat(id) },
                onExportChat = { id ->
                    vm.exportChat(id)?.let { json -> save("chat-${id.take(8)}.json", json) }
                },
                onImport = {
                    menuOpen = false
                    importPicker.launch("*/*")
                },
                onRename = { id, t ->
                    menuOpen = false
                    renaming = id to t
                },
                dark = dark,
                onClose = { menuOpen = false },
                onNew = {
                    menuOpen = false
                    vm.clearChat()
                    input = ""
                    attachments = emptyList()
                },
                onSettings = {
                    menuOpen = false
                    onOpenSettings()
                },
                onLog = {
                    menuOpen = false
                    logOpen = true
                },
                onToggleTheme = {
                    menuOpen = false
                    onToggleTheme()
                },
            )
        }
    }
}

// ---------- Settings screen ----------

@Composable
fun SettingsScreen(
    vm: AppViewModel,
    multi: Boolean,
    onMulti: (Boolean) -> Unit,
    onBack: () -> Unit,
    theme: ThemeConfig,
    onTheme: (ThemeConfig) -> Unit,
) {
    val p = LocalPalette.current
    val settings by vm.settings.collectAsState()
    val logs by vm.logs.collectAsState()
    val ping by vm.pingResult.collectAsState()
    val ctx = LocalContext.current
    val hasAccess = Perms.hasFileAccess(ctx)

    var editingId by remember { mutableStateOf<String?>(null) }
    var providerId by remember { mutableStateOf("custom") }
    var profileName by remember { mutableStateOf("") }
    var baseUrl by remember { mutableStateOf("https://osaii.wyvernhub.net/api/v1") }
    var apiKey by remember { mutableStateOf("") }
    var model by remember { mutableStateOf("") }
    var showKey by remember { mutableStateOf(false) }
    var formStatus by remember { mutableStateOf("") }
    var startupDraft by remember { mutableStateOf(settings.startupPrompt) }
    var skillName by remember { mutableStateOf("") }
    var skillText by remember { mutableStateOf("") }
    var openGroups by remember { mutableStateOf(setOf<String>()) }
    var workspaceDraft by remember { mutableStateOf(settings.workspacePath) }
    var termCmd by remember { mutableStateOf("") }
    var termOut by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    val bgPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            scope.launch {
                val path = withContext(Dispatchers.IO) { saveBackground(ctx, uri) }
                if (path != null) onTheme(theme.copy(bgImage = path))
                else showToast(ctx, "Could not load this image")
            }
        }
    }

    val clearForm: () -> Unit = {
        editingId = null
        profileName = ""
        apiKey = ""
        model = ""
    }
    val loadProfile: (Profile) -> Unit = { prof ->
        editingId = prof.id
        providerId = prof.providerId
        profileName = prof.name
        baseUrl = prof.baseUrl
        apiKey = prof.apiKey
        model = prof.model
        formStatus = "Editing ${prof.name}"
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconBtn(IcBack, "Back", onClick = onBack)
            Spacer(Modifier.width(4.dp))
            Text("Settings", fontSize = 18.sp, fontWeight = FontWeight.SemiBold, color = p.text)
        }

        Section("File access and workspace") {
            Text(
                if (hasAccess) "File access: granted" else "File access: not granted",
                fontSize = 14.sp,
                color = if (hasAccess) p.text else p.error,
            )
            Text(
                "The AI creates files and folders only inside the workspace folder below.",
                fontSize = 13.sp,
                color = p.muted,
                modifier = Modifier.padding(top = 4.dp),
            )
            if (!hasAccess) {
                Choice(
                    "Grant file access",
                    selected = true,
                    onClick = { ctx.startActivity(Perms.settingsIntent(ctx)) },
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                )
            }
            LabeledField("Workspace folder", workspaceDraft, "/storage/emulated/0/AiChat") { workspaceDraft = it }
            Choice(
                "Save workspace",
                selected = true,
                onClick = {
                    val path = workspaceDraft.trim()
                    if (path.isNotBlank()) {
                        val dir = java.io.File(path)
                        val ok = dir.isDirectory || dir.mkdirs()
                        vm.updateSettings { it.copy(workspacePath = path) }
                        showToast(ctx, if (ok) "Workspace saved" else "Saved, but the folder could not be created")
                    }
                },
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
            )
            Text(
                "Shell commands run in this folder. Android limits which system commands are available.",
                fontSize = 12.sp,
                color = p.muted,
                modifier = Modifier.padding(top = 8.dp),
            )
        }

        Section("Theme") {
            Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Choice("Dark", selected = theme.theme == "dark", onClick = { onTheme(theme.copy(theme = "dark")) }, modifier = Modifier.weight(1f))
                Choice("Light", selected = theme.theme == "light", onClick = { onTheme(theme.copy(theme = "light")) }, modifier = Modifier.weight(1f))
                Choice("Custom", selected = theme.theme == "custom", onClick = { onTheme(theme.copy(theme = "custom")) }, modifier = Modifier.weight(1f))
            }
            ToggleRow(
                title = "Glass UI",
                subtitle = "Makes every element translucent and blurs the background",
                checked = theme.glass,
                onChange = { onTheme(theme.copy(glass = it)) },
            )
            if (theme.glass) {
                Text("Glass opacity: ${(theme.glassAlpha * 100).toInt()}%", fontSize = 13.sp, color = p.muted, modifier = Modifier.padding(top = 8.dp))
                Slider(value = theme.glassAlpha, onValueChange = { onTheme(theme.copy(glassAlpha = it)) }, valueRange = 0.1f..0.9f)
                Text("Blur: ${theme.glassBlur.toInt()} dp", fontSize = 13.sp, color = p.muted)
                Slider(value = theme.glassBlur, onValueChange = { onTheme(theme.copy(glassBlur = it)) }, valueRange = 0f..30f)
                Text("Highlight: ${(theme.glassHighlight * 100).toInt()}%", fontSize = 13.sp, color = p.muted)
                Slider(value = theme.glassHighlight, onValueChange = { onTheme(theme.copy(glassHighlight = it)) }, valueRange = 0f..1f)
            }
            if (theme.theme == "custom") {
                LabeledField("Background color", theme.customBg, "#1E1E1D") { onTheme(theme.copy(customBg = it)) }
                LabeledField("Accent color", theme.customAccent, "#D97757") { onTheme(theme.copy(customAccent = it)) }
                LabeledField("Text color", theme.customText, "#ECECEA") { onTheme(theme.copy(customText = it)) }
            }
        }

        Section("Background") {
            Text("Custom picture shown behind the chat.", fontSize = 13.sp, color = p.muted)
            Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Choice("Choose image", selected = true, onClick = { bgPicker.launch("image/*") }, modifier = Modifier.weight(1f))
                if (theme.bgImage.isNotBlank()) {
                    Choice("Remove", selected = false, onClick = { onTheme(theme.copy(bgImage = "")) }, modifier = Modifier.weight(1f))
                }
            }
        }

        Section("Terminal") {
            Text("Runs shell commands inside the workspace folder.", fontSize = 13.sp, color = p.muted)
            OutlinedTextField(
                value = termCmd,
                onValueChange = { termCmd = it },
                label = { Text("Command") },
                placeholder = { Text("ls -la") },
                singleLine = true,
                colors = fieldColors(),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
            )
            Choice(
                "Run",
                selected = true,
                onClick = { if (termCmd.isNotBlank()) vm.runTerminal(termCmd) { termOut = it } },
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
            )
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = p.bg,
                border = BorderStroke(1.dp, p.line),
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
            ) {
                Text(
                    termOut.ifBlank { "Output will appear here." },
                    fontFamily = FontFamily.Monospace,
                    fontSize = 12.sp,
                    color = p.text,
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 220.dp)
                        .verticalScroll(rememberScrollState())
                        .padding(10.dp),
                )
            }
        }

        Section("Effort") {
            Text("Reasoning effort sent with each request", fontSize = 13.sp, color = p.muted)
            Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Choice("Low", selected = settings.effort == "low",
                    onClick = { vm.updateSettings { it.copy(effort = "low") } }, modifier = Modifier.weight(1f))
                Choice("Medium", selected = settings.effort == "medium",
                    onClick = { vm.updateSettings { it.copy(effort = "medium") } }, modifier = Modifier.weight(1f))
            }
            Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Choice("High", selected = settings.effort == "high",
                    onClick = { vm.updateSettings { it.copy(effort = "high") } }, modifier = Modifier.weight(1f))
                Choice("Max", selected = settings.effort == "max",
                    onClick = { vm.updateSettings { it.copy(effort = "max") } }, modifier = Modifier.weight(1f))
            }
        }

        Section("Startup prompt") {
            Text(
                "Sent automatically at the start of each new chat. It is hidden from the chat.",
                fontSize = 13.sp,
                color = p.muted,
            )
            OutlinedTextField(
                value = startupDraft,
                onValueChange = { startupDraft = it },
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                minLines = 3,
                maxLines = 8,
                placeholder = { Text("e.g. Always answer briefly and use code blocks.") },
                colors = fieldColors(),
                shape = RoundedCornerShape(10.dp),
            )
            Choice(
                "Save startup prompt",
                selected = true,
                onClick = { vm.updateSettings { it.copy(startupPrompt = startupDraft.trim()) } },
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
            )
        }

        Section("Skills") {
            Text(
                "Enabled skills are added to the instructions of every request.",
                fontSize = 13.sp,
                color = p.muted,
            )
            if (settings.skills.isEmpty()) {
                Text("No skills yet.", fontSize = 13.sp, color = p.muted, modifier = Modifier.padding(top = 8.dp))
            }
            settings.skills.forEach { skill ->
                Row(
                    Modifier.fillMaxWidth().padding(top = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(skill.name, color = p.text, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(
                            skill.text.lines().firstOrNull().orEmpty(),
                            fontSize = 12.sp,
                            color = p.muted,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                    Switch(
                        checked = skill.enabled,
                        onCheckedChange = { v ->
                            vm.updateSettings { st ->
                                st.copy(skills = st.skills.map { if (it.id == skill.id) it.copy(enabled = v) else it })
                            }
                        },
                    )
                    IconBtn(IcTrash, "Delete skill", box = 36.dp, size = 18.dp) {
                        vm.updateSettings { st -> st.copy(skills = st.skills.filter { it.id != skill.id }) }
                    }
                }
            }
            LabeledField("Skill name", skillName, "e.g. Code reviewer") { skillName = it }
            OutlinedTextField(
                value = skillText,
                onValueChange = { skillText = it },
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                minLines = 3,
                maxLines = 8,
                label = { Text("Skill instructions") },
                colors = fieldColors(),
                shape = RoundedCornerShape(10.dp),
            )
            Choice(
                "Add skill",
                selected = true,
                onClick = {
                    if (skillName.isNotBlank() && skillText.isNotBlank()) {
                        vm.updateSettings { it.copy(skills = it.skills + Skill(name = skillName.trim(), text = skillText.trim())) }
                        skillName = ""
                        skillText = ""
                    }
                },
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
            )
        }

        Section("Mode") {
            Text("Agent mode", fontSize = 13.sp, color = p.muted)
            Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Choice("Single model", selected = !multi, onClick = { onMulti(false) }, modifier = Modifier.weight(1f))
                Choice("Multi-agent", selected = multi, onClick = { onMulti(true) }, modifier = Modifier.weight(1f))
            }
            Text("Execution", fontSize = 13.sp, color = p.muted, modifier = Modifier.padding(top = 14.dp))
            Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Choice(
                    "Ask every time",
                    selected = settings.askEveryTime,
                    onClick = { vm.updateSettings { it.copy(askEveryTime = true) } },
                    modifier = Modifier.weight(1f),
                )
                Choice(
                    "Auto / No prompt",
                    selected = !settings.askEveryTime,
                    onClick = { vm.updateSettings { it.copy(askEveryTime = false) } },
                    modifier = Modifier.weight(1f),
                )
            }
        }

        Section("Provider profile") {
            Dropdown(
                label = "Provider",
                options = PROVIDERS.map { it.id to it.name },
                selectedId = providerId,
                onSelect = { id ->
                    providerId = id
                    val meta = PROVIDERS.first { it.id == id }
                    baseUrl = if (id == "custom") baseUrl.ifBlank { meta.baseUrl } else meta.baseUrl
                    if (profileName.isBlank()) profileName = meta.name
                },
                modifier = Modifier.fillMaxWidth(),
            )
            LabeledField("Profile name", profileName, "e.g. My OpenAI key") { profileName = it }
            LabeledField("Base URL", baseUrl, "https://osaii.wyvernhub.net/api/v1") { baseUrl = it }
            OutlinedTextField(
                value = apiKey,
                onValueChange = { apiKey = it },
                label = { Text("API key") },
                singleLine = true,
                colors = fieldColors(),
                shape = RoundedCornerShape(10.dp),
                visualTransformation = if (showKey) VisualTransformation.None else PasswordVisualTransformation(),
                trailingIcon = {
                    TextButton(onClick = { showKey = !showKey }) {
                        Text(if (showKey) "Hide" else "Show", color = p.muted)
                    }
                },
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
            )

            Spacer(Modifier.height(12.dp))
            Choice(
                "Ping / Fetch Models",
                selected = false,
                onClick = { vm.ping(baseUrl.trim(), apiKey.trim()) },
                modifier = Modifier.fillMaxWidth(),
            )

            ping?.let { r ->
                val pingLine = if (r.ok) {
                    "Status ${r.status} · ${r.latencyMs} ms · ${r.models.size} models"
                } else {
                    val code = if (r.status > 0) " (${r.status})" else ""
                    "Failed$code · ${r.message.take(200)}"
                }
                Text(pingLine, fontSize = 12.sp, color = if (r.ok) p.muted else p.error, modifier = Modifier.padding(top = 8.dp))
            }

            val models = ping?.models.orEmpty()
            if (models.isNotEmpty()) {
                Column(
                    Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp)
                        .heightIn(max = 200.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    models.forEach { m ->
                        Text(
                            m,
                            fontSize = 14.sp,
                            color = p.text,
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(if (m == model) p.user else p.surface)
                                .clickable { model = m }
                                .padding(10.dp),
                        )
                    }
                }
            }

            if (models.isNotEmpty()) {
                Choice(
                    "Add all ${models.size} models",
                    selected = true,
                    onClick = {
                        val added = vm.addModels(providerId, baseUrl.trim(), apiKey.trim(), models)
                        formStatus = if (added > 0) "Added $added models." else "All these models are already saved."
                    },
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                )
            }
            LabeledField("Model", model, "Pick from the list or type a model name") { model = it }

            Row(Modifier.fillMaxWidth().padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Choice(
                    "Save profile",
                    selected = true,
                    onClick = {
                        if (baseUrl.isBlank()) {
                            formStatus = "Base URL is required."
                        } else {
                            vm.saveProfile(
                                Profile(
                                    id = editingId ?: UUID.randomUUID().toString(),
                                    name = profileName.ifBlank { "Untitled profile" },
                                    providerId = providerId,
                                    baseUrl = baseUrl.trim(),
                                    apiKey = apiKey.trim(),
                                    model = model.trim(),
                                )
                            )
                            formStatus = "Profile saved."
                            clearForm()
                        }
                    },
                    modifier = Modifier.weight(1f),
                )
                Choice(
                    "Delete",
                    selected = false,
                    onClick = {
                        editingId?.let { vm.deleteProfile(it) }
                        formStatus = "Profile deleted."
                        clearForm()
                    },
                    modifier = Modifier.weight(1f),
                )
            }
            if (formStatus.isNotBlank()) {
                Text(formStatus, fontSize = 12.sp, color = p.muted, modifier = Modifier.padding(top = 6.dp))
            }
        }

        Section("Saved profiles") {
            if (settings.profiles.isEmpty()) {
                Text("No profiles saved.", fontSize = 13.sp, color = p.muted)
            }
            settings.profiles.groupBy { groupLabel(it) }.forEach { (label, list) ->
                val isOpen = label in openGroups
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(top = 10.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .clickable { openGroups = if (isOpen) openGroups - label else openGroups + label }
                        .padding(vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        label,
                        color = p.text,
                        fontWeight = FontWeight.Medium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f),
                    )
                    Text(
                        if (isOpen) "Hide" else "Show all ${list.size} models",
                        color = p.muted,
                        fontSize = 12.sp,
                    )
                    Spacer(Modifier.width(6.dp))
                    Icon(
                        if (isOpen) IcChevronDown else IcChevronRight,
                        contentDescription = null,
                        tint = p.muted,
                        modifier = Modifier.size(16.dp),
                    )
                }
                AnimatedVisibility(visible = isOpen, enter = fadeIn() + expandVertically(), exit = fadeOut() + shrinkVertically()) {
                    Column {
                        list.forEach { prof ->
                            Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(prof.model.ifBlank { prof.name }, color = p.text, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text(prof.baseUrl, fontSize = 12.sp, color = p.muted, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                                TextButton(onClick = { loadProfile(prof) }) { Text("Edit", color = p.text) }
                                TextButton(onClick = { vm.setActive(prof.id) }) {
                                    Text(if (settings.activeId == prof.id) "Active" else "Use", color = p.text)
                                }
                            }
                        }
                    }
                }
            }
        }

        Section("Failover") {
            ToggleRow(
                title = "Switch API key on failure",
                subtitle = "Moves to another key for the same provider when quota, rate limit or an error occurs.",
                checked = settings.failoverKeys,
                onChange = { v -> vm.updateSettings { it.copy(failoverKeys = v) } },
            )
            ToggleRow(
                title = "Switch model on failure",
                subtitle = "Falls back to another enabled profile if the current model fails or runs out of tokens.",
                checked = settings.failoverModels,
                onChange = { v -> vm.updateSettings { it.copy(failoverModels = v) } },
            )
        }

        Section("Multi-agent assignment") {
            val agentOptions = listOf("" to "Use active profile") + settings.profiles.map { it.id to it.name }

            Text("Planner / Architect", fontSize = 13.sp, color = p.muted, modifier = Modifier.padding(top = 4.dp))
            Dropdown(
                label = "Use active profile",
                options = agentOptions,
                selectedId = settings.agents.planner.orEmpty(),
                onSelect = { id -> vm.updateSettings { it.copy(agents = it.agents.copy(planner = id.ifEmpty { null })) } },
                modifier = Modifier.fillMaxWidth(),
            )

            Text("Coder", fontSize = 13.sp, color = p.muted, modifier = Modifier.padding(top = 10.dp))
            Dropdown(
                label = "Use active profile",
                options = agentOptions,
                selectedId = settings.agents.coder.orEmpty(),
                onSelect = { id -> vm.updateSettings { it.copy(agents = it.agents.copy(coder = id.ifEmpty { null })) } },
                modifier = Modifier.fillMaxWidth(),
            )

            Text("Reviewer / Tester", fontSize = 13.sp, color = p.muted, modifier = Modifier.padding(top = 10.dp))
            Dropdown(
                label = "Use active profile",
                options = agentOptions,
                selectedId = settings.agents.reviewer.orEmpty(),
                onSelect = { id -> vm.updateSettings { it.copy(agents = it.agents.copy(reviewer = id.ifEmpty { null })) } },
                modifier = Modifier.fillMaxWidth(),
            )
        }

        Section("Activity log") {
            Column(Modifier.fillMaxWidth().heightIn(max = 220.dp).verticalScroll(rememberScrollState())) {
                Text(
                    if (logs.isEmpty()) "No activity yet." else logs.joinToString("\n"),
                    fontFamily = FontFamily.Monospace,
                    fontSize = 12.sp,
                    color = p.muted,
                )
            }
        }

        Spacer(Modifier.height(24.dp))
    }
}

@Composable
fun ColumnScope.EnterFade(content: @Composable () -> Unit) {
    val state = remember { MutableTransitionState(false).apply { targetState = true } }
    AnimatedVisibility(
        visibleState = state,
        enter = fadeIn(tween(350)) + slideInVertically(tween(350)) { it / 8 },
    ) {
        content()
    }
}

@Composable
fun TypingDots() {
    val p = LocalPalette.current
    val transition = rememberInfiniteTransition(label = "dots")
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
        repeat(3) { i ->
            val alpha by transition.animateFloat(
                initialValue = 0.2f,
                targetValue = 1f,
                animationSpec = infiniteRepeatable(tween(600, delayMillis = i * 150), RepeatMode.Reverse),
                label = "dot$i",
            )
            Box(Modifier.size(7.dp).clip(CircleShape).background(p.muted.copy(alpha = alpha)))
        }
        Spacer(Modifier.width(6.dp))
        Text("Thinking", color = p.muted, fontSize = 14.sp)
    }
}

fun providerNameOf(providerId: String, fallback: String): String =
    PROVIDERS.firstOrNull { it.id == providerId }?.name ?: fallback

/** Group title: the provider name, or "Custom · host" for custom endpoints. */
fun groupLabel(p: Profile): String {
    val known = PROVIDERS.firstOrNull { it.id == p.providerId && it.id != "custom" }
    if (known != null) return known.name
    val host = runCatching { java.net.URI(p.baseUrl).host }.getOrNull()?.takeIf { it.isNotBlank() }
        ?: p.baseUrl.ifBlank { "unknown" }
    return "Custom · $host"
}

@Composable
fun ModelPicker(settings: Settings, onPick: (String) -> Unit, onDismiss: () -> Unit) {
    val p = LocalPalette.current
    var query by remember { mutableStateOf("") }
    var expanded by remember { mutableStateOf(setOf<String>()) }
    val q = query.trim()
    val groups = settings.profiles
        .filter { it.enabled }
        .filter { q.isEmpty() || it.model.contains(q, true) || it.name.contains(q, true) || groupLabel(it).contains(q, true) }
        .groupBy { groupLabel(it) }
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(18.dp),
            color = p.surface,
            border = BorderStroke(1.dp, p.line),
            modifier = Modifier.fillMaxWidth().heightIn(max = 620.dp),
        ) {
            Column(Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Models", color = p.text, fontSize = 18.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                    IconBtn(IcClose, "Close", onClick = onDismiss)
                }
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    singleLine = true,
                    placeholder = { Text("Search models") },
                    leadingIcon = { Icon(IcSearch, contentDescription = null, tint = p.muted, modifier = Modifier.size(18.dp)) },
                    colors = fieldColors(),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                )
                if (groups.isEmpty()) {
                    Text("No models found.", color = p.muted, fontSize = 14.sp, modifier = Modifier.padding(top = 12.dp))
                }
                LazyColumn(Modifier.padding(top = 4.dp)) {
                    groups.forEach { (label, list) ->
                        val isOpen = label in expanded || q.isNotEmpty()
                        item(key = "h-$label") {
                            Text(
                                "$label · ${list.size}",
                                color = p.muted,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.padding(top = 12.dp, bottom = 4.dp, start = 4.dp),
                            )
                        }
                        val shown = if (isOpen) list else list.take(3)
                        items(shown, key = { it.id }) { prof ->
                            val selected = prof.id == settings.activeId
                            val title = prof.model.ifBlank { prof.name }
                            Row(
                                Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(if (selected) p.user else Color.Transparent)
                                    .clickable { onPick(prof.id) }
                                    .padding(horizontal = 10.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                ModelIcon(title, 28.dp)
                                Spacer(Modifier.width(10.dp))
                                Text(
                                    title,
                                    color = p.text,
                                    fontSize = 15.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.weight(1f),
                                )
                                if (selected) {
                                    Icon(IcCheck, "Selected", tint = p.text, modifier = Modifier.size(18.dp))
                                }
                            }
                        }
                        if (list.size > 3 && q.isEmpty()) {
                            item(key = "t-$label") {
                                TextButton(onClick = {
                                    expanded = if (label in expanded) expanded - label else expanded + label
                                }) {
                                    Text(
                                        if (label in expanded) "Show less" else "Show all ${list.size} models",
                                        color = p.text,
                                        fontSize = 13.sp,
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun RenameDialog(current: String, onSave: (String) -> Unit, onDismiss: () -> Unit) {
    val p = LocalPalette.current
    var text by remember { mutableStateOf(current) }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = p.surface,
        title = { Text("Rename chat", color = p.text) },
        text = {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                singleLine = true,
                colors = fieldColors(),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth(),
            )
        },
        confirmButton = { Choice("Save", selected = true, onClick = { onSave(text) }) },
        dismissButton = { Choice("Cancel", selected = false, onClick = onDismiss) },
    )
}

@Composable
fun BoxScope.ScrollToBottom(visible: Boolean, onClick: () -> Unit) {
    val p = LocalPalette.current
    AnimatedVisibility(
        visible = visible,
        modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 10.dp),
        enter = fadeIn() + slideInVertically { it },
        exit = fadeOut() + slideOutVertically { it },
    ) {
        Box(
            Modifier
                .size(40.dp)
                .clip(CircleShape)
                .background(p.surface)
                .border(BorderStroke(1.dp, p.line), CircleShape)
                .clickable(onClick = onClick),
            contentAlignment = Alignment.Center,
        ) {
            Icon(IcArrowDown, "Scroll to bottom", tint = p.text, modifier = Modifier.size(20.dp))
        }
    }
}

@Composable
fun AgentsWorking(settings: Settings) {
    val p = LocalPalette.current
    val fallback = settings.profiles.firstOrNull { it.id == settings.activeId }
    val rows = listOf(
        "Planner" to settings.agents.planner,
        "Coder" to settings.agents.coder,
        "Reviewer" to settings.agents.reviewer,
    ).map { (role, id) ->
        val prof = settings.profiles.firstOrNull { it.id == id } ?: fallback
        role to (prof?.model?.ifBlank { null } ?: prof?.name ?: "active model")
    }
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text("Agents working together", color = p.muted, fontSize = 12.sp)
        rows.forEachIndexed { i, (role, name) ->
            val transition = rememberInfiniteTransition(label = "agent$i")
            val alpha by transition.animateFloat(
                initialValue = 0.3f,
                targetValue = 1f,
                animationSpec = infiniteRepeatable(tween(700, delayMillis = i * 200), RepeatMode.Reverse),
                label = "agentAlpha$i",
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(8.dp).clip(CircleShape).background(AccentOrange.copy(alpha = alpha)))
                Spacer(Modifier.width(8.dp))
                Text(
                    "$role · $name",
                    color = p.text,
                    fontSize = 14.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }
    }
}
