package com.example.aichat

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.io.File

// ---------- Theme settings ----------

/** Theme choice. theme: dark | light | custom. Glass is applied on top of any theme. */
data class ThemeConfig(
    val theme: String = "dark",
    val glass: Boolean = false,
    val glassAlpha: Float = 0.45f,
    val glassBlur: Float = 14f,
    val glassHighlight: Float = 0.5f,
    val glassStyle: String = "classic",  // classic | liquid
    val customBg: String = "#1E1E1D",
    val customAccent: String = "#D97757",
    val customText: String = "#ECECEA",
    val bgImage: String = "",
)

object ThemeStore {
    private const val FILE = "theme"

    fun load(ctx: Context): ThemeConfig {
        val p = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        return ThemeConfig(
            theme = p.getString("theme", "dark") ?: "dark",
            glass = p.getBoolean("glass", false),
            glassAlpha = p.getFloat("glassAlpha", 0.45f),
            glassBlur = p.getFloat("glassBlur", 14f),
            glassHighlight = p.getFloat("glassHighlight", 0.5f),
            glassStyle = p.getString("glassStyle", "classic") ?: "classic",
            customBg = p.getString("customBg", "#1E1E1D") ?: "#1E1E1D",
            customAccent = p.getString("customAccent", "#D97757") ?: "#D97757",
            customText = p.getString("customText", "#ECECEA") ?: "#ECECEA",
            bgImage = p.getString("bgImage", "") ?: "",
        )
    }

    fun save(ctx: Context, c: ThemeConfig) {
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit()
            .putString("theme", c.theme)
            .putBoolean("glass", c.glass)
            .putFloat("glassAlpha", c.glassAlpha)
            .putFloat("glassBlur", c.glassBlur)
            .putFloat("glassHighlight", c.glassHighlight)
            .putString("glassStyle", c.glassStyle)
            .putString("customBg", c.customBg)
            .putString("customAccent", c.customAccent)
            .putString("customText", c.customText)
            .putString("bgImage", c.bgImage)
            .apply()
    }
}

fun parseHex(s: String, fallback: Color): Color {
    val t = s.trim().let { if (it.startsWith("#")) it else "#$it" }
    return runCatching { Color(android.graphics.Color.parseColor(t)) }.getOrDefault(fallback)
}

private fun customPalette(c: ThemeConfig): Palette {
    val bg = parseHex(c.customBg, DarkPalette.bg)
    val accent = parseHex(c.customAccent, AccentOrange)
    val text = parseHex(c.customText, DarkPalette.text)
    return Palette(
        bg = bg,
        surface = lerp(bg, Color.White, 0.06f),
        user = lerp(bg, Color.White, 0.12f),
        text = text,
        muted = text.copy(alpha = 0.65f),
        line = lerp(bg, Color.White, 0.16f),
        accent = accent,
        accentText = if (accent.luminance() > 0.5f) Color.Black else Color.White,
        error = DarkPalette.error,
    )
}

fun buildPalette(c: ThemeConfig): Palette {
    val base = when (c.theme) {
        "light" -> LightPalette
        "custom" -> customPalette(c)
        else -> DarkPalette
    }
    if (!c.glass) return base
    return base.copy(
        surface = base.surface.copy(alpha = c.glassAlpha),
        user = base.user.copy(alpha = c.glassAlpha),
        line = base.line.copy(alpha = 0.5f),
        glass = true,
        glassHighlight = c.glassHighlight,
        liquid = c.glassStyle == "liquid",
    )
}

/** Copies the picked picture into app storage (resized) and returns its path. */
fun saveBackground(ctx: Context, uri: Uri): String? {
    return try {
        val bytes = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: return null
        val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: return null
        val scale = minOf(1f, 1280f / maxOf(bmp.width, bmp.height))
        val scaled = if (scale < 1f) {
            Bitmap.createScaledBitmap(bmp, (bmp.width * scale).toInt(), (bmp.height * scale).toInt(), true)
        } else bmp
        val file = File(ctx.filesDir, "background_${System.currentTimeMillis()}.jpg")
        file.outputStream().use { scaled.compress(Bitmap.CompressFormat.JPEG, 90, it) }
        file.path
    } catch (e: Exception) {
        null
    }
}

// ---------- Glass effect ----------

/** Soft light that follows the finger over glass surfaces. */
fun Modifier.glassTouch(enabled: Boolean, strength: Float): Modifier = composed {
    if (!enabled) return@composed this
    var touch by remember { mutableStateOf<Offset?>(null) }
    this
        .pointerInput(Unit) {
            awaitPointerEventScope {
                while (true) {
                    val event = awaitPointerEvent()
                    val change = event.changes.firstOrNull()
                    touch = if (change != null && change.pressed) change.position else null
                }
            }
        }
        .drawWithContent {
            drawContent()
            val c = touch
            if (c != null) {
                drawCircle(
                    brush = Brush.radialGradient(
                        listOf(Color.White.copy(alpha = strength), Color.Transparent),
                        center = c,
                        radius = 260f,
                    ),
                    radius = 260f,
                    center = c,
                )
            }
        }
}

// ---------- Model icons (picked by model name) ----------

enum class ModelKind { GEMINI, CLAUDE, OPENAI, THINK, OTHER }

fun modelKind(name: String): ModelKind {
    val n = name.lowercase()
    return when {
        "gemini" in n || "gemma" in n -> ModelKind.GEMINI
        "claude" in n -> ModelKind.CLAUDE
        "gpt" in n || "openai" in n || Regex("(^|[^a-z])o[134]([^a-z0-9]|$)").containsMatchIn(n) -> ModelKind.OPENAI
        "think" in n || "reason" in n || Regex("(^|[^a-z0-9])r1([^a-z0-9]|$)").containsMatchIn(n) -> ModelKind.THINK
        else -> ModelKind.OTHER
    }
}

@Composable
fun ModelIcon(name: String, size: Dp = 28.dp) {
    val p = LocalPalette.current
    Box(
        Modifier
            .size(size)
            .clip(CircleShape)
            .background(p.user)
            .border(1.dp, p.line, CircleShape),
        contentAlignment = Alignment.Center,
    ) {
        val iconSize = (size.value * 0.56f).dp
        when (modelKind(name)) {
            ModelKind.GEMINI -> Icon(IcSparkle, contentDescription = null, tint = p.accent, modifier = Modifier.size(iconSize))
            ModelKind.CLAUDE -> Icon(IcAsterisk, contentDescription = null, tint = p.accent, modifier = Modifier.size(iconSize))
            ModelKind.OPENAI -> Icon(IcHex, contentDescription = null, tint = p.text, modifier = Modifier.size(iconSize))
            ModelKind.THINK -> Icon(IcThink, contentDescription = null, tint = p.text, modifier = Modifier.size(iconSize))
            ModelKind.OTHER -> Text(
                name.firstOrNull()?.uppercase() ?: "?",
                color = p.text,
                fontSize = (size.value * 0.42f).sp,
                fontWeight = FontWeight.Medium,
            )
        }
    }
}

// ---------- Sharing ----------

fun shareText(ctx: Context, text: String) {
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_TEXT, text)
    }
    ctx.startActivity(Intent.createChooser(intent, "Share"))
}

// ---------- Liquid edge ----------

/** Bright rim that catches the light around a liquid-glass surface. */
fun Modifier.liquidEdge(enabled: Boolean, radius: Dp): Modifier =
    if (!enabled) this else this.drawWithContent {
        drawContent()
        drawRoundRect(
            brush = Brush.linearGradient(
                listOf(Color.White.copy(alpha = 0.7f), Color.White.copy(alpha = 0.05f), Color.White.copy(alpha = 0.3f)),
                start = Offset.Zero,
                end = Offset(size.width, size.height),
            ),
            cornerRadius = CornerRadius(radius.toPx()),
            style = Stroke(width = 1.5.dp.toPx()),
        )
    }
