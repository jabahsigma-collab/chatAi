# Multi-Model Chat (Android, 32-bit)

Native Kotlin + Jetpack Compose app. No HTML, no WebView.

## Build
1. Open this folder in Android Studio (Ladybug or newer), wait for Gradle Sync.
2. If Android Studio reports a missing Gradle wrapper, run in this folder:
       gradle wrapper --gradle-version 8.7
   (or let Android Studio use its bundled Gradle).
3. Build > Build Bundle(s) / APK(s) > Build APK(s), or run: ./gradlew assembleDebug
4. Output: app/build/outputs/apk/debug/app-armeabi-v7a-debug.apk

Only the armeabi-v7a (32-bit) ABI is packaged.

## Notes
- Commands and files run inside the app's private folder (files/workspace).
- API keys are stored in SharedPreferences in plain text.
- Auto mode runs model-proposed commands without confirmation.
